//import { db, auth } from "./firebaseConfig.js";
import { 
    collection, addDoc, query, orderBy, onSnapshot, doc, updateDoc, deleteDoc, getDoc, setDoc, serverTimestamp, where, limit, arrayUnion, getDocs, writeBatch, getFirestore
} from "https://www.gstatic.com/firebasejs/10.10.0/firebase-firestore.js";
import { 
    signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut, onAuthStateChanged , updatePassword, deleteUser, getAuth, sendEmailVerification , reauthenticateWithCredential, EmailAuthProvider
} from "https://www.gstatic.com/firebasejs/10.10.0/firebase-auth.js";

import { initializeApp } from "https://www.gstatic.com/firebasejs/10.10.0/firebase-app.js";

// ✅ Firebase configuration
const firebaseConfig = {
	apiKey: "AIzaSyCSEQD6g5yODdBm-QrmimttWodvr7Z1wSo", // Optional: keep empty or fill in
	authDomain: "dot-84067.firebaseapp.com",
	projectId: "dot-84067",
	storageBucket: "dot-84067.appspot.com",
	messagingSenderId: "995158726072",
	appId: "1:995158726072:web:80e3869fb33aee5b27ab4d",
	measurementId: "G-3KN0FPPBH4"
};

// ✅ Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);

// ✅ Attach Firestore & Auth to window (optional for debugging)
window.db = db;
window.auth = auth;
window.collection = collection;
window.query = query;
window.getDocs = getDocs;
window.orderBy = orderBy;

////////////


console.log(window.updateFirestore);
// Fetch User Data Example
async function fetchUserData() {
	const querySnapshot = await getDocs(collection(db, "users"));
	
	console.log("🔍 Fetching users from Firestore...");
	if (querySnapshot.empty) {
		console.warn("⚠️ No users found in Firestore.");
	}
	
	querySnapshot.forEach((doc) => {
		console.log("📜 Retrieved User:", doc.id, "=>", doc.data());
	});
}

fetchUserData();
console.log("Checking Premium Panel Button:", document.getElementById("toggle-premium-panel"));
console.log("Checking Premium Panel:", document.getElementById("premium-management"));


/////////Making safe password starts here

if (await checkIfAdmin(auth.currentUser)) {
	await fetchSecretKey();
	await fetchAdminEmail();
}

let secretKey = null;

async function fetchSecretKey() {
	try {
		const docRef = doc(db, "appSettings", "admin");
		const docSnap = await getDoc(docRef);
		
		if (docSnap.exists()) {
			secretKey = docSnap.data().password;
			console.log("✅ Secret key loaded from Firestore");
		} else {
			console.error("❌ Admin password doc not found");
		}
	} catch (error) {
		console.error("❌ Error fetching secret key:", error);
	}
}

document.addEventListener("DOMContentLoaded", async function() {
	await fetchSecretKey();
	
	if (!window.adminPassword) {
		const entered = prompt("Enter admin password:");
		if (entered !== secretKey) {
			return alert("❌ Incorrect password!");
		}
		window.adminPassword = entered;
	}
	
	// Safe to use `secretKey` or `window.adminPassword` here
});




/////////Making safe password ends here
///////// Making safe admin email starts here
let ADMIN_EMAIL = null;

async function fetchAdminEmail() {
	try {
		const docRef = doc(db, "appSettings", "admin");
		const docSnap = await getDoc(docRef);
		if (docSnap.exists()) {
			ADMIN_EMAIL = docSnap.data().email;
			console.log("✅ ADMIN_EMAIL fetched:", ADMIN_EMAIL);
			setupAdminAnalysisButton(); // ← safe to run auth check after this
		} else {
			console.error("❌ Admin email not found in Firestore");
		}
	} catch (err) {
		console.error("❌ Error fetching ADMIN_EMAIL:", err);
	}
}

function setupAdminAnalysisButton() {
	onAuthStateChanged(auth, (user) => {
		const adminBtn = document.getElementById("adminAnalysisControlButton");
		if (!adminBtn) return;

		if (user && user.email === ADMIN_EMAIL) {
			adminBtn.style.display = "block";
		} else {
			adminBtn.style.display = "none";
		}
	});
}

document.addEventListener("DOMContentLoaded", () => {
	fetchAdminEmail();
});


///////// Making safe admin email ends here

//const ADMIN_PASSWORD = secretKey; 
//const adminPassword = secretKey;
//const YOUR_ADMIN_PASSWORD = secretKey;
const adminBtn = document.getElementById("admin-btn");
const tradeFormContainer = document.getElementById("trade-form-container");
const removeAllTradesBtn = document.getElementById("remove-all-trades");
const addTradeBtn = document.getElementById("add-trade");
const tradeContainer = document.querySelector(".trade-container");
const loginBtn = document.getElementById("login-btn");
const signupBtn = document.getElementById("signup-btn");
const logoutBtn = document.getElementById("logout-btn"); // Added Logout Button

// Get reference to the notification section
const notificationSection = document.getElementById("notification-section");
const notificationList = document.getElementById("notification-list");
const hideNotificationBtn = document.getElementById("hide-notifications");
const clearAllBtn = document.getElementById("clear-all");




///////////////// STARTS HERE ///////////////// 

///////////////// ENDS HERE ///////////////// 

///////////////// STARTS HERE ///////////////// 

///////////////// ENDS HERE ///////////////// 

///////////////// STARTS HERE ///////////////// 

///////////////// ENDS HERE ///////////////// 

///////////////// STARTS HERE ///////////////// 

///////////////// ENDS HERE ///////////////// 



///////////////// Education Panel STARTS HERE ///////////////// 


document.addEventListener("DOMContentLoaded", () => {
  function openEducationPanel() {
    document.getElementById("educationPanel").classList.remove("hidden");
  }

  function closeEducationPanel() {
    document.getElementById("educationPanel").classList.add("hidden");
  }

  // Global access
  window.openEducationPanel = openEducationPanel;
  window.closeEducationPanel = closeEducationPanel;
});


///////////////// Education Panel ENDS HERE ///////////////// 

///////////////// Dot View Calculator STARTS HERE ///////////////// 


const calculatorDocRef = doc(db, "calculator_settings", "formulas");
let calcFormulas = { ceFormula: "", peFormula: "", visible: false };

async function loadCalculatorSettings() {
	try {
		const snap = await getDoc(calculatorDocRef);
		if (snap.exists()) {
			calcFormulas = snap.data();
			
			// Save visibility status for future use, but do NOT open calculator here
			document.getElementById("toggleCalcVisibility").checked = calcFormulas.visible;
			document.getElementById("ceFormulaInput").value = calcFormulas.ceFormula || "";
			document.getElementById("peFormulaInput").value = calcFormulas.peFormula || "";
			document.getElementById("calcStatusMsg").textContent = calcFormulas.visible ?
				"✅ Calculator is VISIBLE to users." :
				"❌ Calculator is HIDDEN from users.";
			
			// Only show the calculator if it was left open manually by user
			document.getElementById("strikeCalculatorPanel").classList.add("hidden");
		}
	} catch (err) {
		console.error("Error loading calculator settings:", err);
	}
}
window.addEventListener("DOMContentLoaded", loadCalculatorSettings);

async function saveCalculatorSettings() {
  const ceFormula = document.getElementById("ceFormulaInput").value.trim();
  const peFormula = document.getElementById("peFormulaInput").value.trim();
  const visible = document.getElementById("toggleCalcVisibility").checked;

  if (!confirm("Are you sure you want to update formulas and visibility?")) return;

  try {
    await setDoc(calculatorDocRef, { ceFormula, peFormula, visible }, { merge: true });
    document.getElementById("calcStatusMsg").textContent = "✅ Settings saved successfully!";
    loadCalculatorSettings(); // Refresh view
  } catch (err) {
    console.error("Failed to save formulas:", err);
    document.getElementById("calcStatusMsg").textContent = "❌ Failed to save settings.";
  }
}
window.saveCalculatorSettings = saveCalculatorSettings;

function resetCalculatorFormulas() {
  const defaultCE = `
    const buyAbove = open + Math.sqrt(open);
    const sellBelow = open - Math.sqrt(open);
  `;
  const defaultPE = `
    const buyAbove = open + Math.sqrt(open);
    const sellBelow = open - Math.sqrt(open);
  `;
  document.getElementById("ceFormulaInput").value = defaultCE.trim();
  document.getElementById("peFormulaInput").value = defaultPE.trim();
  alert("✅ Default formulas restored. Don’t forget to click Save.");
}
window.resetCalculatorFormulas = resetCalculatorFormulas;




// Render results table
function renderResults(resultObj, containerId) {
	const container = document.getElementById(containerId);
	if (!container || !resultObj) return;
	
	const levelOrder = [
		["Resistance 4", resultObj.resistance4],
		["Resistance 3", resultObj.resistance3],
		["Resistance 2", resultObj.resistance2],
		["Resistance 1", resultObj.resistance1],
		["BUY Above", resultObj.buyAbove],
		["SELL Below", resultObj.sellBelow],
		["Support 1", resultObj.support1],
		["Support 2", resultObj.support2],
		["Support 3", resultObj.support3],
		["Support 4", resultObj.support4],
	];
	
	let html = `<table>
    <tr><th>Level</th><th>Price</th></tr>
    ${levelOrder
      .map(([label, value]) => {
        if (value === undefined || isNaN(value)) return "";
        const cls = label.includes("Resistance")
          ? "resistance"
          : label.includes("Support")
          ? "support"
          : "";
        return `<tr><td class="${cls}">${label}</td><td class="${cls}">${value.toFixed(2)}</td></tr>`;
      })
      .join("")}
  </table>`;
	
	container.innerHTML = html;
}

// Run CE Calculation from formula string
function runCECalc() {
  const open = parseFloat(document.getElementById("calcCEOpen").value);
  if (!open) return;

  try {
    const result = Function("open", calcFormulas.ceFormula + "; return { buyAbove, sellBelow, resistance1, resistance2, resistance3, resistance4, support1, support2, support3, support4 };")(open);
    renderResults(result, "ceResultsBox");
  } catch (err) {
    document.getElementById("ceResultsBox").innerText = "⚠️ Invalid CE Formula";
  }
}
window.runCECalc = runCECalc;

// Run PE Calculation from formula string
function runPECalc() {
  const open = parseFloat(document.getElementById("calcPEOpen").value);
  if (!open) return;

  try {
    const result = Function("open", calcFormulas.peFormula + "; return { buyAbove, sellBelow, resistance1, resistance2, resistance3, resistance4, support1, support2, support3, support4 };")(open);
    renderResults(result, "peResultsBox");
  } catch (err) {
    document.getElementById("peResultsBox").innerText = "⚠️ Invalid PE Formula";
  }
}
window.runPECalc = runPECalc;

window.openStrikeCalc = function() {
	if (!calcFormulas.visible) {
		alert("⚠️ This calculator is currently hidden by the admin.");
		return;
	}
	document.getElementById("strikeCalculatorPanel").classList.remove("hidden");
};

window.closeStrikeCalc = function() {
	document.getElementById("strikeCalculatorPanel").classList.add("hidden");
};




///////////////// Dot View Calculator ENDS HERE ///////////////// 




///////////////// Tool Panel STARTS HERE ///////////////// 
// Open/Close Tools Panel

document.addEventListener("DOMContentLoaded", () => {
	function openToolsPanel() {
		document.getElementById("toolsPanel").classList.remove("hidden");
	}
	
	function closeToolsPanel() {
		document.getElementById("toolsPanel").classList.add("hidden");
	}
	
	// Make them global so onclick can access them
	window.openToolsPanel = openToolsPanel;
	window.closeToolsPanel = closeToolsPanel;
});

const toolLinksRef = collection(db, "tool_links");

// Load and display links for all users
async function loadUsefulLinks() {
  const container = document.getElementById("usefulLinksContainer");
  container.innerHTML = "";
  const q = query(toolLinksRef, orderBy("timestamp", "desc"));
  const snapshot = await getDocs(q);
  
  snapshot.forEach(doc => {
    const data = doc.data();
    const block = document.createElement("div");
    block.className = "link-block";
    block.innerHTML = `
      <h5>${data.title}</h5>
      <p>${data.description}</p>
      <a href="${data.url}" target="_blank" style="color: blue;">Visit</a>
    `;
    container.appendChild(block);
  });
}

// Admin can save a new link
async function saveToolLink() {
	const title = document.getElementById("toolLinkTitle").value.trim();
	const description = document.getElementById("toolLinkDescription").value.trim();
	const url = document.getElementById("toolLinkURL").value.trim();
	
	if (!title || !description || !url) return alert("All fields are required.");
	
	try {
		await addDoc(toolLinksRef, {
			title,
			description,
			url,
			timestamp: serverTimestamp()
		});
		alert("✅ Link saved successfully!");
		loadUsefulLinks(); // refresh
	} catch (err) {
		console.error("❌ Failed to save link:", err);
		alert("❌ Failed to save link.");
	}
}

// ✅ Make available globally
window.saveToolLink = saveToolLink;
// Load links on page load
window.addEventListener("DOMContentLoaded", loadUsefulLinks);


window.editToolLink = async function(docId, currentTitle, currentDescription, currentUrl) {
	const password = prompt("Enter Admin Password:");
	if (password !== secretKey) return alert("❌ Incorrect password!");
	
	const newTitle = prompt("Edit Title:", currentTitle);
	const newDescription = prompt("Edit Description:", currentDescription);
	const newUrl = prompt("Edit URL:", currentUrl);
	
	if (!newTitle || !newDescription || !newUrl) return alert("All fields are required.");
	
	try {
		await updateDoc(doc(db, "tool_links", docId), {
			title: newTitle,
			description: newDescription,
			url: newUrl,
			timestamp: serverTimestamp()
		});
		alert("✅ Link updated!");
		loadUsefulLinks();
		loadAdminLinks();
	} catch (err) {
		console.error("❌ Error updating link:", err);
	}
};

window.deleteToolLink = async function(docId) {
	const password = prompt("Enter Admin Password:");
	if (password !== secretKey) return alert("❌ Incorrect password!");
	if (!confirm("Are you sure you want to delete this link?")) return;
	
	try {
		await deleteDoc(doc(db, "tool_links", docId));
		alert("🗑️ Link deleted!");
		loadUsefulLinks();
		loadAdminLinks();
	} catch (err) {
		console.error("❌ Error deleting link:", err);
	}
};

async function renderAdminLinks() {
	const adminContainer = document.getElementById("adminLinksList");
	adminContainer.innerHTML = "";
	
	const q = query(toolLinksRef, orderBy("timestamp", "desc"));
	const snapshot = await getDocs(q);
	
	snapshot.forEach(docSnap => {
		const data = docSnap.data();
		const docId = docSnap.id;
		
		const block = document.createElement("div");
		block.className = "link-block";
		block.innerHTML = `
      <strong>${data.title}</strong>
      <p>${data.description}</p>
      <a href="${data.url}" target="_blank">🔗 Visit</a><br><br>
      
      <input type="text" id="edit-title-${docId}" value="${data.title}" placeholder="New Title" />
      <input type="text" id="edit-desc-${docId}" value="${data.description}" placeholder="New Description" />
      <input type="text" id="edit-url-${docId}" value="${data.url}" placeholder="New URL" />
      <button onclick="updateToolLink('${docId}')">💾 Update</button>
      <button onclick="deleteToolLink('${docId}')">🗑️ Delete</button>
      <hr/>
    `;
		adminContainer.appendChild(block);
	});
}

window.updateToolLink = async function(docId) {
	const password = prompt("Enter Admin Password:");
	if (password !== secretKey) return alert("❌ Incorrect password!");
	
	const newTitle = document.getElementById(`edit-title-${docId}`).value.trim();
	const newDescription = document.getElementById(`edit-desc-${docId}`).value.trim();
	const newUrl = document.getElementById(`edit-url-${docId}`).value.trim();
	
	if (!newTitle || !newDescription || !newUrl) return alert("All fields are required!");
	
	try {
		await updateDoc(doc(db, "tool_links", docId), {
			title: newTitle,
			description: newDescription,
			url: newUrl,
			timestamp: serverTimestamp()
		});
		alert("✅ Link updated!");
		loadUsefulLinks();
		renderAdminLinks();
	} catch (err) {
		console.error("❌ Error updating link:", err);
	}
};

onAuthStateChanged(auth, async (user) => {
  if (!ADMIN_EMAIL) await fetchAdminEmail();

  if (user && user.email === ADMIN_EMAIL) {
    document.getElementById("adminToolLinksSection").style.display = "block";
    renderAdminLinks();
  } else {
    document.getElementById("adminToolLinksSection").style.display = "none";
  }
});

//toggle link sections in tollsp
window.toggleSection = function(sectionId) {
	const section = document.getElementById(sectionId);
	if (section.style.display === "none" || section.style.display === "") {
		section.style.display = "block";
	} else {
		section.style.display = "none";
	}
};

//toggle inside admin panel 
function toggleSection(id) {
	const el = document.getElementById(id);
	if (el) el.style.display = (el.style.display === "none") ? "block" : "none";
}

///////////////// Tool Panel ENDS HERE ///////////////// 




///////////////// Toolspanel/ticker link STARTS HERE ///////////////// 

// 🧾 Firestore Collection Reference
const tickerLinksRef = collection(db, "ticker_links");

// 🟢 Load Ticker Links (for users)
async function loadTickerLinks() {
  const container = document.getElementById("tickerLinksContainer");
  container.innerHTML = "";
  const q = query(tickerLinksRef, orderBy("timestamp", "desc"));
  const snapshot = await getDocs(q);

  snapshot.forEach(doc => {
    const data = doc.data();
    const block = document.createElement("div");
    block.className = "link-block";
    block.innerHTML = `
      <h5>${data.title}</h5>
      <p>${data.description}</p>
      <a href="${data.url}" target="_blank" style="color: blue;">Visit</a>
    `;
    container.appendChild(block);
  });
}
window.addEventListener("DOMContentLoaded", loadTickerLinks);

// 🟠 Save New Ticker Link (admin)
window.saveTickerLink = async function () {
  const title = document.getElementById("tickerLinkTitle").value.trim();
  const description = document.getElementById("tickerLinkDescription").value.trim();
  const url = document.getElementById("tickerLinkURL").value.trim();

  if (!title || !description || !url) return alert("All fields are required.");

  try {
    await addDoc(tickerLinksRef, {
      title,
      description,
      url,
      timestamp: serverTimestamp()
    });
    alert("✅ Ticker Link saved!");
    loadTickerLinks();
    renderAdminTickerLinks();
  } catch (err) {
    console.error("❌ Error saving ticker link:", err);
    alert("Failed to save.");
  }
};

// 🔁 Render Admin Edit/Delete Panel
async function renderAdminTickerLinks() {
  const adminContainer = document.getElementById("adminTickerLinksList");
  adminContainer.innerHTML = "";

  const q = query(tickerLinksRef, orderBy("timestamp", "desc"));
  const snapshot = await getDocs(q);

  snapshot.forEach(docSnap => {
    const data = docSnap.data();
    const docId = docSnap.id;

    const block = document.createElement("div");
    block.className = "link-block";
    block.innerHTML = `
      <strong>${data.title}</strong>
      <p>${data.description}</p>
      <a href="${data.url}" target="_blank">🔗 Visit</a><br><br>
      
      <input type="text" id="edit-title-${docId}" value="${data.title}" />
      <input type="text" id="edit-desc-${docId}" value="${data.description}" />
      <input type="text" id="edit-url-${docId}" value="${data.url}" />
      <button onclick="updateTickerLink('${docId}')">💾 Update</button>
      <button onclick="deleteTickerLink('${docId}')">🗑️ Delete</button>
      <hr/>
    `;
    adminContainer.appendChild(block);
  });
}

// ✏️ Update
window.updateTickerLink = async function (docId) {
  const password = prompt("Enter Admin Password:");
  if (password !== secretKey) return alert("❌ Incorrect password!");

  const newTitle = document.getElementById(`edit-title-${docId}`).value.trim();
  const newDescription = document.getElementById(`edit-desc-${docId}`).value.trim();
  const newUrl = document.getElementById(`edit-url-${docId}`).value.trim();

  if (!newTitle || !newDescription || !newUrl) return alert("All fields required!");

  try {
    await updateDoc(doc(tickerLinksRef, docId), {
      title: newTitle,
      description: newDescription,
      url: newUrl,
      timestamp: serverTimestamp()
    });
    alert("✅ Ticker Link updated!");
    loadTickerLinks();
    renderAdminTickerLinks();
  } catch (err) {
    console.error("❌ Error updating:", err);
  }
};

// 🗑️ Delete
window.deleteTickerLink = async function (docId) {
  const password = prompt("Enter Admin Password:");
  if (password !== secretKey) return alert("❌ Incorrect password!");
  if (!confirm("Delete this Ticker Link?")) return;

  try {
    await deleteDoc(doc(tickerLinksRef, docId));
    alert("🗑️ Deleted!");
    loadTickerLinks();
    renderAdminTickerLinks();
  } catch (err) {
    console.error("❌ Error deleting:", err);
  }
};

// 🟡 Show Admin Controls If Admin
onAuthStateChanged(auth, async (user) => {
  if (!ADMIN_EMAIL) await fetchAdminEmail();

  const section = document.getElementById("adminTickerLinksSection");
  if (user && user.email === ADMIN_EMAIL) {
    section.style.display = "block";
    renderAdminTickerLinks();
  } else {
    section.style.display = "none";
  }
});

///////////////// Toolspanel/ticker link ENDS HERE ///////////////// 





///////////////// Referral Links STARTS HERE ///////////////// 

const referralLinksRef = collection(db, "referral_links");


async function loadReferralLinks() {
	const container = document.getElementById("referralLinksContainer");
	container.innerHTML = "";
	const q = query(referralLinksRef, orderBy("timestamp", "desc"));
	const snapshot = await getDocs(q);
	
	snapshot.forEach(doc => {
		const data = doc.data();
		const block = document.createElement("div");
		block.className = "link-block";
		block.innerHTML = `
			<h5>${data.title}</h5>
			<p>${data.description}</p>
			<a href="${data.url}" target="_blank" style="color: green;">Open Link</a>
		`;
		container.appendChild(block);
	});
}
window.addEventListener("DOMContentLoaded", loadReferralLinks);

window.saveReferralLink = async function() {
	const title = document.getElementById("referralLinkTitle").value.trim();
	const description = document.getElementById("referralLinkDescription").value.trim();
	const url = document.getElementById("referralLinkURL").value.trim();
	
	if (!title || !description || !url) return alert("All fields are required.");
	
	try {
		await addDoc(referralLinksRef, {
			title,
			description,
			url,
			timestamp: serverTimestamp()
		});
		alert("✅ Referral link saved!");
		loadReferralLinks();
		renderAdminReferralLinks();
	} catch (err) {
		console.error("❌ Error saving referral link:", err);
	}
};

async function renderAdminReferralLinks() {
	const adminContainer = document.getElementById("adminReferralLinksList");
	adminContainer.innerHTML = "";
	
	const q = query(referralLinksRef, orderBy("timestamp", "desc"));
	const snapshot = await getDocs(q);
	
	snapshot.forEach(docSnap => {
		const data = docSnap.data();
		const docId = docSnap.id;
		
		const block = document.createElement("div");
		block.className = "link-block";
		block.innerHTML = `
			<strong>${data.title}</strong>
			<p>${data.description}</p>
			<a href="${data.url}" target="_blank">🔗 Visit</a><br><br>
			
			<input type="text" id="edit-title-${docId}" value="${data.title}" />
			<input type="text" id="edit-desc-${docId}" value="${data.description}" />
			<input type="text" id="edit-url-${docId}" value="${data.url}" />
			<button onclick="updateReferralLink('${docId}')">💾 Update</button>
			<button onclick="deleteReferralLink('${docId}')">🗑️ Delete</button>
			<hr/>
		`;
		adminContainer.appendChild(block);
	});
}

window.updateReferralLink = async function(docId) {
	const password = prompt("Enter Admin Password:");
	if (password !== secretKey) return alert("❌ Incorrect password!");
	
	const newTitle = document.getElementById(`edit-title-${docId}`).value.trim();
	const newDescription = document.getElementById(`edit-desc-${docId}`).value.trim();
	const newUrl = document.getElementById(`edit-url-${docId}`).value.trim();
	
	if (!newTitle || !newDescription || !newUrl) return alert("All fields are required!");
	
	try {
		await updateDoc(doc(referralLinksRef, docId), {
			title: newTitle,
			description: newDescription,
			url: newUrl,
			timestamp: serverTimestamp()
		});
		alert("✅ Referral Link updated!");
		loadReferralLinks();
		renderAdminReferralLinks();
	} catch (err) {
		console.error("❌ Error updating:", err);
	}
};

window.deleteReferralLink = async function(docId) {
	const password = prompt("Enter Admin Password:");
	if (password !== secretKey) return alert("❌ Incorrect password!");
	if (!confirm("Delete this Referral Link?")) return;
	
	try {
		await deleteDoc(doc(referralLinksRef, docId));
		alert("🗑️ Deleted!");
		loadReferralLinks();
		renderAdminReferralLinks();
	} catch (err) {
		console.error("❌ Error deleting:", err);
	}
};

onAuthStateChanged(auth, async (user) => {
	if (!ADMIN_EMAIL) await fetchAdminEmail();
	
	const section = document.getElementById("adminReferralLinksSection");
	if (user && user.email === ADMIN_EMAIL) {
		section.style.display = "block";
		renderAdminReferralLinks();
	} else {
		section.style.display = "none";
	}
});

///////////////// Referral Links ENDS HERE /////////////////






///////////////// Tools panel/ career section STARTS HERE ///////////////// 
// Reference to the Firestore document for the default message
const careerSettingsRef = doc(db, "settings", "career");
const careerOpeningsRef = collection(db, "career_openings");

// Function to save the default message
window.saveCareerDefaultMessage = async function() {
	const message = document.getElementById("careerDefaultMessage").value.trim();
	if (!message) return alert("Message cannot be empty.");
	
	try {
		await setDoc(careerSettingsRef, { defaultMessage: message }, { merge: true });
		alert("✅ Default message saved!");
		loadCareerDefaultMessage();
	} catch (err) {
		console.error("❌ Error saving default message:", err);
		alert("Failed to save the message.");
	}
};

// Function to save career-related emails
window.saveCareerEmails = async function() {
	const hrEmail = document.getElementById("hrEmail").value.trim();
	const careersEmail = document.getElementById("careersEmail").value.trim();
	
	if (!hrEmail || !careersEmail) return alert("Both email fields are required.");
	
	try {
		await setDoc(careerSettingsRef, { hrEmail, careersEmail }, { merge: true });
		alert("✅ Career emails saved!");
		loadCareerEmails();
	} catch (err) {
		console.error("❌ Error saving career emails:", err);
		alert("Failed to save the emails.");
	}
};

// Function to load the default message into the admin panel
async function loadCareerDefaultMessage() {
	try {
		const docSnap = await getDoc(careerSettingsRef);
		if (docSnap.exists()) {
			const data = docSnap.data();
			document.getElementById("careerDefaultMessage").value = data.defaultMessage || "";
		}
	} catch (err) {
		console.error("❌ Error loading default message:", err);
	}
}

// Function to load career-related emails into the admin panel
async function loadCareerEmails() {
	try {
		const docSnap = await getDoc(careerSettingsRef);
		if (docSnap.exists()) {
			const data = docSnap.data();
			document.getElementById("hrEmail").value = data.hrEmail || "";
			document.getElementById("careersEmail").value = data.careersEmail || "";
		}
	} catch (err) {
		console.error("❌ Error loading career emails:", err);
	}
}
// Call these functions when the admin panel loads
loadCareerDefaultMessage();
loadCareerEmails();




async function renderAdminCareerOpenings() {
	const adminContainer = document.getElementById("adminCareerList");
	adminContainer.innerHTML = "";
	
	const q = query(careerOpeningsRef, orderBy("timestamp", "desc"));
	const snapshot = await getDocs(q);
	
	snapshot.forEach(docSnap => {
		const data = docSnap.data();
		const docId = docSnap.id;
		
		const block = document.createElement("div");
		block.className = "link-block";
		block.innerHTML = `
      <strong>${data.title}</strong>
      <p>${data.description}</p>
      <p><strong>Location:</strong> ${data.location}</p>
      <input type="text" id="edit-title-${docId}" value="${data.title}" />
      <input type="text" id="edit-desc-${docId}" value="${data.description}" />
      <input type="text" id="edit-location-${docId}" value="${data.location}" />
      <button onclick="updateCareerOpening('${docId}')">💾 Update</button>
      <button onclick="deleteCareerOpening('${docId}')">🗑️ Delete</button>
      <hr/>
    `;
		adminContainer.appendChild(block);
	});
}

renderAdminCareerOpenings();
//👥 User Interface: Display Default Message When No OpeningsIn the user-facing part of the Career section, we'll display the default message when there are no current job openings.
// Function to load and display job openings
// 👥 User Interface: Display Default Message When No Openings + Show HR Emails
// 👥 User Interface: Display Default Message When No Openings + Show HR Emails
async function loadCareerOpenings() {
	const container = document.getElementById("careerOpeningsContainer");
	container.innerHTML = "";
	
	const q = query(collection(db, "career_openings"), orderBy("timestamp", "desc"));
	const snapshot = await getDocs(q);
	
	let emailBlock = "";
	let careersEmail = "careers@example.com"; // fallback
	let hrEmail = "";
	
	// Load saved HR/Careers emails
	try {
		const emailSnap = await getDoc(careerSettingsRef);
		if (emailSnap.exists()) {
			const data = emailSnap.data();
			hrEmail = data.hrEmail || "";
			careersEmail = data.careersEmail || careersEmail;
			
			if (hrEmail || careersEmail) {
				emailBlock = `
          <div style="margin-top: 20px;">
            <p><strong>Official Contact Emails:</strong></p>
            <ul>
              ${hrEmail ? `<li>HR: <a href="mailto:${hrEmail}">${hrEmail}</a></li>` : ""}
              ${careersEmail ? `<li>Careers: <a href="mailto:${careersEmail}">${careersEmail}</a></li>` : ""}
            </ul>
          </div>
        `;
			}
		}
	} catch (err) {
		console.error("❌ Error loading career emails:", err);
	}
	
	// If no openings found
	if (snapshot.empty) {
		try {
			const docSnap = await getDoc(careerSettingsRef);
			const message = docSnap.exists() ? docSnap.data().defaultMessage : "There are no job openings currently.";
			//uncommented below line and placed its new version below for message of no openings there when no openings.
			//container.innerHTML = `<p>${message}</p>${emailBlock}`;
			
			container.innerHTML = `
			  <div style="margin-bottom: 15px; background: #fff8dc; padding: 12px; border-left: 4px solid #ffa500; border-radius: 6px;">
			    <strong>Currently, there are no active job openings.</strong><br>
			    You may still reach out to us if you're interested in joining DotView.<br>
			    All official hiring communication is done only via our verified emails.
			  </div>
			  <p>${message}</p>
			  ${emailBlock}
			`;


		} catch (err) {
			console.error("❌ Error loading default message:", err);
			container.innerHTML = `<p>There are no job openings currently.</p>${emailBlock}`;
		}
		return;
	}
	
	// Display job openings
	snapshot.forEach(doc => {
		const data = doc.data();
		const block = document.createElement("div");
		block.className = "job-opening";
		
		block.innerHTML = `
      <h5>${data.title}</h5>
      <p>${data.description}</p>
      <p><strong>Location:</strong> ${data.location}</p>
      <div style="font-size: 14px; color: #444; margin-bottom: 8px;">
        To apply, please email your resume and details to <strong>${careersEmail}</strong>.
      </div>
      <a href="mailto:${careersEmail}?subject=Application for ${encodeURIComponent(data.title)}" style="text-decoration: none;">
        <button>Apply</button>
      </a>
    `;
		
		container.appendChild(block);
	});
	
	// Append emails at the bottom
	container.innerHTML += emailBlock;
}

// Call this function when the page loads
window.addEventListener("DOMContentLoaded", loadCareerOpenings);

//🛠️ Applying Confirmation Prompts to Admin Functions.For each administrative function, modify the code to include a confirmation prompt. Here's how you can adjust the existing functions:
window.saveCareerOpening = async function () {
  const title = document.getElementById("careerTitle").value.trim();
  const description = document.getElementById("careerDescription").value.trim();
  const location = document.getElementById("careerLocation").value.trim();

  if (!title || !description || !location) return alert("All fields are required.");

  if (!confirm("Are you sure you want to save this career opening?")) return;

  try {
    await addDoc(careerOpeningsRef, {
      title,
      description,
      location,
      timestamp: serverTimestamp()
    });
    alert("✅ Career opening saved!");
    loadCareerOpenings();
    renderAdminCareerOpenings();
  } catch (err) {
    console.error("❌ Error saving career opening:", err);
    alert("Failed to save.");
  }
};

window.updateCareerOpening = async function (docId) {
  const newTitle = document.getElementById(`edit-title-${docId}`).value.trim();
  const newDescription = document.getElementById(`edit-desc-${docId}`).value.trim();
  const newLocation = document.getElementById(`edit-location-${docId}`).value.trim();

  if (!newTitle || !newDescription || !newLocation) return alert("All fields required!");

  if (!confirm("Are you sure you want to update this career opening?")) return;

  try {
    await updateDoc(doc(careerOpeningsRef, docId), {
      title: newTitle,
      description: newDescription,
      location: newLocation,
      timestamp: serverTimestamp()
    });
    alert("✅ Career opening updated!");
    loadCareerOpenings();
    renderAdminCareerOpenings();
  } catch (err) {
    console.error("❌ Error updating:", err);
  }
};

window.deleteCareerOpening = async function (docId) {
  if (!confirm("Are you sure you want to delete this career opening?")) return;

  try {
    await deleteDoc(doc(careerOpeningsRef, docId));
    alert("🗑️ Career opening deleted!");
    loadCareerOpenings();
    renderAdminCareerOpenings();
  } catch (err) {
    console.error("❌ Error deleting:", err);
  }
};

document.addEventListener("DOMContentLoaded", function() {
  // Define toggleSection function
  window.toggleSection = function(id) {
    const el = document.getElementById(id);
    if (el) {
      el.style.display = (el.style.display === "none") ? "block" : "none";
    }
  };

  // Other initialization code...
});

// Opens a simple popup form for applying to a job
window.openApplicationForm = function(jobId) {
	const jobTitle = "Job Application"; // fallback title
	const toEmail = "your-second-email@example.com"; // Replace this
	
	const subject = encodeURIComponent(`Application for ${jobTitle}`);
	const body = encodeURIComponent(
		`Hello,\n\nI am applying for the "${jobTitle}" position.\n\nPlease find my details below:\n- Name:\n- Contact:\n- Resume:\n\nThanks.`
	);
	
	window.location.href = `mailto:${toEmail}?subject=${subject}&body=${body}`;
};


///////////////// Tools panel/ career section ENDS HERE ///////////////// 





///////////////// Tooltip STARTS HERE ///////////////// 
// === TOOLTIP SYSTEM SETUP ===

const tooltipsMap = {};
const tooltipRef = collection(db, "tooltips");

// Load tooltips into memory
async function loadTooltips() {
	try {
		const snapshot = await getDocs(tooltipRef);
		const list = document.getElementById("tooltip-list");
		if (list) list.innerHTML = "";
		
		snapshot.forEach(doc => {
			const data = doc.data();
			tooltipsMap[data.title] = data.content;
			
			// Add to Admin List (if admin panel exists)
			if (list) {
				const li = document.createElement("li");
				li.innerHTML = `
          <strong>${data.title}</strong>
          <button onclick="editTooltip('${data.title}')">✏️ Edit</button>
          <p style="font-size: 13px; margin: 4px 0;">${data.content.substring(0, 100)}...</p>
          <hr/>
        `;
				list.appendChild(li);
			}
		});
		
		console.log("✅ Tooltips loaded.");
	} catch (err) {
		console.error("❌ Error loading tooltips:", err);
	}
}

// Tooltip display box
const tooltipEl = document.createElement("div");
tooltipEl.id = "tooltip-box";
document.body.appendChild(tooltipEl);


// Show & hide logic
function showTooltip(e) {
  const id = e.target.getAttribute("data-tooltip-id");
  if (!id || !tooltipsMap[id]) return;

  tooltipEl.innerHTML = tooltipsMap[id];
  tooltipEl.style.left = e.pageX + 10 + "px";
  tooltipEl.style.top = e.pageY + 10 + "px";
  tooltipEl.style.display = "block";
}

function hideTooltip() {
  tooltipEl.style.display = "none";
}

//function setupTooltipListeners() {
  //document.querySelectorAll(".tooltip-trigger").forEach(trigger => {
    //trigger.addEventListener("mouseenter", showTooltip);
    //trigger.addEventListener("mouseleave", hideTooltip);
  //});
//}

function setupTooltipListeners() {
	document.querySelectorAll(".tooltip-trigger").forEach(trigger => {
		trigger.addEventListener("mouseenter", showTooltip);
		trigger.addEventListener("mousemove", showTooltip); // for moving tooltip with cursor
		trigger.addEventListener("mouseleave", hideTooltip);
	});
}

//document.querySelectorAll('.tooltip-trigger').forEach(trigger => {
	//trigger.addEventListener('mouseenter', function() {
		//const tooltipId = this.getAttribute('data-tooltip-id');
		//const tooltipEl = document.getElementById(tooltipId);
		//if (tooltipEl) {
			// Show tooltip near the trigger
			//tooltipEl.style.display = 'block';
			// Positioning logic here...
		//}
	//});
//});

window.addEventListener("DOMContentLoaded", async () => {
  await loadTooltips();
  setupTooltipListeners();
});

// === ADMIN TOOLTIP PANEL ===

const tooltipCollectionRef = collection(db, "tooltips");

document.getElementById("save-tooltip-btn").addEventListener("click", async () => {
  const title = document.getElementById("tooltip-title").value.trim();
  const content = document.getElementById("tooltip-content").value.trim();

  if (!title || !content) return alert("Both fields required.");

  try {
    await setDoc(doc(tooltipCollectionRef, title), {
      title,
      content,
      updatedAt: serverTimestamp()
    });
    document.getElementById("tooltip-feedback").textContent = "✅ Tooltip saved!";
    loadTooltips(); // reload
  } catch (err) {
    console.error("❌ Error saving:", err);
    document.getElementById("tooltip-feedback").textContent = "❌ Failed to save tooltip.";
  }
});

document.getElementById("fetch-tooltip-btn").addEventListener("click", async () => {
  const title = document.getElementById("search-tooltip-title").value.trim();
  if (!title) return alert("Enter title to search.");

  try {
    const snap = await getDoc(doc(tooltipCollectionRef, title));
    if (snap.exists()) {
      const data = snap.data();
      document.getElementById("tooltip-title").value = data.title;
      document.getElementById("tooltip-content").value = data.content;
      document.getElementById("tooltip-feedback").textContent = "✅ Loaded!";
    } else {
      document.getElementById("tooltip-feedback").textContent = "⚠️ Not found.";
    }
  } catch (err) {
    console.error("❌ Error fetching:", err);
    document.getElementById("tooltip-feedback").textContent = "❌ Failed to fetch.";
  }
});

// Toggle admin panel
document.getElementById("toggle-tooltip-admin").addEventListener("click", () => {
  const panel = document.getElementById("tooltip-admin-panel");
  panel.style.display = panel.style.display === "none" ? "block" : "none";
});

document.getElementById("close-tooltip-admin").addEventListener("click", () => {
  document.getElementById("tooltip-admin-panel").style.display = "none";
});

document.addEventListener("click", (e) => {
  const panel = document.getElementById("tooltip-admin-panel");
  const btn = document.getElementById("toggle-tooltip-admin");
  if (!panel.contains(e.target) && e.target !== btn && panel.style.display === "block") {
    panel.style.display = "none";
  }
});

//
window.editTooltip = async function(title) {
	try {
		const docSnap = await getDoc(doc(tooltipCollectionRef, title));
		if (docSnap.exists()) {
			const data = docSnap.data();
			document.getElementById("tooltip-title").value = data.title;
			document.getElementById("tooltip-content").value = data.content;
			document.getElementById("tooltip-feedback").textContent = `✅ Loaded "${data.title}"`;
		}
	} catch (error) {
		console.error("❌ Error editing tooltip:", error);
	}
};

//Add this after loading a tooltip in editTooltip:
document.getElementById("tooltip-title").scrollIntoView({ behavior: "smooth", block: "center" });

// Only admin sees tooltip button
onAuthStateChanged(auth, async (user) => {
  const btn = document.getElementById("toggle-tooltip-admin");
  if (!user) return btn.style.display = "none";

  if (!ADMIN_EMAIL) await fetchAdminEmail();
  btn.style.display = user.email === ADMIN_EMAIL ? "inline-block" : "none";
});


document.addEventListener("DOMContentLoaded", () => {
	const heading = document.getElementById("toggleTooltipSectionHeading");
	const section = document.getElementById("tooltipButtonSection");
	
	if (heading && section) {
		heading.addEventListener("click", () => {
			section.style.display = section.style.display === "none" ? "block" : "none";
		});
	}
});

///////////////// Tooltip ENDS HERE ///////////////// 







///////////////// Testimonials STARTS HERE ///////////////// 
// Firestore reference to testimonials collection
const testimonialsRef = collection(db, "publicTestimonials");

// Button to show/hide testimonial section
document.getElementById("show-testimonials-button").addEventListener("click", async () => {
  const section = document.getElementById("testimonial-section");

  if (section.style.display === "none") {
    section.style.display = "block";
    await loadTestimonials();
    section.scrollIntoView({ behavior: "smooth" });
  } else {
    section.style.display = "none";
  }
});

// Function to fetch and display testimonials
async function loadTestimonials() {
  const container = document.getElementById("testimonial-cards");
  container.innerHTML = "";

  try {
    const snapshot = await getDocs(query(testimonialsRef, orderBy("createdAt", "desc")));
    snapshot.forEach(doc => {
      const data = doc.data();
      const card = document.createElement("div");
      card.className = "testimonial-card";
      card.innerHTML = `
        <!--<p>"${data.content}"</p>-->
        <div class="testimonial-text">${data.content}</div>
        <span>— ${data.name}</span>
      `;
      container.appendChild(card);
    });
  } catch (err) {
    console.error("❌ Error loading testimonials:", err);
    container.innerHTML = "<p>Unable to load testimonials at the moment.</p>";
  }
}





//Testimonials admin side 
document.getElementById("submit-testimonial").addEventListener("click", async () => {
	const name = document.getElementById("testimonial-name").value.trim();
	const content = document.getElementById("testimonial-content").innerHTML.trim();
	
	if (!name || !content) return alert("Please fill both fields.");
	
	try {
		await addDoc(collection(db, "publicTestimonials"), {
			name,
			content,
			createdAt: serverTimestamp()
		});
		alert("✅ Testimonial added!");
		document.getElementById("testimonial-name").value = "";
		document.getElementById("testimonial-content").innerHTML = "";
	} catch (err) {
		console.error("❌ Error adding testimonial:", err);
		alert("❌ Failed to add testimonial.");
	}
});


//toggle for admin add testimonial inside admin panel

document.getElementById("toggle-add-testimonial").addEventListener("click", function() {
	const adminAddTestimonial = document.getElementById("admin-add-testimonial");
	if (adminAddTestimonial.style.display === "none" || adminAddTestimonial.style.display === "") {
		adminAddTestimonial.style.display = "block"; // Expand
	} else {
		adminAddTestimonial.style.display = "none"; // Collapse
	}
});



///////////////// Testimonials ENDS HERE ///////////////// 


///////////////// Scrolling message STARTS HERE ///////////////// 
function loadScrollingMessage() {
	const container = document.getElementById("scrollingMessageContainer");
	const textDiv = document.getElementById("scrollingMessageText");
	
	getDoc(doc(db, "settings", "scrollingMessage"))
		.then(docSnap => {
			if (docSnap.exists()) {
				const data = docSnap.data();
				console.log("Scrolling message data:", data);
				
				if (!data.visible || !data.text) {
					container.style.display = "none";
					return;
				}
				
				// Set message and speed
				textDiv.textContent = data.text;
				
				textDiv.classList.remove("scroll-slow", "scroll-medium", "scroll-fast");
				const speed = data.speed || "medium"; // default
				textDiv.classList.add(`scroll-${speed}`);
				
				container.style.display = "block";
			} else {
				container.style.display = "none";
			}
		})
		.catch(err => {
			console.error("Error loading scrolling message:", err);
			container.style.display = "none";
		});
}

// Call this after auth success
onAuthStateChanged(auth, user => {
	if (user) {
		displayPaymentSection(user);
		displayPaymentLinkAdminPanel();
		displayPaymentHistory();
		loadPaymentInfoMessage();
		loadScrollingMessage(); // important
	}
});

document.getElementById("updateScrollingMsgBtn").addEventListener("click", () => {
	const text = document.getElementById("scrollingMsgInput").value.trim();
	const visible = document.getElementById("scrollingMsgVisible").checked;
	const speed = document.getElementById("scrollingMsgSpeed").value;
	const status = document.getElementById("scrollingMsgStatus");
	
	if (!text) {
		status.textContent = "Message cannot be empty.";
		return;
	}
	
	const data = {
		text,
		visible,
		speed: speed || "medium"
	};
	
	setDoc(doc(db, "settings", "scrollingMessage"), data)
		.then(() => {
			status.textContent = "Scrolling message updated!";
		})
		.catch(err => {
			console.error("Error updating scrolling message:", err);
			status.textContent = "Error saving message.";
		});
});

document.addEventListener("DOMContentLoaded", () => {
	const toggle = document.getElementById("toggle-scrolling-msg");
	const section = document.getElementById("scrollingMsgSection");
	const icon = document.getElementById("scrollToggleIcon");

	section.style.display = "none";
	icon.textContent = "▼";

	toggle.addEventListener("click", () => {
		const isHidden = section.style.display === "none";
		section.style.display = isHidden ? "block" : "none";
		icon.textContent = isHidden ? "▲" : "▼";
	});
});


///////////////// Scrolling message ENDS HERE ///////////////// 


///////////////// Payment info msg STARTS HERE ///////////////// 
function loadPaymentInfoMessage() {
	const msgEl = document.getElementById("paymentInfoMessageDisplay");
	
	getDoc(doc(db, "settings", "paymentInfoMessage"))
		.then(docSnap => {
			const data = docSnap.data();
			if (docSnap.exists() && data?.text && data?.show) {
				msgEl.textContent = data.text;
				msgEl.style.display = "block";
			} else {
				msgEl.style.display = "none"; // Hide if show=false or missing
			}
		})
		.catch(error => {
			console.error("Error loading payment info message:", error);
			msgEl.style.display = "none";
		});
}

function loadPaymentInfoMessageForAdminPanel() {
	getDoc(doc(db, "settings", "paymentInfoMessage"))
		.then(docSnap => {
			const data = docSnap.data();
			if (data?.text) {
				document.getElementById("paymentInfoMsgInput").value = data.text;
				document.getElementById("togglePaymentInfoMsgVisibility").checked = !!data.show;
			}
		})
		.catch(err => {
			console.error("Error loading message for admin panel:", err);
		});
}

// Call this when displaying admin panel
loadPaymentInfoMessageForAdminPanel();

onAuthStateChanged(auth, user => {
  if (user) {
    displayPaymentSection(user);
    displayPaymentLinkAdminPanel();
    displayPaymentHistory();
    loadPaymentInfoMessage(); // <<< add this
  }
});

document.getElementById("updatePaymentInfoMsgBtn").addEventListener("click", () => {
	const input = document.getElementById("paymentInfoMsgInput").value.trim();
	const status = document.getElementById("paymentInfoMsgStatus");
	const showToUsers = document.getElementById("togglePaymentInfoMsgVisibility").checked;
	
	if (!input) {
		status.textContent = "Message cannot be empty.";
		return;
	}
	
	setDoc(doc(db, "settings", "paymentInfoMessage"), {
			text: input,
			show: showToUsers
		})
		.then(() => {
			status.textContent = "Payment info message updated!";
		})
		.catch(err => {
			console.error("Error updating payment info message:", err);
			status.textContent = "Error updating message.";
		});
});

document.addEventListener("DOMContentLoaded", () => {
	const toggleH5 = document.getElementById("toggle-payment-info-msg");
	const section = document.getElementById("paymentInfoMsgSection");
	const icon = document.getElementById("paymentMsgToggleIcon");
	
	// Initially hide the section
	section.style.display = "none";
	icon.textContent = "▼";
	
	toggleH5.addEventListener("click", () => {
		const isHidden = section.style.display === "none";
		section.style.display = isHidden ? "block" : "none";
		icon.textContent = isHidden ? "▲" : "▼";
	});
});



///////////////// Payment info msg ENDS HERE ///////////////// 



///////////////// Payment STARTS HERE ///////////////// 
// Toggle fir admin side payment
document.addEventListener("DOMContentLoaded", () => {
	const adminToggle = document.getElementById("toggle-admin-section");
	const adminSection = document.getElementById("adminSection");
	const adminIcon = document.getElementById("adminToggleIcon");

	// Ensure it's hidden on load
	adminSection.style.display = "none";
	adminIcon.textContent = "▼";

	adminToggle.addEventListener("click", () => {
		const isHidden = adminSection.style.display === "none";
		adminSection.style.display = isHidden ? "block" : "none";
		adminIcon.textContent = isHidden ? "▲" : "▼";
	});
});

document.addEventListener("DOMContentLoaded", () => {
	onAuthStateChanged(auth, user => {
		if (user) {
			displayPaymentSection(user);
			displayPaymentLinkAdminPanel();
			displayPaymentHistory();
		} else {
			console.log("User not logged in");
		}
	});
});

function displayPaymentSection(user) {
	const container = document.getElementById('payment-container');
	const payNowBtn = document.getElementById('payNowBtn');
	const userPaymentUI = document.getElementById('userPaymentUI');
	const paymentStatus = document.getElementById('paymentStatus');
	
	// Keep UI collapsed initially
	paymentStatus.innerText = "Checking availability...";
	userPaymentUI.style.display = "none";
	payNowBtn.style.display = "none";
	
	getDoc(doc(db, "settings", "paymentConfig")).then((docSnap) => {
		const data = docSnap.data();
		
		if (!data?.enabled) {
			paymentStatus.innerText = "Payment option is currently disabled by admin.";
			return;
		}
		
		if (data?.link) {
			paymentStatus.innerText = "Click the button below to pay securely.";
			payNowBtn.style.display = "inline-block"; // Show button only, not full UI
			
			payNowBtn.onclick = () => window.open(data.link, "_blank");
			
			document.getElementById("paymentInfoForm").onsubmit = (e) => {
				e.preventDefault();
				const formData = new FormData(e.target);
				const amount = parseFloat(formData.get("amount"));
				
				if (isNaN(amount) || amount <= 0) {
					document.getElementById("paymentMsg").innerText = "Please enter a valid amount.";
					return;
				}
				
				const info = {
					uid: user.uid,
					name: formData.get("name").trim(),
					email: formData.get("email").trim(),
					amount: amount,
					txnId: formData.get("txnId").trim() || "",
					timestamp: formData.get("timestamp").trim() || new Date().toLocaleString(),
					paidForCategory: formData.get("paidForCategory").trim(),
					planDuration: formData.get("planDuration").trim(),
					submittedAt: serverTimestamp()
				};
				
				addDoc(collection(db, "user_payments"), info)
					.then(() => {
						document.getElementById("paymentMsg").innerText = "Payment info sent successfully!";
						e.target.reset();
					})
					.catch((error) => {
						console.error("Error submitting payment info:", error);
						document.getElementById("paymentMsg").innerText = "Error sending payment info.";
					});
			};
		} else {
			paymentStatus.innerText = "Payment link not configured.";
		}
	}).catch(err => {
		paymentStatus.innerText = "Failed to fetch payment link.";
		console.error("Error fetching payment config:", err);
	});
}

function displayPaymentLinkAdminPanel() {
	const input = document.getElementById("paymentLinkInput");
	const status = document.getElementById("paymentLinkStatus");
	const toggleCheckbox = document.getElementById("togglePaymentVisibility");
	const toggleStatus = document.getElementById("toggleStatusMsg");

	const configRef = doc(db, "settings", "paymentConfig");

	getDoc(configRef).then((docSnap) => {
		if (docSnap.exists()) {
			const data = docSnap.data();
			input.value = data.link || "";
			toggleCheckbox.checked = data.enabled !== false; // default to true if undefined
		}
	});

	document.getElementById("updatePaymentLinkBtn").onclick = () => {
		const newLink = input.value.trim();
		const enabled = toggleCheckbox.checked;

		if (!newLink.startsWith("http")) {
			status.innerText = "Invalid link. Please include https://";
			return;
		}

		setDoc(configRef, { link: newLink, enabled: enabled })
			.then(() => {
				status.innerText = "Payment link updated successfully.";
				setTimeout(() => (status.innerText = ""), 3000);
			})
			.catch(() => {
				status.innerText = "Failed to update link.";
			});
	};

	toggleCheckbox.addEventListener("change", () => {
		setDoc(configRef, { enabled: toggleCheckbox.checked }, { merge: true })
			.then(() => {
				toggleStatus.innerText = "Visibility updated.";
				setTimeout(() => (toggleStatus.innerText = ""), 2000);
			});
	});
}

function displayPaymentHistory() {
	const container = document.getElementById("paymentHistoryContainer");
	const historyQuery = query(collection(db, "user_payments"), orderBy("submittedAt", "desc"));
	
	getDocs(historyQuery).then(snapshot => {
		if (snapshot.empty) {
			container.innerHTML = "<p>No payments found.</p>";
			return;
		}
		
		let payments = [];
		snapshot.forEach(doc => {
			const data = doc.data();
			data.id = doc.id;
			data.submittedAtStr = data.submittedAt?.toDate().toLocaleString() || "Unknown date";
			payments.push(data);
		});
		
		// Insert toggle button and container
		container.innerHTML = `
			<button id="toggleHistoryBtn" style="margin-bottom: 10px;">Show/Hide Payment History</button>
			<div id="historyList" style="display: none;"></div>
		`;
		
		const historyListDiv = document.getElementById("historyList");
		
		const renderList = () => {
			const searchVal = document.getElementById("historySearch").value.toLowerCase();
			const sortVal = document.getElementById("historySort").value;
			
			let filtered = payments.filter(p =>
				(p.name || "").toLowerCase().includes(searchVal) ||
				(p.email || "").toLowerCase().includes(searchVal) ||
				(p.paidForCategory || "").toLowerCase().includes(searchVal)
			);
			
			switch (sortVal) {
				case "dateAsc":
					filtered.sort((a, b) => a.submittedAt?.toMillis() - b.submittedAt?.toMillis());
					break;
				case "dateDesc":
					filtered.sort((a, b) => b.submittedAt?.toMillis() - a.submittedAt?.toMillis());
					break;
				case "amountAsc":
					filtered.sort((a, b) => (a.amount || 0) - (b.amount || 0));
					break;
				case "amountDesc":
					filtered.sort((a, b) => (b.amount || 0) - (a.amount || 0));
					break;
				case "categoryAsc":
					filtered.sort((a, b) => (a.paidForCategory || "").localeCompare(b.paidForCategory || ""));
					break;
				case "categoryDesc":
					filtered.sort((a, b) => (b.paidForCategory || "").localeCompare(a.paidForCategory || ""));
					break;
			}
			
			let html = "";
			for (const data of filtered) {
				html += `
					<div style="border: 1px solid #ccc; padding: 10px; margin-bottom: 10px;">
						<strong>Name:</strong> ${data.name || "-"}<br/>
						<strong>Email:</strong> ${data.email || "-"}<br/>
						<strong>Amount:</strong> ₹${data.amount || "-"}<br/>
						<strong>Transaction ID:</strong> ${data.txnId || "Not provided"}<br/>
						<strong>Timestamp:</strong> ${data.timestamp || "-"}<br/>
						<strong>Paid For Category:</strong> ${data.paidForCategory || "-"}<br/>
						<strong>Plan Duration:</strong> ${data.planDuration || "-"}<br/>
						<strong>Submitted:</strong> ${data.submittedAtStr}
					</div>
				`;
			}
			historyListDiv.innerHTML = html;
		};
		
		// Toggle functionality
		document.getElementById("toggleHistoryBtn").addEventListener("click", () => {
			const isVisible = historyListDiv.style.display === "block";
			historyListDiv.style.display = isVisible ? "none" : "block";
		});
		
		// Attach search/sort events
		document.getElementById("historySearch").addEventListener("input", renderList);
		document.getElementById("historySort").addEventListener("change", renderList);
		
		renderList(); // Initial render
	}).catch(err => {
		console.error("Failed to load history:", err);
		container.innerHTML = "<p>Error loading payment history.</p>";
	});
}

window.toggleHistoryList = function () {
	const list = document.getElementById("historyList");
	list.style.display = list.style.display === "none" ? "block" : "none";
};


//Toggle for user side payment
document.addEventListener("DOMContentLoaded", () => {
	const toggleBtn = document.getElementById("toggle-pay");
	const payUI = document.getElementById("userPaymentUI");
	const icon = document.getElementById("payToggleIcon");
	
	// Ensure it's hidden on load
	payUI.style.display = "none";
	icon.textContent = "▼";
	
	toggleBtn.addEventListener("click", () => {
		const isHidden = payUI.style.display === "none";
		payUI.style.display = isHidden ? "block" : "none";
		icon.textContent = isHidden ? "▲" : "▼";
	});
});

///////////////// Payment ENDS HERE ///////////////// 



///////////////// Maintenance Mode STARTS HERE ///////////////// 

//Update Firestore When Admin Toggles the Switch
//import { db } from "./firebaseConfig.js";
//import { doc, getDoc, setDoc, onSnapshot } from "firebase/firestore";

const maintenanceToggle = document.getElementById("maintenance-toggle");

// Function to update Firestore when Admin toggles maintenance mode
async function toggleMaintenanceMode(event) {
	const isEnabled = event.target.checked; // Get toggle state
	
	try {
		await setDoc(doc(db, "settings", "maintenance"), { isMaintenanceMode: isEnabled });
		alert(`✅ Maintenance Mode ${isEnabled ? "Enabled" : "Disabled"}`);
	} catch (error) {
		console.error("❌ Failed to update maintenance mode:", error);
	}
}

// Listen for toggle changes
maintenanceToggle.addEventListener("change", toggleMaintenanceMode);


//Check Maintenance Mode on Login/Page Load
async function checkMaintenanceMode(user) {
	const maintenanceDoc = await getDoc(doc(db, "settings", "maintenance"));
	
	if (maintenanceDoc.exists() && maintenanceDoc.data().isMaintenanceMode) {
		if (!user || !await checkIfAdmin(user)) {
			// If maintenance is enabled and user is not admin, show maintenance screen
			document.body.innerHTML = `<div class="maintenance-message">
                <h1>🚧 Site Under Maintenance 🚧</h1>
                <p>We are performing updates. Please check back later.</p>
            </div>`;
		}
	}
}

// Call this function on login/page load
onAuthStateChanged(auth, async (user) => {
	await checkMaintenanceMode(user);
});

//Auto-Update Maintenance Mode UI
onSnapshot(doc(db, "settings", "maintenance"), (docSnap) => {
    if (docSnap.exists()) {
        const isEnabled = docSnap.data().isMaintenanceMode;
        maintenanceToggle.checked = isEnabled;
    }
});

//toggle for maintenance mode indside admin panel
document.getElementById("toggle-maintenance").addEventListener("click", function() {
    const settings = document.getElementById("maintenance-settings");
    settings.style.display = settings.style.display === "none" ? "block" : "none";
});

///////////////// Maintenance Mode ENDS HERE ///////////////// 



///////////////// Privacy Policy STARTS HERE ///////////////// 


///////////////// Privacy Policy ENDS HERE ///////////////// 


///////////////// New Disclaimer STARTS HERE ///////////////// 

document.addEventListener("DOMContentLoaded", function() {
    // Create Floating Disclaimer Button
    let disclaimerBtn = document.createElement("button");
    disclaimerBtn.id = "disclaimer-btn";
    disclaimerBtn.innerText = "⚠️ Disclaimer";
    document.body.appendChild(disclaimerBtn);

    // Create Disclaimer Popup
    let disclaimerPopup = document.createElement("div");
    disclaimerPopup.id = "disclaimer-popup";
    disclaimerPopup.className = "popup";
    disclaimerPopup.innerHTML = `
        <div class="popup-content">
            <span class="closedisclaimer-btn">&times;</span>
            <h2></br>📢 Disclaimer</h2>

            <p class="disclaimer-intro">
                ⚠️ <strong>Important Notice:</strong> The information provided on this platform is for educational and informational purposes only and should not be considered financial advice.
            </p>

            <div class="disclaimer-section">
                <h3>1️⃣ No Investment Advice</h3>
                <p>
                    We do not provide investment, tax, or legal advice. Any content shared here, including market analysis, trade insights, and financial data, is purely informational. 
                    You should always consult with a licensed financial advisor before making any investment decisions.
                </p>
            </div>

            <div class="disclaimer-section">
                <h3>2️⃣ Risk of Trading</h3>
                <p>
                    Trading in the stock market, options, forex, or cryptocurrencies involves a high level of risk and may not be suitable for all investors. 
                    Past performance does not guarantee future results. You may lose some or all of your capital.
                </p>
            </div>

            <div class="disclaimer-section">
                <h3>3️⃣ No Guarantees</h3>
                <p>
                    While we strive for accuracy, we do not guarantee the correctness, completeness, or reliability of the data presented. 
                    Market conditions can change rapidly, and you should conduct your own research before making any trades.
                </p>
            </div>

            <div class="disclaimer-section">
                <h3>4️⃣ Third-Party Links & Data</h3>
                <p>
                    We may use third-party sources for market data and analysis. We are not responsible for any inaccuracies in external data or 
                    the consequences of decisions based on such data.
                </p>
            </div>

            <div class="disclaimer-section">
                <h3>5️⃣ Personal Responsibility</h3>
                <p>
                    By using this platform, you acknowledge that you are solely responsible for any trading or investment decisions you make. 
                    We are not liable for any financial losses incurred.
                </p>
            </div>

            <div class="disclaimer-section">
                <h3>6️⃣ Regulatory Compliance</h3>
                <p>
                    Ensure that you comply with all applicable financial regulations in your country or jurisdiction when trading or investing.
                </p>
            </div>

            <div class="disclaimer-acknowledgment">
                📌 <strong>Acknowledgment:</strong> By using this platform, you agree to this disclaimer and accept that all financial decisions are made at your own risk.
            </div>

            <div class="disclaimer-actions">
                <button id="agree-disclaimer">✅ Agree & Proceed</button>
                <button class="closedisclaimer-btn">❌ Close</button>
            </div>
        </div>
    `;
    document.body.appendChild(disclaimerPopup);

    // Show Disclaimer Popup
    disclaimerBtn.addEventListener("click", function() {
        disclaimerPopup.style.display = "flex";
    });

    // Close Disclaimer Popup on Close Button
    disclaimerPopup.querySelectorAll(".closedisclaimer-btn").forEach(button => {
        button.addEventListener("click", function() {
            disclaimerPopup.style.display = "none";
        });
    });

    // Close on "Agree & Proceed" Button
    document.getElementById("agree-disclaimer").addEventListener("click", function() {
        disclaimerPopup.style.display = "none";
        alert("You have agreed to the disclaimer. Trade responsibly! 📈");
    });
});

///////////////// New Disclaimer ENDS HERE ///////////////// 

///////////////// Privacy Policy STARTS HERE ///////////////// 

document.addEventListener("DOMContentLoaded", function() {
	// ✅ Create Privacy Policy Button inside Settings Panel
	let privacyBtn = document.createElement("button");
	privacyBtn.id = "privacy-btn";
	privacyBtn.innerText = "🔒 Privacy Policy";
	
	// Assuming you have a settings panel, add button inside it
	let settingsPanel = document.getElementById("settings-panel");
	if (settingsPanel) {
		settingsPanel.appendChild(privacyBtn);
	}
	
	// ✅ Create Privacy Policy Popup
	let privacyPopup = document.createElement("div");
	privacyPopup.id = "privacy-popup";
	privacyPopup.className = "popup";
	privacyPopup.innerHTML = `
        <div class="popup-content">
        </br>
            <span class="closeprivacy-btn"> [ close &times ] </span>
            
            <h2>🔒 Privacy Policy</h2>
            <p id="privacy-text">Loading...</p> <!-- 🔹 Will be replaced with Firestore data -->
        </div>
    `;
	document.body.appendChild(privacyPopup);
	
	// ✅ Add Privacy Policy Button inside Disclaimer Popup
	let privacyInDisclaimer = document.createElement("button");
	privacyInDisclaimer.id = "privacy-inside-disclaimer";
	privacyInDisclaimer.innerText = "🔍 View Privacy Policy";
	document.querySelector(".disclaimer-actions").appendChild(privacyInDisclaimer);
	
	// ✅ Show Privacy Policy Popup
	function openPrivacyPopup() {
		privacyPopup.style.display = "flex";
		loadPrivacyPolicy(); // Fetch from Firestore
	}
	
	privacyBtn.addEventListener("click", openPrivacyPopup);
	privacyInDisclaimer.addEventListener("click", openPrivacyPopup);
	
	// ✅ Close Privacy Policy Popup
	privacyPopup.querySelector(".closeprivacy-btn").addEventListener("click", function() {
		privacyPopup.style.display = "none";
	});
	
	// ✅ Load Privacy Policy from Firestore
	async function loadPrivacyPolicy() {
		const privacyText = document.getElementById("privacy-text");
		
		try {
			const privacyRef = doc(db, "settings", "privacyPolicy"); // Assuming "settings" collection
			const privacySnap = await getDoc(privacyRef);
			
			if (privacySnap.exists()) {
				privacyText.innerHTML = privacySnap.data().content; // Load updated privacy policy
			} else {
				privacyText.innerHTML = "Privacy Policy not found.";
			}
		} catch (error) {
			console.error("❌ Error fetching Privacy Policy:", error);
			privacyText.innerHTML = "Failed to load Privacy Policy.";
		}
	}
});








//Allow admins to update privacy
const privacyEditor = document.getElementById("privacy-editor");
const savePrivacyBtn = document.getElementById("save-privacy-btn");

// ✅ Function to Save Privacy Policy with Admin Password
async function savePrivacyPolicy() {
	const newPolicy = privacyEditor.innerHTML.trim();
	if (!newPolicy) {
		alert("⚠️ Privacy policy cannot be empty!");
		return;
	}
	
	// 🚀 Ask Admin for Password
	const password = prompt("🔑 Enter Admin Password:");
	if (password !== secretKey) { // Replace with a secure password check mechanism
		alert("❌ Incorrect password! You are not authorized to update the Privacy Policy.");
		return;
	}
	
	savePrivacyBtn.innerText = "Saving...";
	savePrivacyBtn.disabled = true;
	
	try {
		await setDoc(doc(db, "settings", "privacyPolicy"), { content: newPolicy }, { merge: true });
		alert("✅ Privacy Policy updated successfully!");
	} catch (error) {
		console.error("❌ Error updating policy:", error);
		alert("⚠️ Failed to update Privacy Policy.");
	}
	
	savePrivacyBtn.innerText = "Save Policy";
	savePrivacyBtn.disabled = false;
}

// ✅ Admin clicks "Save" to update policy
savePrivacyBtn.addEventListener("click", savePrivacyPolicy);

// ✅ Load Existing Privacy Policy on Page Load
async function loadExistingPolicy() {
	try {
		const privacyRef = doc(db, "settings", "privacyPolicy");
		const privacySnap = await getDoc(privacyRef);
		
		if (privacySnap.exists()) {
			privacyEditor.innerHTML = privacySnap.data().content || "Enter Privacy Policy here...";
		}
	} catch (error) {
		console.error("❌ Error loading Privacy Policy:", error);
	}
}

// ✅ Load current Privacy Policy when Admin Panel opens
document.addEventListener("DOMContentLoaded", loadExistingPolicy);


//toggle for update privacy policy inside admin panel
// Toggle visibility of the messages list
document.getElementById("toggle-update-privacy-policy").addEventListener("click", function () {
    const privacyEditorContainer = document.getElementById("privacy-editor-container");
    if (privacyEditorContainer.style.display === "none" || privacyEditorContainer.style.display === "") {
        privacyEditorContainer.style.display = "block"; // Expand
    } else {
        privacyEditorContainer.style.display = "none"; // Collapse
    }
});
///////////////// Privacy Policy ENDS HERE ///////////////// 






///////////////// Old Disclaimer STARTS HERE ///////////////// 
//document.addEventListener("DOMContentLoaded", function() {
//    document.getElementById("disclaimer-btn").addEventListener("click", function() {
//        document.getElementById("disclaimer-popup").style.display = "flex";
//    });

//    document.querySelector(".closedisclaimer-btn").addEventListener("click", function() {
//        document.getElementById("disclaimer-popup").style.display = "none";
//    });
//});
///////////////// Old Disclaimer ENDS HERE ///////////////// 


///////////////// floating button styling STARTS HERE ///////////////// 

// View Modes: Mobile, Tablet, Desktop
const viewModes = [
	{ name: "Mobile", width: "500px", zoom: "100%" },
	{ name: "Tablet", width: "768px", zoom: "90%" },
	{ name: "Desktop", width: "100%", zoom: "100%" }
];

let currentViewIndex = 0;

document.getElementById("layout-toggle-btn").addEventListener("click", function() {
	currentViewIndex = (currentViewIndex + 1) % viewModes.length;
	const { name, width, zoom } = viewModes[currentViewIndex];
	
	document.body.style.width = width;
	document.body.style.zoom = zoom;
	
	alert(`Switched to ${name} View`);
});

///////////////// floating button styling ENDS HERE /////////////////




///////////////// Notification sound STARTS HERE ///////////////// 

// ✅ Fetch notification sounds from Firestore
async function getNotificationSounds() {
    const docRef = doc(db, "settings", "notificationSounds");
    const docSnap = await getDoc(docRef);
    
    if (docSnap.exists()) {
        return docSnap.data();
    } else {
        return {
            sound1: "https://example.com/default1.mp3",
            sound2: "https://example.com/default2.mp3"
        };
    }
}

// ✅ Save user's sound preference in Firestore
async function setNotificationSoundPreference(soundOption) {
    localStorage.setItem("selectedNotificationSound", soundOption);
    const userRef = doc(db, "users", "USER_ID"); // Replace USER_ID dynamically
    await setDoc(userRef, { selectedSound: soundOption }, { merge: true });
}

// ✅ Retrieve user's sound preference from Firestore
async function applyUserPreference() {
    const userRef = doc(db, "users", "USER_ID"); // Replace USER_ID dynamically
    const userDoc = await getDoc(userRef);
    
    if (userDoc.exists()) {
        return userDoc.data().selectedSound || "sound1";
    } else {
        return "sound1";
    }
}

// ✅ Apply user preference on page load
document.addEventListener("DOMContentLoaded", async function () {
    const soundToggle = document.getElementById("soundToggle");
    const soundLabel = document.getElementById("soundLabel");

    // Get user's saved preference
    let selectedSound = await applyUserPreference();
    
    // ✅ Set switch position and label
    soundToggle.checked = selectedSound === "sound1";
    soundLabel.innerText = soundToggle.checked ? "Sound 1" : "Sound 2";

    // ✅ Handle toggle switch action
    soundToggle.addEventListener("change", async function () {
        selectedSound = soundToggle.checked ? "sound1" : "sound2";
        await setNotificationSoundPreference(selectedSound);
        soundLabel.innerText = selectedSound === "sound1" ? "Sound 1" : "Sound 2";

        // 🔄 Play the newly selected sound immediately
        playNotificationSound();
    });
});

// ✅ Function to play notification sound based on user's selection
// ✅ Play notification sound (used by toggle and other parts)
async function playNotificationSound() {
	const soundUrl = await getSelectedSoundUrl(); // 🔹 Get the correct sound
	if (!audio) {
		audio = new Audio(soundUrl); // 🔹 Create audio only if not already created
		audio.preload = "auto"; // 🔹 Preload for smooth playback
	} else {
		audio.src = soundUrl; // 🔹 Update source if audio object already exists
	}
	
	audio.currentTime = 0; // Reset to start
	audio.play().catch(error => console.error("🔊 Error playing sound:", error));
}

// ✅ Admin function to update notification sound URL
//const password = secretKey; // ✅ Hardcoded admin password

async function updateNotificationSoundURL(soundNumber, newUrl, enteredPassword) {
    if (!newUrl) {
        alert("Please enter a valid URL.");
        return;
    }

    // ✅ Check if the entered password matches the hardcoded secretKey
    if (enteredPassword !== secretKey) {
        alert("Incorrect admin password!");
        return;
    }

    // ✅ Update the Firestore document with the new sound URL
    const soundsRef = doc(db, "settings", "notificationSounds");
    await updateDoc(soundsRef, { [`sound${soundNumber}`]: newUrl });

    alert("Sound updated successfully!");
}

// ✅ Admin function to update sound URL
window.updateSound = async function(soundNumber) {
	const newUrl = document.getElementById(`sound${soundNumber}Url`).value;
	const enteredPassword = document.getElementById("adminPassword").value; // ✅ Get input value
	
	if (!enteredPassword) {
		alert("Please enter the admin password.");
		return;
	}
	
	await updateNotificationSoundURL(soundNumber, newUrl, enteredPassword);
};


// Toggle Notification Sounds Section
document.getElementById("toggle-notification-sounds").addEventListener("click", function () {
    const soundContainer = document.getElementById("notification-sound-container");
    soundContainer.style.display = soundContainer.style.display === "none" || soundContainer.style.display === "" ? "block" : "none";
});

///////////////// Notification sound ENDS HERE ///////////////// 




///////////////// FAQ STARTS HERE ///////////////// 



// ✅ Firestore References
const faqCollection = collection(db, "faqs");

// ✅ Fetch & Display FAQs (For Both Users & Admin)
async function loadFAQs() {
	const querySnapshot = await getDocs(query(faqCollection, orderBy("timestamp", "desc")));
	const faqList = document.getElementById("faq-list");
	const adminFaqList = document.getElementById("admin-faq-list");
	faqList.innerHTML = "";
	adminFaqList.innerHTML = "";
	
	querySnapshot.forEach((docSnap) => {
		const faq = docSnap.data();
		const faqId = docSnap.id;
		
		// 📌 User View
		const faqItem = `
            <div class="faq-item">
                <h3>${faq.question}</h3>
                <p>${faq.answer}</p>
                <small>📂 Category: ${faq.category || "Other"} | ⏳ ${new Date(faq.timestamp.toDate()).toLocaleString()}</small>
            </div>
        `;
		faqList.innerHTML += faqItem;
		
		// 🔧 Admin View (With Edit/Delete Buttons)
		const adminItem = `
            <div class="faq-item">
                <h3>${faq.question}</h3>
                <p>${faq.answer}</p>
                <small>📂 Category: ${faq.category || "Other"} | ⏳ ${new Date(faq.timestamp.toDate()).toLocaleString()}</small>
                <button onclick="editFAQ('${faqId}', '${faq.question}', '${faq.answer}', '${faq.category}')">✏️ Edit</button>
                <button onclick="deleteFAQ('${faqId}')">🗑 Delete</button>
            </div>
        `;
		adminFaqList.innerHTML += adminItem;
	});
}

// ✅ Add New FAQ
async function addFAQ() {
	const question = document.getElementById("faq-question").value.trim();
	const answer = document.getElementById("faq-answer").value.trim();
	const category = document.getElementById("faq-category").value.trim() || "Other";
	
	if (!question || !answer) {
		alert("⚠️ Please enter both question and answer!");
		return;
	}
	
	await addDoc(faqCollection, {
		question,
		answer,
		category,
		timestamp: serverTimestamp()
	});
	
	alert("✅ FAQ Added!");
	loadFAQs(); // Refresh list
}



// toggle for Manage Existing FAQ's inside admin panel 
document.getElementById("toggle-faqs").addEventListener("click", function() {
	const faqContainer = document.getElementById("admin-faq-list-container");
	faqContainer.classList.toggle("hidden");
});


// ✅ Edit Existing FAQ
function editFAQ(faqId, question, answer, category) {
	document.getElementById("faq-question").value = question;
	document.getElementById("faq-answer").value = answer;
	document.getElementById("faq-category").value = category;
	
	document.getElementById("add-faq").innerText = "💾 Update FAQ";
	document.getElementById("add-faq").onclick = async function() {
		await updateDoc(doc(faqCollection, faqId), {
			question: document.getElementById("faq-question").value.trim(),
			answer: document.getElementById("faq-answer").value.trim(),
			category: document.getElementById("faq-category").value.trim()
		});
		alert("✅ FAQ Updated!");
		loadFAQs(); // Refresh list
		document.getElementById("add-faq").innerText = "➕ Add FAQ"; // Reset button
		document.getElementById("add-faq").onclick = addFAQ;
	};
}

// ✅ Delete FAQ
async function deleteFAQ(faqId) {
	if (confirm("⚠️ Are you sure you want to delete this FAQ?")) {
		await deleteDoc(doc(faqCollection, faqId));
		alert("✅ FAQ Deleted!");
		loadFAQs(); // Refresh list
	}
}

// ✅ Search FAQs
document.getElementById("faq-search").addEventListener("input", function() {
	const searchTerm = this.value.toLowerCase();
	document.querySelectorAll("#faq-list .faq-item").forEach((item) => {
		item.style.display = item.innerText.toLowerCase().includes(searchTerm) ? "block" : "none";
	});
});

// ✅ Open/Close FAQ Panel
document.getElementById("open-faq-panel").addEventListener("click", () => {
	document.getElementById("faq-panel").classList.remove("hidden");
	loadFAQs(); // Load FAQs when opened
});
document.getElementById("close-faq-panel").addEventListener("click", () => {
	document.getElementById("faq-panel").classList.add("hidden");
});

// ✅ Load FAQs on Page Load
document.addEventListener("DOMContentLoaded", loadFAQs);

document.getElementById("add-faq").addEventListener("click", async () => {
	const password = prompt("Enter admin password:");
	if (password !== secretKey) {
		alert("❌ Incorrect password!");
		return;
	}
	
	const question = document.getElementById("faq-question").value.trim();
	const answer = document.getElementById("faq-answer").value.trim();
	const category = document.getElementById("faq-category").value.trim() || "Other FAQs";
	
	if (!question || !answer) {
		alert("⚠️ Please enter both a question and an answer!");
		return;
	}
	
	try {
		await addDoc(collection(db, "faqs"), {
			question,
			answer,
			category,
			timestamp: serverTimestamp()
		});
		alert("✅ FAQ added successfully!");
		loadFAQs(); // Refresh FAQ list
	} catch (error) {
		console.error("❌ Error adding FAQ:", error);
	}
});

// Toggle FAQ Section
document.getElementById("toggle-faq-section").addEventListener("click", function () {
    const faqContainer = document.getElementById("faq-container");
    faqContainer.style.display = faqContainer.style.display === "none" || faqContainer.style.display === "" ? "block" : "none";
});

// Toggle Existing FAQs List
document.getElementById("toggle-faqs").addEventListener("click", function () {
    const faqListContainer = document.getElementById("admin-faq-list-container");
    faqListContainer.style.display = faqListContainer.style.display === "none" || faqListContainer.style.display === "" ? "block" : "none";
});
///////////////// FAQ  ENDS HERE ///////////////// 



///////////////// Analysis Panel STARTS HERE ///////////////// 

//import { initializeApp } from "https://www.gstatic.com/firebasejs/10.10.0/firebase-app.js";
//import { getFirestore, collection, addDoc, deleteDoc, updateDoc, doc, getDocs, orderBy, serverTimestamp } from "https://www.gstatic.com/firebasejs/10.10.0/firebase-firestore.js";

// ✅ Firebase Configuration
//const firebaseConfig = {
	//apiKey: "YOUR_API_KEY",
	//authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
	//projectId: "YOUR_PROJECT_ID",
	//storageBucket: "YOUR_PROJECT.appspot.com",
	//messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
	//appId: "YOUR_APP_ID"
//};

// ✅ Initialize Firebase & Firestore
//const app = initializeApp(firebaseConfig);
//const db = getFirestore(app);



// --- Analysis Panel Functions ---



// --- Analysis Panel Functions ---

// Open and close the Analysis Panel
function openAnalysisPanel() {
  document.getElementById("analysisPanel").classList.remove("hidden");
  document.getElementById("analysisBadge").classList.add("hidden"); // hide badge when panel opens
}
function closeAnalysisPanel() {
  document.getElementById("analysisPanel").classList.add("hidden");
}

// Admin Analysis Control Button (only clickable for admin)
function toggleAdminControls() {
	if (auth.currentUser && auth.currentUser.email === ADMIN_EMAIL) {
		let password = prompt("Enter Admin Password:");
		if (password === secretKey) {
			const controls = document.getElementById("adminControls");
			if (controls.classList.contains("hidden")) {
				controls.classList.remove("hidden");
			} else {
				controls.classList.add("hidden");
			}
		} else {
			alert("❌ Incorrect Password!");
		}
	} else {
		alert("You are not authorized to access admin controls.");
	}
}


// ✅ Function to Copy Link to Clipboard
window.copyToClipboard = function(link) {
	navigator.clipboard.writeText(link).then(() => {
		alert("✅ Link copied to clipboard!");
	}).catch(err => {
		console.error("❌ Failed to copy link:", err);
	});
};

// --- Admin Functions ---

// Simulated fetchPreviewData function to extract preview info from link
async function fetchPreviewData(link) {
  // Here you can integrate a real preview extraction API if available.
  // For now, we'll simulate:
  if (link.includes("tradingview")) {
    return {
      title: "TradingView Analysis",
      description: "Detailed chart analysis from TradingView.",
      image: "https://via.placeholder.com/150?text=TradingView",
      link: link
    };
  }
  return {
    title: "Default Analysis",
    description: "No preview available.",
    image: "https://via.placeholder.com/150",
    link: link
  };
}

async function addAnalysis() {
	let password = prompt("Enter Admin Password:");
	if (password !== secretKey) {
		alert("❌ Incorrect Password!");
		return;
	}
	
	const title = document.getElementById("newAnalysisTitle").value;
	const category = document.getElementById("newAnalysisCategory").value;
	const link = document.getElementById("newAnalysisLink").value;
	const imageInput = document.getElementById("newAnalysisImage").value;
	const description = document.getElementById("newAnalysisDescription").value;
	
	if (!title || !link || !category) {
		alert("❌ Title, Category & Link are required!");
		return;
	}
	
	let previewData = {
		title,
		description,
		link,
		image: imageInput || ""
	};
	
	// Only fetch preview if image not manually entered
	if (!imageInput) {
		const preview = await fetchPreviewData(link);
		if (preview.image) previewData.image = preview.image;
	}
	
	try {
		await addDoc(collection(db, "analysis"), {
			...previewData,
			category,
			timestamp: serverTimestamp()
		});
		alert("✅ Analysis Added!");
		new Audio("notification.mp3").play();
	} catch (error) {
		console.error("❌ Error adding analysis:", error);
		alert("❌ Error adding analysis! Check console for details.");
	}
}
// Edit analysis description (admin-only) – now takes docId automatically

async function editFullAnalysis(docId) {
	let password = prompt("Enter Admin Password:");
	if (password !== secretKey) {
		alert("❌ Incorrect Password!");
		return;
	}
	
	try {
		const docRef = doc(db, "analysis", docId);
		const docSnap = await getDoc(docRef);
		if (!docSnap.exists()) {
			alert("❌ Analysis not found.");
			return;
		}
		
		const data = docSnap.data();
		
		const title = prompt("Edit Title:", data.title || "");
		const description = prompt("Edit Description:", data.description || "");
		const category = prompt("Edit Category:", data.category || "");
		const link = prompt("Edit Analysis Link:", data.link || "");
		const image = prompt("Edit Image URL:", data.image || "");
		
		if (!title || !category || !link) {
			alert("❌ Title, Link, and Category cannot be empty.");
			return;
		}
		
		await updateDoc(docRef, {
			title,
			description,
			category,
			link,
			image
		});
		
		alert("✅ Analysis Updated!");
	} catch (err) {
		console.error("❌ Failed to update analysis:", err);
		alert("❌ Failed to update analysis.");
	}
}

// Delete analysis (admin-only)
async function deleteAnalysis(docId) {
  let password = prompt("Enter Admin Password:");
  if (password !== secretKey) {
    alert("❌ Incorrect Password!");
    return;
  }
  if (!confirm("Are you sure you want to delete this analysis?")) return;

  try {
    await deleteDoc(doc(db, "analysis", docId));
    alert("✅ Analysis Deleted!");
  } catch (error) {
    console.error("❌ Error deleting analysis:", error);
  }
}

// --- Attach functions to window so they're accessible from HTML ---
window.openAnalysisPanel = openAnalysisPanel;
window.closeAnalysisPanel = closeAnalysisPanel;
window.toggleAdminControls = toggleAdminControls;
window.addAnalysis = addAnalysis;
window.editFullAnalysis = editFullAnalysis;
window.deleteAnalysis = deleteAnalysis;

// Optionally, you could also set up a listener for auth state changes to hide/show admin controls.
onAuthStateChanged(auth, (user) => {
  // If admin, the Admin Analysis Control Button is enabled; otherwise, hide it.
  const adminButton = document.getElementById("adminAnalysisControlButton");
  if (user && user.email === ADMIN_EMAIL) {
    adminButton.style.display = "block";
  } else {
    adminButton.style.display = "none";
  }
});


// ✅ Load Analysis Data (Newest First)

function loadAnalysis() {
	const analysisList = document.getElementById("analysisList");
	const badge = document.getElementById("analysisBadge"); // Badge reference
	analysisList.innerHTML = ""; // Clear previous entries
	
	const q = query(collection(db, "analysis"), orderBy("timestamp", "desc"));
	
	onSnapshot(q, (snapshot) => {
		analysisList.innerHTML = ""; // Clear list to prevent duplicates
		let addedIds = new Set();
		let count = 0; // Count new analyses
		
		snapshot.forEach((docSnap) => {
			const data = docSnap.data();
			const docId = docSnap.id;
			
			if (addedIds.has(docId)) return; // Prevent duplicate entries
			addedIds.add(docId);
			count++; // Increase count for new entries
			
			const listItem = document.createElement("div");
			listItem.classList.add("analysis-item");

			listItem.innerHTML = `
			    <!--<strong>${data.title}</strong> <small>${data.timestamp?.toDate().toLocaleString()}</small>-->
					<strong style="font-size: 20px; font-weight: bold;">${data.title || "Default Title"}</strong><small>${data.timestamp?.toDate().toLocaleString()}</small>
					<p><strong>📂 Category:</strong> ${data.category || "Uncategorized"}</p>

			    <img src="${data.image || 'https://via.placeholder.com/150'}" 
			        class="analysis-image" 
			        alt="Analysis Image"
			        onclick="zoomImage(this.src)">
			    <button class="zoom-button" onclick="zoomImage('${data.image || 'https://via.placeholder.com/150'}')">
			        🔍 Zoom Image
			    </button>
			    <!--<p>${data.description || "No description available."}</p>-->
					<!--<p>${data.description ? data.description.replace(/\n/g, '<br>') : "No description available."}</p>-->
			    <p style="font-style: italic; padding: 10px; border-left: 4px solid #007bff;">
			        ${data.description ? data.description.replace(/\n/g, '<br>') : "No description available."}
			    </p>
			    
			    
			    
			    <div class="analysis-actions">
			        <a href="${data.link}" target="_blank"><b>📈 View Full Analysis</b></a>
			        <button onclick="copyToClipboard('${data.link}')">📋 Copy Link</button>
			    </div>
			`;
			
			// Show Edit/Delete buttons only for the admin
			if (auth.currentUser && auth.currentUser.email === ADMIN_EMAIL) {
				listItem.innerHTML += `
										<div class="admin-actions">
										  <button onclick="editFullAnalysis('${docId}')">✏️ Edit</button>
										  <button onclick="deleteAnalysis('${docId}')">🗑️ Delete</button>
										</div>
                `;
			}
			
			analysisList.appendChild(listItem);
		});
		
		// ✅ Update Badge for Real-Time Notifications (Red Dot + Count)
		//if (count > 0) {
			//badge.textContent = `🔴 (${count})`; // Example: 🔴 (3)
			//badge.classList.remove("hidden"); // Show badge
		//} else {
			//badge.classList.add("hidden"); // Hide badge if no new updates
	//}
		
		console.log("✅ Real-Time Analysis Data Loaded with Badge Updates");
	});
}

document.getElementById("analysisSearchInput").addEventListener("input", function() {
	const keyword = this.value.toLowerCase();
	const allItems = document.querySelectorAll("#analysisList .analysis-item");
	
	allItems.forEach(item => {
		const text = item.textContent.toLowerCase();
		item.style.display = text.includes(keyword) ? "block" : "none";
	});
});

async function updateAllAnalysisLink() {
	const link = document.getElementById("updateAllAnalysisLinkInput").value.trim();
	if (!link) return alert("Please enter a valid link.");
	
	try {
		await setDoc(doc(db, "settings", "analysis_link"), { link }, { merge: true });
		alert("✅ Link updated!");
		document.getElementById("allAnalysisLink").href = link;
	} catch (err) {
		console.error("❌ Error updating analysis link:", err);
	}
}

// ✅ Make it callable from HTML
window.updateAllAnalysisLink = updateAllAnalysisLink;

async function loadAllAnalysisLink() {
	try {
		const snap = await getDoc(doc(db, "settings", "analysis_link"));
		if (snap.exists()) {
			const link = snap.data().link;
			document.getElementById("allAnalysisLink").href = link;
		}
	} catch (e) {
		console.warn("⚠️ Failed to load analysis link");
	}
}
window.addEventListener("DOMContentLoaded", loadAllAnalysisLink);

// ✅ Open Image in Fullscreen Modal
window.zoomImage = function zoomImage(imageSrc) {
	const modal = document.getElementById("imageZoomModal");
	const zoomedImage = document.getElementById("zoomedImage");
	
	if (!modal || !zoomedImage) {
		console.error("🚨 Image Zoom Modal elements not found!");
		return;
	}
	
	zoomedImage.src = imageSrc;
	modal.classList.remove("hidden"); // ✅ Better than inline styles
	modal.style.display = "flex"; // Ensure it's visible
};

window.closeZoom = function() {
	const modal = document.getElementById("imageZoomModal");
	if (modal) {
		modal.classList.add("hidden"); // Hide modal
		modal.style.display = "none";
	}
};

////////Analysis notification /////
//const notificationSoundUrl = "https://raw.githubusercontent.com/ps7703/ps/main/notification3.mp3";
//let audio = null; // Declare but don't initialize yet

let audio; // 🔹 Define audio globally

document.addEventListener("click", async () => {
	if (!audio) {
		const soundUrl = await getSelectedSoundUrl(); // 🔹 Get sound based on toggle preference
		audio = new Audio(soundUrl); // 🔹 Initialize audio with correct sound
		audio.preload = "auto"; // 🔹 Preload audio
	}
	
	audio.play().catch(() => console.warn("🔇 Autoplay blocked, waiting for event"));
}, { once: true });

// ✅ Get the correct sound URL based on the toggle switch
async function getSelectedSoundUrl() {
	const sounds = await getNotificationSounds(); // 🔹 Fetch available sounds
	const selectedSound = await applyUserPreference(); // 🔹 Check which sound is selected
	return selectedSound === "sound1" ? sounds.sound1 : sounds.sound2;
}



// ✅ Play MP3 Sound from GitHub using Fetch (For Trade Analysis)
function notifyNewAnalysis() {
	playNotificationSound(); // 🔹 Use updated sound function
}

//Option 2: Direct URL(Might Not Work on Some Browsers)Some browsers may block direct playback due to GitHub’ s CORS policy.But you can try:  //
//function notifyNewAnalysis() {
    //const audio = new Audio("https://raw.githubusercontent.com/ps7703/ps/main/notification3.mp3");
    //audio.play().catch(error => console.error("Error playing audio:", error));
//}

// ✅ Load Analysis on Page Load
loadAnalysis();!


//import { getAuth, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.10.0/firebase-auth.js";

//const auth = getAuth();
onAuthStateChanged(auth, (user) => {
	if (user && user.email === ADMIN_EMAIL) {
		console.log("✅ Admin detected:", user.email);
		// Show admin control button so admin can click to reveal controls.
		document.getElementById("adminAnalysisControlButton").style.display = "block";
	} else {
		console.log("🚫 Not an admin:", user ? user.email : "No user logged in");
		// Hide or disable the admin control button for non-admin users.
		document.getElementById("adminAnalysisControlButton").style.display = "none";
	}
})


///////////////// Analysis Panel ENDS HERE ///////////////// 

///////////////// 📌 Function to Update Latest Version STARTS HERE ///////////////// 
//const password = secretKey; // Change this
//const password = "your_secure_password"; // Change this to your actual admin password
// Attach functions to window so they are accessible in HTML
window.updateFirestore = updateFirestore;
window.applyLatestUpdate = applyLatestUpdate;
window.restoreVersion = restoreVersion;
window.deleteVersion = deleteVersion;

// ✅ Function to Get Admin Password Before Any Action
function getsecretKey() {
	let passwordInput = prompt("Enter Admin Password:");
	return passwordInput === secretKey;
}

// ✅ Update Firestore (Save New Update)
async function updateFirestore() {
	if (!getsecretKey()) { // Fixed function name here
		alert("❌ Incorrect Password! Update Canceled.");
		return;
	}
	
	let newHtml = document.getElementById("newHtml").value;
	let newCss = document.getElementById("newCss").value;
	let newJs = document.getElementById("newJs").value;
	let timestamp = new Date();
	
	let updatesRef = db.collection("updates");
	
	// Save old version to history before updating
	let latestDoc = await updatesRef.doc("latest").get();
	if (latestDoc.exists) {
		await updatesRef.doc("latest").collection("history").add(latestDoc.data());
	}
	
	// Update to latest version
	await updatesRef.doc("latest").set({ html: newHtml, css: newCss, js: newJs, timestamp });
	alert("✅ Update successful!");
	loadUpdateHistory(); // Refresh history
}

// ✅ Restore a Previous Version
async function restoreVersion() {
	let selectedVersion = document.querySelector('input[name="version"]:checked');
	if (!selectedVersion) {
		alert("❌ Please select a version to restore!");
		return;
	}
	
	if (!getsecretKey()) {
		alert("❌ Incorrect Password! Restore Canceled.");
		return;
	}
	
	let historyRef = db.collection("updates").doc("latest").collection("history").doc(selectedVersion.value);
	let docSnapshot = await historyRef.get();
	
	if (docSnapshot.exists) {
		await db.collection("updates").doc("latest").set(docSnapshot.data());
		alert("✅ Version Restored!");
		loadUpdateHistory();
	}
}

// ✅ Apply Latest Update (Manually Trigger)
async function applyLatestUpdate() {
	if (!getsecretKey()) {
		alert("❌ Incorrect Password! Action Canceled.");
		return;
	}
	
	await loadLatestUpdate();
	alert("✅ Latest Update Applied!");
}

// ✅ Delete a Selected Version
async function deleteVersion() {
	let selectedVersion = document.querySelector('input[name="version"]:checked');
	if (!selectedVersion) {
		alert("❌ Please select a version to delete!");
		return;
	}
	
	if (!getsecretKey()) {
		alert("❌ Incorrect Password! Delete Canceled.");
		return;
	}
	
	await db.collection("updates").doc("latest").collection("history").doc(selectedVersion.value).delete();
	alert("✅ Version Deleted!");
	loadUpdateHistory();
}

// Toggle Admin Update Panel Section
document.getElementById("toggle-admin-update").addEventListener("click", function() {
	const adminUpdateContainer = document.getElementById("admin-update-container");
	adminUpdateContainer.style.display = adminUpdateContainer.style.display === "none" || adminUpdateContainer.style.display === "" ? "block" : "none";
});

///////////////// 📌 Function to Update Latest Version ENDS HERE ///////////////// 

/////////////////you can manually copy new users inside your sign-up logic. STARTS HERE ///////////////// 
//import { setDoc, doc, getDoc } from "firebase/firestore";

// Call this function after a new user is added to "users"
//async function syncNewUserToUsers1(userId) {
    //const userRef = doc(db, "users", userId);
    //const userSnap = await getDoc(userRef);

    //if (userSnap.exists()) {
        //const userData = userSnap.data();
        //await setDoc(doc(db, "users1", userId), userData);
        //console.log(`✅ New user ${userId} copied to users1`);
    //}
//}
/////////////////you can manually copy new users inside your sign-up logic. ENDS HERE ///////////////// 



/////////////////duplicate all documents from users into users1 in Firestore. STARTS HERE ///////////////// 
//import { getDocs, collection, doc, setDoc } from "firebase/firestore";

async function duplicateUsersCollection() {
	const usersSnapshot = await getDocs(collection(db, "users1")); // Get all users from "users"
	
	usersSnapshot.forEach(async (userDoc) => {
		const userData = userDoc.data();
		const userId = userDoc.id;
		
		// Copy data to "users1"
		await setDoc(doc(db, "users1", userId), userData);
		console.log(`✅ Copied user ${userId} to users1`);
	});
	
	console.log("✅ All users copied from 'users' to 'users1'");
}

// Run this function once to create users1
duplicateUsersCollection();





/////////////////duplicate all documents from users into users1 in Firestore. ENDS HERE ///////////////// 




///////////////// STARTS HERE ///////////////// 

///////////////// One-time migration script (run once to copy data from users to users1)ENDS HERE ///////////////// 

async function migrateUsersToUsers1() {
    const usersRef = collection(db, "users");
    const users1Ref = collection(db, "users1");

    const querySnapshot = await getDocs(usersRef);

    querySnapshot.forEach(async (docSnap) => {
        const userData = docSnap.data();
        const userId = docSnap.id;

        // Copy user data to users1 (excluding premium request data)
        await setDoc(doc(users1Ref, userId), {
            email: userData.email || "Unknown User",
            premiumAccess: {} // Reset access (admin will manually grant access via switches)
        });

        console.log(`✅ Copied user: ${userId} to users1`);
    });
}




///////////////// One-time migration script (run once to copy data from users to users1)STARTS HERE ///////////////// 




///////////////// ENDS HERE ///////////////// 

/////////////////Inform Users When Their Premium Access Expires STARTS HERE ///////////////// 

function showPremiumExpiryMessage() {
    const user = auth.currentUser;
    if (!user) return;

    const userRef = doc(db, "users", user.uid);
    getDoc(userRef).then(userDoc => {
        if (userDoc.exists()) {
            let userData = userDoc.data();
            let premiumAccess = userData.premiumAccess || {};
            let currentTime = new Date().toISOString();

            Object.keys(premiumAccess).forEach(category => {
                if (premiumAccess[category].status && premiumAccess[category].expiresOn < currentTime) {
                    alert(`⚠️ Your premium access for ${category} has expired.`);
                }
            });
        }
    });
}

// 🔹 Run when user opens settings
document.getElementById("settings-button").addEventListener("click", showPremiumExpiryMessage);




/////////////////Inform Users When Their Premium Access Expires ENDS HERE ///////////////// 

/////////////////JavaScript to Remove Expired Access to check expiry on page load & refresh: STARTS HERE ///////////////// 
//Optimize premium expiry check
function checkPremiumExpiry() {
	const user = auth.currentUser;
	if (!user) return;
	
	const userRef = doc(db, "users", user.uid);
	getDoc(userRef).then(userDoc => {
		if (userDoc.exists()) {
			let userData = userDoc.data();
			let premiumAccess = userData.premiumAccess || {};
			let currentTime = new Date().toISOString();
			
			let updatedPremiumAccess = {};
			let accessChanged = false;
			
			Object.keys(premiumAccess).forEach(category => {
				if (premiumAccess[category].status && premiumAccess[category].expiresOn) {
					if (premiumAccess[category].expiresOn < currentTime) {
						updatedPremiumAccess[category] = { status: false, expiresOn: premiumAccess[category].expiresOn };
						accessChanged = true;
					} else {
						updatedPremiumAccess[category] = premiumAccess[category];
					}
				}
			});
			
			if (accessChanged) {
				updateDoc(userRef, { premiumAccess: updatedPremiumAccess });
				console.log("✅ Expired premium access removed.");
			}
		}
	}).catch(error => {
		console.error("❌ Error checking premium expiry:", error);
	});
}

// 🔹 Run check on page load
document.addEventListener("DOMContentLoaded", checkPremiumExpiry);



/////////////////JavaScript to Remove Expired Access to check expiry on page load & refresh: ENDS HERE ///////////////// 


///////////////// to Lock/Unlock Trades Based on SL/T1/T2/T3 STARTS HERE ///////////////// 



//import { db, auth } from "./firebaseConfig.js";
//import { doc, getDoc, updateDoc, onSnapshot } from "https://www.gstatic.com/firebasejs/10.10.0/firebase-firestore.js";

// 🔹 Lock Trades by Default & Unlock when SL/T1/T2/T3 is Toggled
//Optimize trade looking code


document.querySelectorAll(".trade-card").forEach(trade => {
    const tradeId = trade.getAttribute("data-id");
    if (!tradeId) {
        console.warn("⚠️ Trade card is missing tradeId:", trade);
        return;
    }
});


async function updateGlobalLock(category, newLockState) {
    const password = prompt("Enter admin password:");
    if (password !== secretKey) { // Correct comparison
        alert("❌ Incorrect password!");
        return;
    }

    try {
        const tradeLockRef = doc(db, "tradeSettings", "visibility");
        await updateDoc(tradeLockRef, { [category]: newLockState });

        console.log(`✅ Global lock updated → ${category}: ${newLockState ? "LOCKED" : "UNLOCKED"}`);
    } catch (error) {
        console.error("❌ Error updating global lock:", error);
    }
}

async function toggleTarget(tradeId, targetKey) {
    try {
        const tradeRef = doc(db, "trades", tradeId);
        const tradeSnap = await getDoc(tradeRef);

        if (!tradeSnap.exists()) {
            console.error("❌ Trade not found in Firestore.");
            return;
        }

        const tradeData = tradeSnap.data();
        const newToggleState = !tradeData[targetKey]; // Toggle SL/T1/T2/T3 state

        // ✅ If any target is toggled, unlock Trade Action & Entry Price
        const updatedData = {
            [targetKey]: newToggleState,
        };

        if (newToggleState) {
            updatedData.tradeUnlocked = true; // ✅ Unlock trade action & entry price
        }

        // ✅ Update Firestore
        await updateDoc(tradeRef, updatedData);

        console.log(`✅ ${targetKey} toggled to ${newToggleState}, Trade Action & Entry Price updated.`);
        
        // ✅ Refresh UI instantly
        checkTradeLocking();
    } catch (error) {
        console.error("❌ Error toggling target:", error);
    }
}


async function checkTradeLocking() {
	console.log("🔄 Checking trade locking status...");
	
	const user = auth.currentUser;
	if (!user) {
		console.warn("⚠️ User is not logged in. Cannot check trade access.");
		return;
	}
	
	try {
		const isAdmin = await checkIfAdmin(user);
		console.log(`🔍 Admin Check → ${isAdmin ? "✅ Yes (Full Access)" : "❌ No"}`);
		
		const tradeLockRef = doc(db, "tradeSettings", "visibility");
		const tradeLockSnap = await getDoc(tradeLockRef);
		const tradeLocks = tradeLockSnap.exists() ? tradeLockSnap.data() : {};
		
		const userEmail = user.email.toLowerCase();
		const userQuery = query(collection(db, "users1"), where("email", "==", userEmail));
		const userSnap = await getDocs(userQuery);
		
		if (userSnap.empty) {
			console.error("❌ User document not found in users1!");
			return;
		}
		
		const userData = userSnap.docs[0].data();
		const userPremiumAccess = userData?.premiumAccess || {};
		
		document.querySelectorAll(".trade-card").forEach((tradeCard) => {
			const category = tradeCard.getAttribute("data-category");
			const tradeId = tradeCard.id;
			const tradeDetails = tradeCard.querySelector(".trade-details");
			const lockedMessage = tradeCard.querySelector(".trade-locked-message");
			
			const isCategoryGloballyUnlocked = !tradeLocks[category]; // Global unlock
			const hasCategoryAccess = userPremiumAccess?.[category]?.status === true; // Premium access
			
			// ✅ Listen for real-time updates on this trade
			const tradeRef = doc(db, "trades", tradeId);
			onSnapshot(tradeRef, (tradeSnap) => {
				if (!tradeSnap.exists()) {
					console.warn(`⚠️ Trade document ${tradeId} not found in Firestore.`);
					return;
				}
				
				const tradeData = tradeSnap.data();
				const isTradeUnlocked = tradeData["stop-lossToggled"] || tradeData["target-1Toggled"] || tradeData["target-2Toggled"] || tradeData["target-3Toggled"];
				
				console.log(`🔹 Checking Trade Access → Category: ${category}`);
				console.log(`   🔹 Global Lock: ${!isCategoryGloballyUnlocked}, User Premium Access: ${hasCategoryAccess}, Trade Unlocked: ${isTradeUnlocked}`);
				
				// ✅ Unlock trade action & entry price if ANY target is toggled
				if (isTradeUnlocked) {
					updateDoc(tradeRef, { tradeUnlocked: true });
				}
				
				// ✅ Access Control Logic
				if (isAdmin || hasCategoryAccess || isCategoryGloballyUnlocked || isTradeUnlocked) {
					tradeCard.classList.remove("locked-trade");
					tradeDetails.style.display = "block";
					lockedMessage.style.display = "none";
					console.log(`✅ Trade ${tradeId} is UNLOCKED!`);
				} else {
					tradeCard.classList.add("locked-trade");
					tradeDetails.style.display = "none";
					lockedMessage.style.display = "block";
					console.log(`🔒 Trade ${tradeId} remains LOCKED.`);
				}
			});
		});
	} catch (error) {
		console.error("❌ Error in checkTradeLocking:", error);
	}
}

// ✅ Run trade access check on page load
document.addEventListener("DOMContentLoaded", checkTradeLocking);
window.checkTradeLocking = checkTradeLocking;




// 🔹 Listen for Trade Updates in Real Time
onSnapshot(doc(db, "tradeSettings", "visibility"), (docSnap) => {
	if (docSnap.exists()) {
		applyTradeLocking(docSnap.data());
	}
});

// 🔹 Ensure Admin Always Sees Unlocked Trades
auth.onAuthStateChanged(async (user) => {
	if (user) {
		const userRef = doc(db, "users", user.uid);
		const userDoc = await getDoc(userRef);
		
		if (userDoc.exists() && userDoc.data().role === "admin") {
			document.body.classList.add("admin-user");
		} else {
			document.body.classList.add("regular-user");
		}
	}
});

// 🔹 Apply Trade Locking Rules on Page Load
document.addEventListener("DOMContentLoaded", checkTradeLocking);

// 🔹 Ensure Admin Always Sees Unlocked Trades
auth.onAuthStateChanged(async (user) => {
	if (user) {
		const userRef = doc(db, "users", user.uid);
		const userDoc = await getDoc(userRef);
		
		if (userDoc.exists()) {
			const userRole = userDoc.data().role;
			const adminControls = document.getElementById("admin-controls");
			const premiumButton = document.getElementById("toggle-premium-panel");
			const premiumPanel = document.getElementById("premium-management");
			
			if (userRole === "admin") {
				console.log("✅ Admin detected. Showing Admin Controls.");
				if (adminControls) adminControls.classList.remove("hidden"); // Show Admin Panel
				if (premiumButton) premiumButton.classList.remove("hidden"); // Show Manage Premium Button
				if (premiumPanel) premiumPanel.classList.remove("hidden"); // Show Premium Management Panel
			} else {
				console.log("❌ Regular user detected. Hiding Admin Controls.");
				if (adminControls) adminControls.classList.add("hidden"); // Hide Admin Panel
				if (premiumButton) premiumButton.classList.add("hidden"); // Hide Button
				if (premiumPanel) premiumPanel.classList.add("hidden"); // Hide Premium Panel
			}
		}
	}
});

document.addEventListener("DOMContentLoaded", async function() {
	console.log("🚀 Initializing trade locking system...");
	
	const lockStatusElements = {
		"all": document.getElementById("lock-status-all"),
		"others": document.getElementById("lock-status-others"),
		"index-views": document.getElementById("lock-status-index-views"),
		"index-options": document.getElementById("lock-status-index-options"),
		"stock-views": document.getElementById("lock-status-stock-views"),
		"stock-options": document.getElementById("lock-status-stock-options"),
		"futures-views": document.getElementById("lock-status-futures-views"),
		"crypto-views": document.getElementById("lock-status-crypto-views"),
		"forex-views": document.getElementById("lock-status-forex-views"),
	};
	
	const tradeLockRef = doc(db, "tradeSettings", "visibility");
	
	// ✅ Ensure All Categories Are Locked by Default if Not Set
	async function ensureAllLocked() {
		const tradeLockDoc = await getDoc(tradeLockRef);
		if (!tradeLockDoc.exists()) {
			const defaultLockState = {};
			Object.keys(lockStatusElements).forEach(category => {
				
				defaultLockState[category] = true; // Default: All categories locked

			});
			
			await setDoc(tradeLockRef, defaultLockState);
			console.log("✅ All categories are now locked by default.");
		}
	}
	
	await ensureAllLocked(); // Run this check on page load
	
	// ✅ Fetch & Apply Lock Status from Firestore
	async function fetchAndApplyLockStatus() {
		const tradeLockDoc = await getDoc(tradeLockRef);
		let currentLocks = tradeLockDoc.exists() ? tradeLockDoc.data() : {};
		
		Object.keys(lockStatusElements).forEach(category => {
			updateLockStatusUI(category, currentLocks[category]);
		});
		
		return currentLocks;
	}
	
	let currentLocks = await fetchAndApplyLockStatus();
	
	// ✅ Listen for Real-time Firestore Updates (Auto Sync)
	onSnapshot(tradeLockRef, (docSnap) => {
		if (docSnap.exists()) {
			currentLocks = docSnap.data();
			console.log("📌 Live Update: Trade Locks Changed →", currentLocks);
			
			Object.keys(lockStatusElements).forEach(category => {
				updateLockStatusUI(category, currentLocks[category]);
			});
			
			// ✅ Reapply trade locking logic instantly
			checkTradeLocking();
		}
	});
	
	// ✅ Admin Toggle Buttons for Locking Categories
	// ✅ Admin Toggle Buttons for Locking Categories
	document.querySelectorAll(".lock-toggle-btn").forEach(button => {
		button.addEventListener("click", async function() {
			const category = this.getAttribute("data-category");
			const password = prompt("🔑 Enter Admin Password:");
			if (!password || password !== secretKey) {
				alert("❌ Incorrect password!");
				return;
			}
	
			// ✅ Fetch current lock status
			const tradeLockDoc = await getDoc(tradeLockRef);
			let currentLocks = tradeLockDoc.exists() ? tradeLockDoc.data() : {};
	
			// ✅ Toggle lock state for the selected category
			const newLockState = !currentLocks[category];
			currentLocks[category] = newLockState;
	
			// ✅ Update Firestore with new lock state
			await updateDoc(tradeLockRef, currentLocks);
	
			alert(`✅ Trades for ${category} are now ${newLockState ? "LOCKED" : "UNLOCKED"}`);
	
			// ✅ Apply trade locking logic again to reflect changes
			checkTradeLocking();
		});
	});
	
	// ✅ Function to Update Lock Status UI Instantly
	function updateLockStatusUI(category, isLocked) {
		if (lockStatusElements[category]) {
			lockStatusElements[category].textContent = isLocked ? "🔒 Locked" : "🔓 Unlocked";
		}
	}
});

///////////////// to Lock/Unlock Trades Based on SL/T1/T2/T3 ENDS HERE ///////////////// 

///////////////// Lock / unlock trades in firestore STARTS HERE ///////////////// 
//import { db, auth } from "./firebaseConfig.js";
//import { doc, updateDoc, getDoc } from "https://www.gstatic.com/firebasejs/10.10.0/firebase-firestore.js";

// 🔹 Lock/Unlock Trades
document.getElementById("lock-trades-btn").addEventListener("click", async () => {
    const category = document.getElementById("lock-trade-category").value;
    const password = prompt("Enter admin password to lock/unlock trades:");

    if (password !== secretKey) {  // Use the actual secretKey constant or variable here
        alert("❌ Incorrect password!");
        return;
    }

    const tradeLockRef = doc(db, "tradeSettings", "visibility");
    const tradeLockDoc = await getDoc(tradeLockRef);
    let currentLocks = tradeLockDoc.exists() ? tradeLockDoc.data() : {};

    // Toggle lock state
    const newLockState = !currentLocks[category];
    currentLocks[category] = newLockState;

    await updateDoc(tradeLockRef, currentLocks);
    alert(`✅ Trades for ${category} are now ${newLockState ? "LOCKED" : "UNLOCKED"}`);
});
// 🔹 Apply Locking for Users
async function applyTradeLocking() {
	try {
		const tradeLockRef = doc(db, "tradeSettings", "visibility");
		
		// Listen for real-time updates instead of fetching once
		onSnapshot(tradeLockRef, (docSnap) => {
			if (docSnap.exists()) {
				const lockData = docSnap.data();
				document.querySelectorAll(".trade-card").forEach((trade) => {
					const category = trade.getAttribute("data-category");
					
					if (lockData[category]) {
						trade.classList.add("locked-trade");
					} else {
						trade.classList.remove("locked-trade");
					}
				});
			} else {
				console.warn("⚠️ No trade lock settings found in Firestore.");
			}
		});
	} catch (error) {
		console.error("❌ Error applying trade locking:", error);
	}
}






///////////////// Lock / unlock trades in firestore ENDS HERE ///////////////// 

/////////////////(Lock Trades for Non-Premium Users) STARTS HERE ///////////////// 

//import { db, auth } from "./firebaseConfig.js";
//import { doc, getDoc } from "https://www.gstatic.com/firebasejs/10.10.0/firebase-firestore.js";

// 🔹 Check if User is Premium
async function checkPremiumAccess() {
    const user = auth.currentUser;
    if (!user) return;

    const userDoc = await getDoc(doc(db, "users", user.uid));
    const userData = userDoc.exists() ? userDoc.data() : null;

    if (userData && userData.premiumAccess) {
        document.body.classList.add("premium-user");
        document.body.classList.remove("free-user");
    } else {
        document.body.classList.add("free-user");
        document.body.classList.remove("premium-user");
    }
}

// 🔹 Run Check on Page Load
document.addEventListener("DOMContentLoaded", checkPremiumAccess);







/////////////////(Lock Trades for Non-Premium Users) ENDS HERE ///////////////// 



///////////////// show or hide premium panel STARTS HERE ///////////////// 
// 🔹 Toggle Premium Management Panel
document.addEventListener("DOMContentLoaded", function() {
	const premiumButton = document.getElementById("toggle-premium-panel");
	const premiumPanel = document.getElementById("premium-management");
	const closeButton = document.getElementById("close-premium-panel");
	
	if (!premiumButton || !premiumPanel) {
		console.error("❌ Button or Panel NOT found! Check IDs in HTML.");
		return;
	}
	
	console.log("✅ Premium Button & Panel Found");
	
	// Toggle panel when clicking the "Manage Premium" button
	premiumButton.addEventListener("click", function(event) {
		event.stopPropagation();
		premiumPanel.classList.toggle("hidden");
		
		if (!premiumPanel.classList.contains("hidden")) {
			console.log("✅ Premium Panel OPENED");
		} else {
			console.log("❌ Premium Panel CLOSED");
		}
	});
	
	// Close panel when clicking the close button
	if (closeButton) {
		closeButton.addEventListener("click", function() {
			premiumPanel.classList.add("hidden");
			console.log("❌ Premium Panel CLOSED by Close Button");
		});
	}
	
	// Close panel when clicking outside of it
	document.addEventListener("click", function(event) {
		if (!premiumPanel.contains(event.target) && event.target !== premiumButton) {
			premiumPanel.classList.add("hidden");
			console.log("❌ Premium Panel CLOSED by Clicking Outside");
		}
	});
});
///////////////// show or hide premium panel ENDS HERE ///////////////// 



/////////////////(Admin Panel Logic for Premium Management) STARTS HERE ///////////////// 

//import { db, auth } from "./firebaseConfig.js";
//import { collection, getDocs, doc, updateDoc, deleteDoc, setDoc } from "https://www.gstatic.com/firebasejs/10.10.0/firebase-firestore.js";

// 🔹 Load Pending Premium Requests for Admin
//import { db } from "./firebaseConfig.js";
//import { collection, getDocs, doc, updateDoc, deleteDoc, setDoc } from "https://www.gstatic.com/firebasejs/10.10.0/firebase-firestore.js";

// 🔹 Load Pending Premium Requests
async function loadPremiumRequests() {
	const querySnapshot = await getDocs(collection(db, "premiumRequests"));
	const requestList = document.getElementById("premium-requests-list");
	requestList.innerHTML = "";
	
	querySnapshot.forEach((docData) => {
		const data = docData.data();
		if (data.status === "pending") {
			if (!data.userId || !data.category) {
				console.error("❌ Missing userId or category for request:", docData.id);
				return; // Skip this request if data is incomplete
			}
			
			const requestItem = document.createElement("li");
			requestItem.innerHTML = `
                <span>📌 <strong>${data.email}</strong> requested <strong>${data.category}</strong> for <strong>${data.duration}</strong> (₹${data.price})</span>
                <button class="approve-btn" data-id="${docData.id}" data-user="${data.userId}" data-category="${data.category}" data-duration="${data.duration}">✅ Approve</button>
                <button class="deny-btn" data-id="${docData.id}" data-user="${data.userId}" data-category="${data.category}">❌ Deny</button>
            `;
			requestList.appendChild(requestItem);
		}
	});
	
	// ✅ Add event listeners after creating buttons
	//Optimize event handling
	document.getElementById("premium-requests-list").addEventListener("click", function(event) {
		if (event.target.classList.contains("approve-btn")) {
			approvePremium(event);
		} else if (event.target.classList.contains("deny-btn")) {
			denyPremium(event);
		}
	});
}

async function approvePremium(event) {
	try {
		const button = event.target;
		
		// ✅ Prevent multiple clicks
		if (button.disabled) return;
		button.disabled = true;
		
		const requestId = button.getAttribute("data-id");
		const userId = button.getAttribute("data-user");
		const category = button.getAttribute("data-category");
		const duration = button.getAttribute("data-duration");
		
		if (!requestId || !userId || !category || !duration) {
			console.error("❌ Missing data attributes.");
			button.disabled = false;
			return alert("Error: Missing data. Please try again.");
		}
		
		// ✅ Ask for the password only once per session
		if (!window.sessionPassword) {
			window.sessionPassword = prompt("Enter admin password to approve:");
			if (window.sessionPassword !== secretKey) {
				button.disabled = false;
				window.sessionPassword = null;
				return alert("❌ Incorrect password!");
			}
		}
		
		const expiryDate = calculateExpiryDate(duration);
		const userRef = doc(db, "users", userId);
		
		await setDoc(userRef, {
			[`premiumAccess.${category}`]: { status: true, expiresOn: expiryDate }
		}, { merge: true });
		
		await updateDoc(userRef, {
			notifications: arrayUnion({
				message: `✅ Your premium request for ${category} (${duration}) has been approved!`,
				timestamp: new Date().toISOString(),
				read: false
			})
		});
		
		await updateDoc(doc(db, "premiumRequests", requestId), { status: "approved" });
		
		alert("✅ Premium access granted.");
		
		setTimeout(() => {
			window.sessionPassword = null; // Reset for next time
			loadPremiumRequests();
		}, 500);
		
	} catch (error) {
		console.error("❌ Error in approvePremium:", error);
		alert("An error occurred while approving the request. Please try again.");
		button.disabled = false;
	}
}

async function denyPremium(event) {
	try {
		const button = event.target;
		
		// ✅ Prevent multiple clicks
		if (button.disabled) return;
		button.disabled = true;
		
		const requestId = button.getAttribute("data-id");
		const userId = button.getAttribute("data-user");
		const category = button.getAttribute("data-category");
		
		if (!requestId || !userId || !category) {
			console.error("❌ Missing data attributes.");
			button.disabled = false;
			return alert("Error: Missing data. Please try again.");
		}
		
		// ✅ Ask for the password only once per session
		if (!window.sessionPassword) {
			window.sessionPassword = prompt("Enter admin password to deny:");
			if (window.sessionPassword !== secretKey) {
				button.disabled = false;
				window.sessionPassword = null;
				return alert("❌ Incorrect password!");
			}
		}
		
		const userRef = doc(db, "users", userId);
		await updateDoc(userRef, {
			notifications: arrayUnion({
				message: `❌ Your premium request for ${category} has been denied.`,
				timestamp: new Date().toISOString(),
				read: false
			})
		});
		
		await updateDoc(doc(db, "premiumRequests", requestId), { status: "denied" });
		
		alert("❌ Premium request denied.");
		
		setTimeout(() => {
			window.sessionPassword = null;
			loadPremiumRequests();
		}, 500);
		
	} catch (error) {
		console.error("❌ Error in denyPremium:", error);
		alert("An error occurred while denying the request. Please try again.");
		button.disabled = false;
	}
}

async function loadRequestNotifications() {
	const user = auth.currentUser;
	if (!user) return;
	
	const userRef = doc(db, "users", user.uid);
	const userDoc = await getDoc(userRef);
	if (!userDoc.exists()) return;
	
	const notifications = userDoc.data().notifications || [];
	const requestNotificationList = document.getElementById("request-notification-list");
	const requestNotificationBadge = document.getElementById("request-notification-badge");
	
	requestNotificationList.innerHTML = "";
	let unreadCount = 0;
	
	notifications.forEach(notification => {
		const listItem = document.createElement("li");
		listItem.textContent = notification.message;
		requestNotificationList.appendChild(listItem);
		
		if (!notification.read) unreadCount++;
	});
	
	// 🔹 Show or hide the red notification badge
	if (unreadCount > 0) {
		requestNotificationBadge.classList.remove("hidden");
	} else {
		requestNotificationBadge.classList.add("hidden");
	}
}

// 🔹 Load premium request notifications when settings open
document.getElementById("settings-button").addEventListener("click", loadRequestNotifications);

document.getElementById("clear-request-notifications").addEventListener("click", async () => {
    const user = auth.currentUser;
    if (!user) return;

    const userRef = doc(db, "users", user.uid);
    await updateDoc(userRef, { notifications: [] });

    alert("✅ Premium request notifications cleared!");
    loadRequestNotifications();
});

// 🔹 Load Premium Users List for Admin
async function loadPremiumUsers() {
	const usersList = document.getElementById("premium-users-list");
	usersList.innerHTML = "<tr><td>Loading...</td></tr>";
	
	const querySnapshot = await getDocs(collection(db, "users1")); // ✅ Fetch from `users1`
	
	usersList.innerHTML = ""; // Clear previous entries
	
	// ✅ Add Table Headers (Now Includes "Number" Column)
	usersList.innerHTML = `
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Phone Number</th>
            <th>All</th>
            <th>Others</th>
            <th>Index Views</th>
            <th>Index Options</th>
            <th>Stock Views</th>
            <th>Stock Options</th>
            <th>Futures Views</th>
            <th>Crypto Views</th>
            <th>Forex Views</th>
            <th>Action</th>
        </tr>
    `;
	
	querySnapshot.forEach((doc) => {
		const userData = doc.data();
		const userName = userData.name || "Unknown"; // ✅ Fetch Name
		const userEmail = userData.email || "Unknown User"; // ✅ Fetch Email
		const userPhone = userData.phone || "No Number"; // ✅ Fetch Phone Number
		const userId = doc.id;
		
		console.log(`👤 Adding user: ${userName} | ${userEmail} | ${userPhone} (ID: ${userId})`);
		
		const row = document.createElement("tr");
		
		row.innerHTML = `
            <td><strong>${userName}</strong></td>
            <td><strong>${userEmail}</strong></td>
            <td><strong>${userPhone}</strong></td>
            ${createSwitch(userId, "all", userData.premiumAccess?.["all"]?.status || false)}
            ${createSwitch(userId, "others", userData.premiumAccess?.["others"]?.status || false)}
            ${createSwitch(userId, "index-views", userData.premiumAccess?.["index-views"]?.status || false)}
            ${createSwitch(userId, "index-options", userData.premiumAccess?.["index-options"]?.status || false)}
            ${createSwitch(userId, "stock-views", userData.premiumAccess?.["stock-views"]?.status || false)}
            ${createSwitch(userId, "stock-options", userData.premiumAccess?.["stock-options"]?.status || false)}
            ${createSwitch(userId, "futures-views", userData.premiumAccess?.["futures-views"]?.status || false)}
            ${createSwitch(userId, "crypto-views", userData.premiumAccess?.["crypto-views"]?.status || false)}
            ${createSwitch(userId, "forex-views", userData.premiumAccess?.["forex-views"]?.status || false)}
            <td><button class="remove-btn" onclick="removePremiumUser('${userId}')">❌ Remove</button></td>
        `;
		
		usersList.appendChild(row);
	});
	
	// ✅ Attach Event Listeners for Switches
	document.querySelectorAll(".category-switch").forEach(switchElem => {
		switchElem.addEventListener("change", updateUserPremiumAccess);
	});
	
	console.log("✅ Premium Users List Loaded with Name, Email & Phone.");
}

// ✅ Function to Create Switch Elements with Proper Alignment
function createSwitch(userId, category, isChecked) {
	return `
        <td>
            <label class="switch">
                <input type="checkbox" ${isChecked ? "checked" : ""} data-user="${userId}" data-category="${category}" class="category-switch">
                <span class="slider round"></span>
            </label>
        </td>
    `;
}

// 🔄 Reload Users Button - Calls loadPremiumUsers() again
document.getElementById("reload-users-btn").addEventListener("click", () => {
	console.log("🔄 Reloading premium users...");
	loadPremiumUsers();
});

// 🔹 Update User's Premium Access When Toggle is Changed
async function updateUserPremiumAccess(event) {
    event.stopPropagation();

    const switchElement = event.target;
    const userId = switchElement.getAttribute("data-user"); 
    const category = switchElement.getAttribute("data-category");
    const isChecked = switchElement.checked;

    if (!userId) {
        console.error("❌ Error: User ID is missing!");
        alert("⚠️ Failed to update: User ID is missing.");
        return;
    }

    console.log(`🔄 Updating Premium Access: User=${userId}, Category=${category}, Status=${isChecked}`);

    const enteredPassword = prompt("Enter admin password:");
    if (enteredPassword !== secretKey) {
        alert("❌ Incorrect password!");
        return;
    }

    try {
        const user1Ref = doc(db, "users1", userId);
        await updateDoc(user1Ref, { [`premiumAccess.${category}.status`]: isChecked });
        console.log(`✅ Firestore Updated: users1 → ${category} access is now ${isChecked ? "GRANTED" : "REVOKED"}`);

        const userRef = doc(db, "users", userId);
        await updateDoc(userRef, { [`premiumAccess.${category}.status`]: isChecked });
        console.log(`✅ Firestore Updated: users → ${category} access is now ${isChecked ? "GRANTED" : "REVOKED"}`);

        checkTradeLocking();

    } catch (error) {
        console.error("❌ Error updating user premium access:", error);
        alert("⚠️ Failed to update user premium access.");
    }
}

// ✅ Attach event listener to switches dynamically
document.addEventListener("change", function(event) {
	if (event.target.classList.contains("category-switch")) {
		updateUserPremiumAccess(event);
	}
});

// ✅ Auto-load users when admin opens the panel
document.getElementById("admin-btn").addEventListener("click", () => {
	console.log("🔄 Loading premium users...");
	loadPremiumUsers();
});


async function togglePremium(userId, category, grantAccess) {
    const enteredPassword = prompt("Enter admin password:");
    if (enteredPassword !== secretKey) {
        return alert("❌ Incorrect password!");
    }

    await updateDoc(doc(db, "users", userId), {
        [`premiumAccess.${category}`]: { status: grantAccess }
    });

    alert(`✅ Premium ${grantAccess ? "granted" : "revoked"} for ${category}`);
    loadPremiumUsers();
}

// 🔹 Update Subscription Prices
document.getElementById("update-premium-price").addEventListener("click", async () => {
	const category = document.getElementById("admin-premium-category").value;
	const duration = document.getElementById("admin-premium-duration").value;
	const newPrice = parseInt(document.getElementById("new-premium-price").value);
	
	if (!category || !duration || isNaN(newPrice)) {
		alert("⚠️ Please select category, duration, and enter a valid price.");
		return;
	}
	
	try {
		const settingsRef = doc(db, "settings", "premiumPrices");
		const docSnap = await getDoc(settingsRef);
		let existingPrices = {};
		if (docSnap.exists()) {
			existingPrices = docSnap.data();
		}
		
		const existingCategoryPrices = existingPrices[category] || {};
		
		// Update the price
		existingCategoryPrices[duration] = newPrice;
		
		await setDoc(settingsRef, {
			[category]: existingCategoryPrices
		}, { merge: true });
		
		alert("✅ Price updated successfully!");
	} catch (error) {
		console.error("❌ Error updating subscription price:", error);
		alert("❌ Failed to update price.");
	}
});
// 🔹 Load Data When Admin Panel Opens
document.getElementById("admin-btn").addEventListener("click", () => {
    loadPremiumRequests();
    loadPremiumUsers();
});





/////////////////(Admin Panel Logic for Premium Management) ENDS HERE ///////////////// 

/////////////////(Handle Premium Requests & Tracking)Now, we will handle user requests and store them in Firestore. STARTS HERE ///////////////// 

//import { db, auth } from "./firebaseConfig.js";
//import { collection, addDoc, doc, updateDoc, getDocs, setDoc, serverTimestamp } from "https://www.gstatic.com/firebasejs/10.10.0/firebase-firestore.js";

// 🔹 Subscription Prices (Editable by Admin)
//const premiumPrices = {
    //"index-views": { "1-week": 100, "1-month": 350, "4-months": 1200, "6-months": 1700, "1-year": 3200 },
    //"index-options": { "1-week": 120, "1-month": 400, "4-months": 1400, "6-months": 2000, "1-year": 3800 },
    //"stock-views": { "1-week": 90, "1-month": 300, "4-months": 1000, "6-months": 1500, "1-year": 2800 },
    //"stock-options": { "1-week": 110, "1-month": 360, "4-months": 1250, "6-months": 1800, "1-year": 3400 },
    //"futures-views": { "1-week": 130, "1-month": 450, "4-months": 1600, "6-months": 2300, "1-year": 4200 },
    //"crypto-views": { "1-week": 80, "1-month": 280, "4-months": 950, "6-months": 1400, "1-year": 2600 },
    //"forex-views": { "1-week": 95, "1-month": 320, "4-months": 1100, "6-months": 1600, "1-year": 3000 },
    //"others": { "1-week": 50, "1-month": 180, "4-months": 600, "6-months": 900, "1-year": 1600 }
    
    
//};

//import {collection, addDoc, doc, getDoc, getDocs, serverTimestamp} from "https://www.gstatic.com/firebasejs/10.10.0/firebase-firestore.js";
//import { auth } from "./firebaseConfig.js"; // if not already imported

// 🔹 Update price dynamically from Firestore
document.getElementById("premium-category").addEventListener("change", updatePrice);
document.getElementById("premium-duration").addEventListener("change", updatePrice);

async function updatePrice() {
  const category = document.getElementById("premium-category").value;
  const duration = document.getElementById("premium-duration").value;

  if (!category || !duration) {
    document.getElementById("selected-price").textContent = "-";
    return;
  }

  try {
    const docRef = doc(db, "settings", "premiumPrices");
    const docSnap = await getDoc(docRef);

    if (docSnap.exists()) {
      const prices = docSnap.data();
      const price = prices[category]?.[duration] ?? "-";
      document.getElementById("selected-price").textContent = price === "-" ? "-" : `₹${price}`;
    } else {
      document.getElementById("selected-price").textContent = "-";
    }
  } catch (error) {
    console.error("❌ Error fetching price:", error);
    document.getElementById("selected-price").textContent = "-";
  }
}

// 🔹 Handle Premium Request
document.getElementById("request-premium").addEventListener("click", async () => {
  const user = auth.currentUser;
  if (!user) return alert("You must be logged in to request premium access.");

  const category = document.getElementById("premium-category").value;
  const duration = document.getElementById("premium-duration").value;
  const priceText = document.getElementById("selected-price").textContent;

  if (!category || !duration || priceText === "-") {
    return alert("⚠️ Please select valid category, duration, and wait for price to load.");
  }

  const price = parseInt(priceText.replace("₹", ""));

  const expiryDate = calculateExpiryDate(duration);

  // 🔹 Save Request in Firestore
  try {
    await addDoc(collection(db, "premiumRequests"), {
      userId: user.uid,
      email: user.email,
      category,
      duration,
      price,
      requestTimestamp: serverTimestamp(),
      status: "pending"
    });

    alert("✅ Premium request submitted successfully!");
    loadPremiumStatus(); // Refresh request tracking
  } catch (error) {
    console.error("❌ Failed to send request:", error);
    alert("❌ Failed to send premium request.");
  }
});

// 🔹 Calculate Expiry Date
function calculateExpiryDate(duration) {
  const now = new Date();
  if (duration === "1-week") now.setDate(now.getDate() + 7);
  if (duration === "1-month") now.setMonth(now.getMonth() + 1);
  if (duration === "4-months") now.setMonth(now.getMonth() + 4);
  if (duration === "6-months") now.setMonth(now.getMonth() + 6);
  if (duration === "1-year") now.setFullYear(now.getFullYear() + 1);
  return now.toISOString();
}

// 🔹 Load Premium Status
async function loadPremiumStatus() {
  const user = auth.currentUser;
  if (!user) return;

  const querySnapshot = await getDocs(collection(db, "premiumRequests"));
  const statusList = document.getElementById("premium-status-list");
  statusList.innerHTML = "";

  querySnapshot.forEach((doc) => {
    const data = doc.data();
    if (data.userId === user.uid) {
      const statusItem = document.createElement("li");
      statusItem.textContent = `📌 ${data.category} - ${data.duration} (${data.status})`;
      statusList.appendChild(statusItem);
    }
  });
}

document.getElementById("clear-premium-status").addEventListener("click", () => {
  document.getElementById("premium-status-list").innerHTML = "";
});

document.getElementById("settings-button").addEventListener("click", loadPremiumStatus);



///////////////// (Handle Premium Requests & Tracking)Now, we will handle user requests and store them in Firestore.ENDS HERE ///////////////// 








///////////////// Converted name into three buttons STARTS HERE ///////////////// 
//saving trade name


//fetching and displaying trade name
//import { getFirestore, doc, getDoc, collection } from "https://www.gstatic.com/firebasejs/10.10.0/firebase-firestore.js";

//fetching and displaying trade name
async function loadTradeDetails(tradeId) {
	const tradeRef = doc(db, "trades", tradeId);
	const docSnap = await getDoc(tradeRef);
	
	if (!docSnap.exists()) return;
	
	const { tradeAction, tradeAsset, tradeEntryPrice, chartLink } = docSnap.data();
	
	const tradeActionBtn = document.getElementById('trade-action-btn');
	const tradeAssetBtn = document.getElementById('trade-asset-btn');
	const tradeEntryBtn = document.getElementById('trade-entry-btn');
	const tradeChartLinkBtn = document.getElementById('trade-chart-link-btn'); // Add this if it's a button
	
	// Set button text
	tradeActionBtn.textContent = tradeAction !== "NONE" ? tradeAction : "";
	tradeAssetBtn.textContent = tradeAsset;
	tradeEntryBtn.textContent = tradeEntryPrice;
	
	// Hide trade action button if "NONE"
	tradeActionBtn.style.display = tradeAction === "NONE" ? "none" : "inline-block";
	
	// Handle Chart Link display
	if (tradeChartLinkBtn && chartLink) {
		tradeChartLinkBtn.style.display = "inline-block";
		tradeChartLinkBtn.onclick = () => window.open(chartLink, "_blank");
	} else if (tradeChartLinkBtn) {
		tradeChartLinkBtn.style.display = "none";
	}
}

// Ensure Firestore is initialized
//const db = getFirestore();

// Call function when trade loads
document.addEventListener('DOMContentLoaded', async () => {
	const latestTradeId = "latest_trade_id_here"; // Replace with actual trade ID
	await loadTradeDetails(latestTradeId);
});

//save all changes to firestore
async function saveTradeChanges(tradeId) {
	try {
		const tradeRef = doc(db, "trades", tradeId); // Reference to Firestore document
		
		const updatedTrade = {
			tradeAction: document.getElementById("trade-action-btn").textContent,
			tradeAsset: document.getElementById("trade-asset-btn").textContent,
			entryPrice: document.getElementById("trade-entry-btn").textContent,
			updatedAt: new Date()
		};
		
		await updateDoc(tradeRef, updatedTrade); // Save changes to Firestore
		console.log("✅ Trade updated successfully in Firestore!");
	} catch (error) {
		console.error("❌ Error updating trade in Firestore:", error);
		alert("⚠️ Failed to save trade changes.");
	}
}

//update trade action button styling & firestore
async function updateTradeAction(tradeId) {
    const verified = await verifyAdmin(); // Ensure admin authentication
    if (!verified) return;

    const action = prompt("Enter Trade Action (BUY / SELL / NONE):").toUpperCase();
    if (!["BUY", "SELL", "NONE"].includes(action)) {
        alert("❌ Invalid input! Use BUY, SELL, or NONE.");
        return;
    }

    const tradeActionBtn = document.getElementById("trade-action-btn");

    if (action === "BUY") {
        tradeActionBtn.textContent = "BUY";
        tradeActionBtn.className = "trade-btn buy";
        tradeActionBtn.style.display = "inline-block";
    } else if (action === "SELL") {
        tradeActionBtn.textContent = "SELL";
        tradeActionBtn.className = "trade-btn sell";
        tradeActionBtn.style.display = "inline-block";
    } else {
        tradeActionBtn.textContent = ""; // Clear text
        tradeActionBtn.style.display = "none"; // Hide button when NONE
    }

    await saveTradeChanges(tradeId); // Save changes to Firestore
}



//editing trade name admin only
// ✅ Function to attach event listeners to trade name buttons (Only for Admins)
async function applyTradeButtonListeners(tradeId) {
    const user = auth.currentUser;
    const isAdminUser = user ? await checkIfAdmin(user) : false;

    if (!isAdminUser) return; // ❌ Non-admins cannot edit trade buttons

    console.log(`✅ Admin detected. Trade buttons are now editable for Trade ID: ${tradeId}`);

    // Attach event listeners for trade name buttons
    document.querySelector(`#${tradeId} .trade-action`).addEventListener("dblclick", () => updateTradeButton(tradeId, "action"));
    document.querySelector(`#${tradeId} .trade-asset`).addEventListener("dblclick", () => updateTradeButton(tradeId, "asset"));
    document.querySelector(`#${tradeId} .trade-entry-price`).addEventListener("dblclick", () => updateTradeButton(tradeId, "entryPrice"));
}

// ✅ Function to handle trade name updates for Admins


async function updateTradeButton(tradeId, fieldType) {
    const user = auth.currentUser;
    const isAdminUser = await checkIfAdmin(user);

    if (!isAdminUser) {
        alert("❌ Only admins can update trade details!");
        return;
    }

    const enteredPassword = prompt("Enter admin password:");
    if (enteredPassword !== secretKey) {
        alert("❌ Incorrect password! Changes denied.");
        return;
    }

    const newValue = prompt(`Enter new ${fieldType}:`);
    if (!newValue) return;

    try {
        const tradeRef = doc(db, "trades", tradeId);
        await updateDoc(tradeRef, { [fieldType]: newValue });

        // ✅ Update UI instantly
        document.getElementById(tradeId).querySelector(`.trade-${fieldType}`).textContent = newValue;

        alert("✅ Trade updated successfully!");
    } catch (error) {
        console.error(`❌ Error updating ${fieldType}:`, error);
    }
}

// ✅ Ensure admin control is applied when trade cards are created
auth.onAuthStateChanged(async (user) => {
    if (!user) return;

    const isAdmin = await checkIfAdmin(user);

    document.querySelectorAll(".trade-btn").forEach(button => {
        if (isAdmin) {
            button.classList.add("admin-editable"); // ✅ Admins can edit
            button.style.cursor = "pointer"; // Allow clicking for admins
            button.style.pointerEvents = "auto"; // Make sure clicks work
        } else {
            button.classList.remove("admin-editable"); // ❌ Users cannot edit
            button.style.cursor = "default"; // Disable clicking for users
            button.style.pointerEvents = "none"; // Fully disable clicking
        }
    });
});

// ✅ Allow admins to double-click & edit trade buttons
document.addEventListener("dblclick", async (event) => {
    // ✅ Ensure only admin-editable buttons can be clicked
    if (!event.target.classList.contains("admin-editable")) return;

    const verified = await verifyAdmin(); // Ensure admin authentication
    if (!verified) return;

    const tradeButton = event.target;
    const newValue = prompt("Enter new value:", tradeButton.textContent);
    if (newValue === null) return;

    tradeButton.textContent = newValue;

    // ✅ Get the trade card ID
    const tradeCard = tradeButton.closest(".trade-card");
    if (!tradeCard) {
        console.error("❌ Trade card not found.");
        return;
    }

    const tradeId = tradeCard.id;
    if (!tradeId) {
        console.error("❌ Trade ID is missing.");
        return;
    }

    // ✅ Determine which field to update
    let updateField;
    if (tradeButton.classList.contains("trade-action")) updateField = "action";
    else if (tradeButton.classList.contains("trade-asset")) updateField = "asset";
    else if (tradeButton.classList.contains("trade-entry-price")) updateField = "entryPrice";

    if (updateField) {
        try {
            const tradeRef = doc(db, "trades", tradeId);
            await updateDoc(tradeRef, { [updateField]: newValue });
            alert("✅ Trade updated successfully!");
        } catch (error) {
            console.error("❌ Firestore update failed:", error);
            alert("⚠️ Error updating trade.");
        }
    }
});
///////////////// Converted name into three buttons ENDS HERE ///////////////// 

///////////////// Event Greetinh Banner STARTS HERE ///////////////// 

//import { db } from "./firebaseConfig.js";
//import { doc, getDoc, setDoc, updateDoc } from "https://www.gstatic.com/firebasejs/10.10.0/firebase-firestore.js";

// 🎉 Show Banner on Login (Only if enabled)
//import { db } from "./firebaseConfig.js";
//import { doc, getDoc, setDoc, updateDoc } from "https://www.gstatic.com/firebasejs/10.10.0/firebase-firestore.js";

// 🎉 Show Banner on Login (Only if enabled)
// 🎉 Show Banner on User Login (Only if enabled)
// 🎉 Show Banner on Login (Only if enabled)
auth.onAuthStateChanged(async (user) => {
    if (user) {
        console.log("✅ User logged in. Checking banner settings...");
        const bannerRef = doc(db, "settings", "eventBanner");
        const bannerSnap = await getDoc(bannerRef);

        if (bannerSnap.exists()) {
            const data = bannerSnap.data();
            if (data.enabled) {
                console.log("🎉 Banner enabled! Showing message:", data.message);

                const banner = document.getElementById("event-banner");
                const bannerMessage = document.getElementById("banner-message");

                bannerMessage.textContent = data.message; // ✅ Set the message
                banner.classList.remove("hidden"); // ✅ Remove the hidden class
                banner.classList.add("show"); // ✅ Add animation class
                
                // Show the banner for 3 seconds
                setTimeout(() => {
                    banner.classList.remove("show");
                    banner.classList.add("hidden"); // ✅ Hide after animation
                }, 3000);
            } else {
                console.log("⚠️ Banner is disabled.");
            }
        } else {
            console.log("⚠️ No banner settings found in Firestore.");
        }
    }
});

// 🎛 Admin Panel: Save Banner Message
// 🎛 Admin Panel: Save Banner Message
document.getElementById("save-banner").addEventListener("click", async () => {
	const newMessage = document.getElementById("banner-text").value.trim();
	if (!newMessage) return alert("Enter a valid greeting message!");
	
	await setDoc(doc(db, "settings", "eventBanner"), { message: newMessage }, { merge: true });
	alert("🎉 Banner message updated!");
});

// 🎛 Admin Panel: Toggle Banner ON/OFF
document.getElementById("toggle-banner").addEventListener("click", async () => {
	const bannerRef = doc(db, "settings", "eventBanner");
	const bannerSnap = await getDoc(bannerRef);
	
	const currentState = bannerSnap.exists() ? bannerSnap.data().enabled : false;
	await setDoc(bannerRef, { enabled: !currentState }, { merge: true });
	
	alert(`🎉 Banner is now ${!currentState ? "ENABLED" : "DISABLED"}`);
});

// Toggle Event Greeting Banner Section
document.getElementById("toggle-banner-section").addEventListener("click", function() {
	const bannerContainer = document.getElementById("banner-container");
	bannerContainer.style.display = bannerContainer.style.display === "none" || bannerContainer.style.display === "" ? "block" : "none";
});

///////////////// Event Greeting Banner ENDS HERE ///////////////// 

///////////////// Store a Notification When a User Deletes Their Account & Store Sign-Up & Deletion Notifications to admin in Firestore & Load Notifications in the Admin Panel STARTS HERE ///////////////// 

// ✅ Function to Register a New User & Notify Admin
// ✅ Register User & Notify Admin
async function registerUser(email, password) {
	try {
		const userCredential = await createUserWithEmailAndPassword(auth, email, password);
		const user = userCredential.user;
		console.log("✅ User signed up:", user.email);
		
		// 🔔 Store a sign-up notification in Firestore
		await addDoc(collection(db, "notifications"), {
			message: `🆕 New user signed up: ${user.email}`,
			type: "signup",
			timestamp: serverTimestamp(),
			read: false
		});
		
	} catch (error) {
		console.error("❌ Error signing up:", error.message);
	}
}






// ✅ ADD this new function
async function syncUsersToUsers1() {
    console.log("🔄 Syncing Users to Users1...");

    const usersRef = collection(db, "users");
    const users1Ref = collection(db, "users1");

    try {
        // Fetch all users from "users"
        const usersSnapshot = await getDocs(usersRef);

        for (const userDoc of usersSnapshot.docs) {
            const userId = userDoc.id;
            const userData = userDoc.data();

            // Check if the user exists in "users1"
            const user1Ref = doc(users1Ref, userId);
            const user1Snap = await getDoc(user1Ref);

            if (!user1Snap.exists() || JSON.stringify(user1Snap.data()) !== JSON.stringify(userData)) {
                // If user does not exist OR data is different, update/copy it
                await setDoc(user1Ref, userData);
                console.log(`✅ Synced user: ${userId}`);
            } else {
                console.log(`🔹 No changes for user: ${userId}`);
            }
        }

        alert("✅ Sync Completed!");
    } catch (error) {
        console.error("❌ Error syncing users:", error);
        alert("⚠️ Failed to sync users. Check console for details.");
    }
}
document.getElementById("sync-users-btn").addEventListener("click", syncUsersToUsers1);


auth.onAuthStateChanged(async (user) => {
	if (user) {
		console.log("🔹 Logged in user:", user.email);
		
		// No need to copy user data automatically anymore
		// Users will be synced only when the "Sync Users" button is clicked
	}
});

//Store a Notification When a User Deletes Their Account
// ✅ Delete User & Notify Admin
// ✅ Delete User & Notify Admin
async function deleteUserAccount() {
	const user = auth.currentUser;
	if (!user) return alert("No user is logged in.");
	
	if (!confirm("Are you sure you want to delete your account? This cannot be undone.")) return;
	
	try {
		const email = user.email; // Store email before deleting the user
		
		// 🔔 Save a deletion notification in Firestore BEFORE deleting the user
		await addDoc(collection(db, "notifications"), {
			message: `❌ User deleted account: ${email}`,
			type: "delete", // ✅ Mark it as an account deletion notification
			timestamp: serverTimestamp(),
			read: false // 🔴 Mark as unread initially
		});
		
		// 🔥 Delete user from Firebase Authentication
		await deleteUser(user);
		alert("Your account has been deleted.");
		
	} catch (error) {
		console.error("❌ Error deleting account:", error.message);
	}
}

//async function deleteUserAccount() {
    //const user = auth.currentUser;
    //if (!user) return alert("No user is logged in.");

    //if (!confirm("Are you sure you want to delete your account? This cannot be undone.")) return;

    //try {
        //const userId = user.uid; // Get user ID before deletion
        //const email = user.email; // Store email before deleting the user

        // 🔔 Save a deletion notification in Firestore BEFORE deleting the user
        //await addDoc(collection(db, "notifications"), {
            //message: `❌ User deleted account: ${email}`,
            //type: "delete",
            //timestamp: serverTimestamp(),
            //read: false
        //});

        // 🔥 Delete user from Firestore "users" collection
        //await deleteDoc(doc(db, "users", userId));
        //console.log(`✅ Deleted user ${userId} from users collection`);

        // 🔥 Delete user from Firestore "users1" collection
        //await deleteDoc(doc(db, "users1", userId));
        //console.log(`✅ Deleted user ${userId} from users1 collection`);

        // 🔥 Delete user from Firebase Authentication
        //await deleteUser(user);
        //alert("Your account has been deleted.");

    //} catch (error) {
        //console.error("❌ Error deleting account:", error.message);
        //alert("❌ Failed to delete account. Try again.");
    //}
//}


// ✅ Load Sign-Up & Account Deletion Notifications for Admin
async function loadAdminNotifications() {
	const notificationsList = document.getElementById("admin-notifications-list");
	notificationsList.innerHTML = "<p>Loading notifications...</p>";
	
	try {
		const q = query(
			collection(db, "notifications"),
			where("type", "in", ["signup", "delete"]), // ✅ Only fetch sign-up & delete notifications
			orderBy("timestamp", "desc"),
			limit(10) // ✅ Show latest 10 notifications
		);
		const querySnapshot = await getDocs(q);
		notificationsList.innerHTML = ""; // ✅ Clear old notifications
		
		if (querySnapshot.empty) {
			notificationsList.innerHTML = "<p>No new sign-ups or account deletions.</p>";
			return;
		}
		
		querySnapshot.forEach((doc) => {
			const notificationData = doc.data();
			let notifDate = "Unknown Date";
			
			if (notificationData.timestamp && notificationData.timestamp.toDate) {
				notifDate = new Date(notificationData.timestamp.toDate()).toLocaleString();
			}
			
			// ✅ Create notification item
			const notifItem = document.createElement("li");
			notifItem.innerHTML = `📢 ${notificationData.message} <br> 🕒 ${notifDate}`;
			notificationsList.appendChild(notifItem);
		});
		
	} catch (error) {
		console.error("❌ Error loading notifications:", error);
		notificationsList.innerHTML = `<p style="color: red;">Error loading notifications.</p>`;
	}
}

// ✅ Load notifications when admin panel opens
document.getElementById("admin-btn").addEventListener("click", loadAdminNotifications);


// ✅ Mark Notification as Read
async function markAsRead(notifId) {
	try {
		const notifRef = doc(db, "notifications", notifId);
		await updateDoc(notifRef, { read: true });
		console.log("✅ Notification marked as read:", notifId);
		loadAdminNotifications(); // ✅ Refresh notifications
	} catch (error) {
		console.error("❌ Error marking notification as read:", error);
	}
}




///////////////// Store a Notification When a User Deletes Their Account & Store Sign-Up & Deletion Notifications to admin in Firestore & Load Notifications in the Admin Panel ENDS HERE ///////////////// 

///////////////// To ensure that only admins see the admin panel (and that it behaves like the settings panel), add a button (for example, an "Admin" button) that toggles the visibility of the admin panel. For instance: STARTS HERE ///////////////// 

//const adminBtn = document.getElementById("admin-btn");
//const adminPanel = document.getElementById("admin-panel");
const closeAdminPanelBtn = document.getElementById("close-admin-panel");

// Show admin panel when admin button is clicked (after verifying admin status)

// ✅ Show Admin Panel (Only if Admin)
adminBtn.addEventListener("click", async () => {
	const isAdmin = await checkIfAdmin(auth.currentUser);
	if (isAdmin) {
		adminPanel.classList.remove("hidden");
		loadAllUserMessages();
		loadAllUserFeedback();
		loadBlockedUsers();
		listenForLogins();
		enableTradeEditingForAdmins();
	} else {
		alert("Access Denied! You are not an admin.");
	}
});

// Check if the button exists before adding an event listener
//const adminPanel = document.getElementById("admin-panel");

if (closeAdminPanelBtn) {
	closeAdminPanelBtn.addEventListener("click", () => {
		adminPanel.classList.add("hidden");
	});
} else {
	console.error("❌ close-admin-panel button not found in the DOM!");
}

// ✅ Block User
document.getElementById("block-user").addEventListener("click", async () => {
	const email = document.getElementById("block-user-email").value.trim();
	if (!email) return alert("Enter an email to block.");
	
	try {
		await blockUser(email);
		alert(`User ${email} has been blocked.`);
		loadBlockedUsers(); // Refresh list
	} catch (error) {
		console.error("Error blocking user:", error);
	}
});

// ✅ Unblock User
document.getElementById("unblock-user").addEventListener("click", async () => {
	const email = document.getElementById("block-user-email").value.trim();
	if (!email) return alert("Enter an email to unblock.");
	
	try {
		await unblockUser(email);
		alert(`User ${email} has been unblocked.`);
		loadBlockedUsers(); // Refresh list
	} catch (error) {
		console.error("Error unblocking user:", error);
	}
});
// Hide admin panel when close button is clicked
closeAdminPanelBtn.addEventListener("click", () => {
  adminPanel.classList.add("hidden");
});

///////////////// Modify User Settings for Blocked UsersIf a user is blocked, they should only see Settings and Admin Chat. STARTS HERE ///////////////// 


///////////////// Modify User Settings for Blocked UsersIf a user is blocked, they should only see Settings and Admin Chat. ENDS HERE ///////////////// 
//const adminPanel = document.getElementById("admin-panel");

auth.onAuthStateChanged(async (user) => {
  console.log("🔍 auth.onAuthStateChanged triggered");
  
  if (!user) {
    console.log("❌ No user logged in. Hiding all panels.");
    
    const panels = [
      "settings-panel", "admin-panel", "trade-section", "notification-section",
      "blocked-message", "notification-list", "date-filter",
      "analysisPanel", "toolsPanel", "educationPanel",
      "analysisPanelButton", "toolsPanelButton", "educationPanelButton"
    ];
    
    panels.forEach(id => {
      const element = document.getElementById(id);
      if (element) {
        element.classList.add("hidden");
        console.log(`🔹 Hiding: ${id}`);
      } else {
        console.warn(`⚠️ Element not found: ${id}`);
      }
    });
    
    return;
  }
  
  console.log(`🔹 Logged in user: ${user.email} (UID: ${user.uid})`);
  
  try {
    // ✅ Check if the user is blocked
    console.log("🔍 Checking if user is blocked...");
    const isBlocked = await checkIfBlocked(user.email);
    console.log(`🔹 User Block Status: ${isBlocked}`);
    
    if (isBlocked) {
      console.log("🚫 User is BLOCKED! Restricting to Settings Panel only.");
      
      const elementsToHide = [
        "admin-panel", "trade-section", "notification-section", "notification-list",
        "analysisPanel", "toolsPanel", "educationPanel",
        "analysisPanelButton", "toolsPanelButton", "educationPanelButton",
        "date-filter"
      ];
      
      elementsToHide.forEach(id => {
        const element = document.getElementById(id);
        if (element) element.classList.add("hidden");
      });
      
      document.getElementById("settings-panel")?.classList.remove("hidden");
      document.getElementById("blocked-message")?.classList.remove("hidden");
      
      return;
    }
    
    // ✅ User is NOT blocked
    console.log("✅ User is NOT blocked. Showing trade section and buttons.");
    
    const elementsToShow = [
      "trade-section", "notification-section",
      "analysisPanelButton", "toolsPanelButton", "educationPanelButton",
      "date-filter"
    ];
    
    elementsToShow.forEach(id => {
      const element = document.getElementById(id);
      if (element) element.classList.remove("hidden");
    });
    
    // ✅ Ensure panels stay hidden until clicked
    ["analysisPanel", "toolsPanel", "educationPanel"].forEach(id => {
      const el = document.getElementById(id);
      if (el) el.classList.add("hidden");
    });
    
    document.getElementById("blocked-message")?.classList.add("hidden");
    document.getElementById("toggle-premium-panel")?.classList.add("hidden");
    document.getElementById("premium-managemen")?.classList.add("hidden");
    
    // ✅ Check if Admin
    console.log("🔍 Checking admin status...");
    const isAdmin = await checkIfAdmin(user);
    console.log(`🔹 Admin Status: ${isAdmin}`);
    
    if (isAdmin) {
      console.log("✅ Admin detected. Showing Admin Panel.");
      document.getElementById("admin-panel")?.classList.remove("hidden");
      loadAllUserMessages();
      loadBlockedUsers();
    } else {
      console.log("❌ Not an admin. Hiding Admin Panel.");
      document.getElementById("admin-panel")?.classList.add("hidden");
    }
    
  } catch (error) {
    console.error("⚠️ Error handling user state:", error);
  }
});

///////////////// To ensure that only admins see the admin panel (and that it behaves like the settings panel), add a button (for example, an "Admin" button) that toggles the visibility of the admin panel. For instance: ENDS HERE ///////////////// 

///////////////// Admin Can Reply to User Messages📌 Modify script.js to let admin reply to user messages: STARTS HERE ///////////////// 

// ✅ Load All User Messages for Admin
async function loadAllUserMessages() {
    const adminMessagesList = document.getElementById("admin-messages-list");
    adminMessagesList.innerHTML = "<p>Loading messages...</p>";

    try {
        const messagesRef = collection(db, "chats");
        const q = query(messagesRef, orderBy("timestamp", "desc"));
        const querySnapshot = await getDocs(q);
        adminMessagesList.innerHTML = "";

        if (querySnapshot.empty) {
            adminMessagesList.innerHTML = "<p>No messages available.</p>";
        } else {
            querySnapshot.forEach((doc) => {
                const messageData = doc.data();
                let messageDate = "Unknown Date";

                if (messageData.timestamp && messageData.timestamp.toDate) {
                    messageDate = new Date(messageData.timestamp.toDate()).toLocaleString();
                }

                // Create message item with reply box
                const messageItem = document.createElement("li");
                messageItem.innerHTML = `
                    <strong>${messageData.email}:</strong> ${messageData.message} 
                    <br>📅 ${messageDate}
                    <br>
                    <textarea id="msg-reply-${doc.id}" placeholder="Reply here..."></textarea>
                    <button onclick="sendMessageReply('${doc.id}', '${messageData.userId}')">Reply</button>
                    <br><br>
                `;
                adminMessagesList.appendChild(messageItem);
            });
        }
    } catch (error) {
        console.error("❌ Error loading all messages:", error);
        adminMessagesList.innerHTML = `<p style="color: red;">Error loading messages.</p>`;
    }
}

// ✅ Send Admin Reply to Messages
async function sendMessageReply(messageId, userId) {
    const replyText = document.getElementById(`msg-reply-${messageId}`).value.trim();
    if (!replyText) return alert("Reply cannot be empty!");

    try {
        await addDoc(collection(db, "adminMessages"), {
            userId: userId,
            message: replyText,
            timestamp: serverTimestamp(),
        });

        alert("Reply sent successfully!");
        document.getElementById(`msg-reply-${messageId}`).value = ""; // Clear input
    } catch (error) {
        console.error("❌ Error sending message reply:", error);
    }
}

// Toggle visibility of the messages list
document.getElementById("toggle-messages").addEventListener("click", function () {
    const messageList = document.getElementById("admin-messages-list");
    if (messageList.style.display === "none" || messageList.style.display === "") {
        messageList.style.display = "block"; // Expand
    } else {
        messageList.style.display = "none"; // Collapse
    }
});

///////////////// Admin Can Reply to User Messages📌 Modify script.js to let admin reply to user messages: ENDS HERE ///////////////// 


 


///////////////// Show Admin’s Messages to the UserNow, let's add "Admin’s Message for You" below "Chat with Admin" in Settings Panel. STARTS HERE ///////////////// 

//Force-load feedback and messages when the admin panel opens:
document.getElementById("admin-btn").addEventListener("click", () => {
    loadAllUserFeedback();
    loadAllUserMessages();
    loadBlockedUsers();
});

// 🔹 Load Admin's Messages for the Logged-in User
async function loadAdminMessages() {
    const user = auth.currentUser;
    if (!user) return;

    const querySnapshot = await getDocs(collection(db, "adminMessages"));
    const adminMessagesList = document.getElementById("admin-messages-for-user");
    adminMessagesList.innerHTML = "";

    querySnapshot.forEach((doc) => {
        const data = doc.data();
        if (data.userId === user.uid) {
            const messageItem = document.createElement("li");
            messageItem.textContent = `📢 ${data.message}`;
            adminMessagesList.appendChild(messageItem);
        }
    });
}

// ✅ Load Admin Messages When Settings Open
document.getElementById("settings-button").addEventListener("click", loadAdminMessages);

///////////////// Show Admin’s Messages to the UserNow, let's add "Admin’s Message for You" below "Chat with Admin" in Settings Panel. ENDS HERE ///////////////// 



///////////////// Admin Panel Logic in script.jsNow, let's control who sees the Admin Panel and load user messages, feedback, and notifications. STARTS HERE ///////////////// 

//import { db, auth } from "./firebaseConfig.js";
//import { collection, addDoc, getDocs, doc, updateDoc, onSnapshot, setDoc } from "https://www.gstatic.com/firebasejs/10.10.0/firebase-firestore.js";

// ✅ Admin Credentials
//const ADMIN_EMAIL = "pravinshinde222.ps@gmail.com"; // Change this to actual admin email

// Elements
const adminPanel = document.getElementById("admin-panel");
const adminMessagesList = document.getElementById("admin-messages-list");
const adminFeedbackList = document.getElementById("admin-feedback-list");
const adminNotificationsList = document.getElementById("admin-notifications-list");
const blockUserInput = document.getElementById("block-user-email");
const blockUserBtn = document.getElementById("block-user");

// 🔒 Show Admin Panel ONLY for Admin
auth.onAuthStateChanged((user) => {
    if (user && user.email === ADMIN_EMAIL) {
        adminPanel.classList.remove("hidden"); // Show Admin Panel
        loadAllUserMessages();
        loadUserFeedback();
        listenForLogins();
    } else {
        adminPanel.classList.add("hidden"); // Hide for non-admins
    }
});

// 📩 Load User Messages
// ✅ Load All User Feedback for Admin
// ✅ Load All Feedback (With Admin Reply Option)
async function loadAllUserFeedback() {
	const adminFeedbackList = document.getElementById("admin-feedback-list");
	adminFeedbackList.innerHTML = "<p>Loading feedback...</p>";
	
	try {
		const feedbackRef = collection(db, "feedback");
		const q = query(feedbackRef, orderBy("timestamp", "desc"));
		const querySnapshot = await getDocs(q);
		adminFeedbackList.innerHTML = "";
		
		if (querySnapshot.empty) {
			adminFeedbackList.innerHTML = "<p>No feedback available.</p>";
		} else {
			querySnapshot.forEach((doc) => {
				const feedbackData = doc.data();
				let feedbackDate = "Unknown Date";
				
				if (feedbackData.timestamp && feedbackData.timestamp.toDate) {
					feedbackDate = new Date(feedbackData.timestamp.toDate()).toLocaleString();
				}
				
				// Create feedback item with reply box
				const feedbackItem = document.createElement("li");
				feedbackItem.innerHTML = `
                    <strong>${feedbackData.email}:</strong> ${feedbackData.feedback} 
                    <br>📅 ${feedbackDate}
                    <br>
                    <textarea id="reply-${doc.id}" placeholder="Reply here..."></textarea>
                    <button onclick="sendFeedbackReply('${doc.id}', '${feedbackData.userId}')">Reply</button>
                    <br><br>
                `;
				adminFeedbackList.appendChild(feedbackItem);
			});
		}
	} catch (error) {
		console.error("❌ Error loading all feedback:", error);
		adminFeedbackList.innerHTML = `<p style="color: red;">Error loading feedback.</p>`;
	}
}

// ✅ Send Admin Reply to Feedback
window.sendFeedbackReply = async function(feedbackId, userId) {
	const replyText = document.getElementById(`reply-${feedbackId}`).value.trim();
	if (!replyText) return alert("Reply cannot be empty!");
	
	try {
		const feedbackRef = doc(db, "feedback", feedbackId);
		await updateDoc(feedbackRef, { adminReply: replyText });
		
		await addDoc(collection(db, "adminMessages"), {
			userId: userId,
			message: replyText,
			timestamp: serverTimestamp(),
		});
		
		alert("Reply sent successfully!");
		document.getElementById(`reply-${feedbackId}`).value = "";
	} catch (error) {
		console.error("❌ Error sending reply:", error);
	}
};
// ✅ Load all feedback when Admin Panel opens
document.getElementById("admin-btn").addEventListener("click", loadAllUserFeedback);

// Toggle User Feedback
document.getElementById("toggle-feedback").addEventListener("click", function () {
    const feedbackList = document.getElementById("admin-feedback-list");
    feedbackList.style.display = feedbackList.style.display === "none" || feedbackList.style.display === "" ? "block" : "none";
});


// 🔔 Notify Admin on New Logins
function listenForLogins() {
    onSnapshot(collection(db, "logins"), (snapshot) => {
        adminNotificationsList.innerHTML = "";
        snapshot.forEach((doc) => {
            const data = doc.data();
            const notificationItem = document.createElement("li");
            notificationItem.textContent = `👤 ${data.email} logged in`;
            adminNotificationsList.appendChild(notificationItem);
        });
    });
}

// 🚫 Block User
blockUserBtn.addEventListener("click", async () => {
    const email = blockUserInput.value.trim();
    if (!email) return alert("Enter a valid email!");

    await setDoc(doc(db, "blockedUsers", email), { blocked: true });
    alert(`${email} has been blocked.`);
});
// 🚫 Block User
async function blockUser() {
    const email = document.getElementById("block-user-email").value.trim();
    if (!email) return alert("Enter a valid email!");

    try {
        await setDoc(doc(db, "blockedUsers", email), { blocked: true });
        alert(`${email} has been blocked.`);
        loadBlockedUsers(); // ✅ Refresh the blocked list
    } catch (error) {
        console.error("❌ Error blocking user:", error);
    }
}
document.getElementById("block-user").addEventListener("click", blockUser);

///////////////// Admin Panel Logic in script.jsNow, let's control who sees the Admin Panel and load user messages, feedback, and notifications. ENDS HERE ///////////////// 


///////////////// Admin Can Block & Unblock Users📌 Modify script.js to allow admin to block / unblock users: STARTS HERE ///////////////// 

//const blockUserBtn = document.getElementById("block-user");
const unblockUserBtn = document.getElementById("unblock-user");

// 🚫 Block User
blockUserBtn.addEventListener("click", async () => {
	const email = document.getElementById("block-user-email").value.trim();
	if (!email) return alert("Enter a valid email!");
	
	await setDoc(doc(db, "blockedUsers", email), { blocked: true });
	alert(`${email} has been blocked.`);
	loadBlockedUsers(); // Refresh list
});

// ✅ Unblock User
unblockUserBtn.addEventListener("click", async () => {
	const email = document.getElementById("block-user-email").value.trim();
	if (!email) return alert("Enter a valid email!");
	
	await deleteDoc(doc(db, "blockedUsers", email));
	alert(`${email} has been unblocked.`);
	loadBlockedUsers(); // Refresh list
});

// ✅ Load Blocked Users List
// ✅ Load Blocked Users from Firestore
async function loadBlockedUsers() {
    console.log("🔄 Loading blocked users...");
    const blockedUsersList = document.getElementById("blocked-users-list");
    blockedUsersList.innerHTML = "<p>Loading blocked users...</p>";

    try {
        const querySnapshot = await getDocs(collection(db, "blockedUsers"));
        blockedUsersList.innerHTML = ""; // ✅ Clear old list

        if (querySnapshot.empty) {
            blockedUsersList.innerHTML = "<p>No blocked users.</p>";
            return;
        }

        querySnapshot.forEach((doc) => {
            const email = doc.id;
            const listItem = document.createElement("li");
            listItem.textContent = email;
            blockedUsersList.appendChild(listItem);
        });

        console.log("✅ Blocked users loaded.");
    } catch (error) {
        console.error("❌ Error loading blocked users:", error);
    }
}

// ✅ Load Blocked Users When Admin Panel Opens
document.getElementById("admin-btn").addEventListener("click", loadBlockedUsers);

// ✅ Check if User is Blocked from Firestore
// ✅ Check if User is Blocked from Firestore
async function checkIfBlocked(email) {
    try {
        const docRef = doc(db, "blockedUsers", email);
        const docSnap = await getDoc(docRef);

        if (docSnap.exists()) {
            console.log(`🚫 User ${email} is BLOCKED!`);
            return true; // ✅ User is blocked
        } else {
            console.log(`✅ User ${email} is NOT blocked.`);
            return false; // ✅ User is not blocked
        }
    } catch (error) {
        console.error("❌ Error checking blocked status:", error);
        return false; // ✅ If error, assume user is not blocked
    }
}

// Toggle Blocked Users Section
document.getElementById("toggle-blocked-users").addEventListener("click", function () {
    const blockedUsersContainer = document.getElementById("blocked-users-container");
    blockedUsersContainer.style.display = blockedUsersContainer.style.display === "none" || blockedUsersContainer.style.display === "" ? "block" : "none";
});
///////////////// Admin Can Block & Unblock Users 📌 Modify script.js to allow admin to block / unblock users: ENDS HERE /////////////////


///////////////// Send msg to admin STARTS HERE ///////////////// 
//import { db, auth } from "./firebaseConfig.js";
//import { collection, addDoc, query, orderBy, where, onSnapshot, serverTimestamp, getDocs } from "https://www.gstatic.com/firebasejs/10.10.0/firebase-firestore.js";

// ✅ Function to Send a Message to Admin
document.getElementById("send-chat").addEventListener("click", async () => {
    const user = auth.currentUser;
    const messageText = document.getElementById("chat-input").value.trim();

    if (!user) {
        alert("You must be logged in to chat with the admin.");
        return;
    }

    if (!messageText) {
        alert("Please enter a message before sending.");
        return;
    }

    try {
        // ✅ Store message in Firestore
        await addDoc(collection(db, "chats"), {
            userId: user.uid,
            email: user.email,
            message: messageText,
            timestamp: serverTimestamp()
        });

        alert("Message sent successfully!");
        document.getElementById("chat-input").value = ""; // Clear input field
        loadChatMessages(); // Refresh chat messages
    } catch (error) {
        console.error("Error sending message:", error);
        alert("Error: Unable to send message.");
    }
});

// ✅ Function to Load Chat Messages
async function loadChatMessages() {
    const user = auth.currentUser;
    if (!user) return;

    try {
        const chatList = document.getElementById("chat-list");
        chatList.innerHTML = "<p>Loading messages...</p>";

        // Reference to Firestore collection
        const chatRef = collection(db, "chats");

        // ✅ Get messages for the logged-in user
        const q = query(
            chatRef,
            where("userId", "==", user.uid),
            orderBy("timestamp", "asc") // Ensure messages are ordered correctly
        );

        const querySnapshot = await getDocs(q);
        chatList.innerHTML = ""; // Clear previous messages

        if (querySnapshot.empty) {
            chatList.innerHTML = "<p>No messages yet.</p>";
        } else {
            querySnapshot.forEach((doc) => {
                const chatData = doc.data();
                let chatDate = "Unknown Date";

                if (chatData.timestamp && chatData.timestamp.toDate) {
                    chatDate = new Date(chatData.timestamp.toDate()).toLocaleString();
                }

                // Create and append message
                const chatItem = document.createElement("li");
                chatItem.textContent = `${chatDate}: ${chatData.message}`;
                chatList.appendChild(chatItem);
            });
        }
    } catch (error) {
        console.error("❌ Error loading chat messages:", error);
        const chatList = document.getElementById("chat-list");
        chatList.innerHTML = `<p style="color: red;">Error loading chat messages.</p>`;
    }
}

// ✅ Load messages when settings panel opens
document.getElementById("settings-button").addEventListener("click", () => {
    loadChatMessages();
});
///////////////// Send msg to admin ENDS HERE ///////////////// 

///////////////// Add Labels STARTS HERE ///////////////// 

///////////////// Add Labels STARTS HERE ///////////////// 

let isPasswordVerified = false; // Cache password check for the session

function addCustomTradeType() {
    let customTradeType = prompt("Enter Custom Trade Type:");
    if (customTradeType) {
        document.querySelector(".trade-type").textContent = customTradeType;
        document.querySelector(".trade-type").className = "trade-type custom-trade-type";
    }
}

function addCustomTradeState() {
    let customTradeState = prompt("Enter Custom Trade State:");
    if (customTradeState) {
        document.querySelector(".trade-state").textContent = customTradeState;
        document.querySelector(".trade-state").className = "trade-state custom-trade-state";
    }
}

// Only Admins Can Change Trade Type & Trade State
async function enableTradeEditingForAdmins() {
	const user = auth.currentUser;
	const isAdminUser = await checkIfAdmin(user);
	
	if (!isAdminUser) return;
	
	// Enable trade-type and trade-state dropdowns
	const typeSelect = document.getElementById("trade-type");
	const stateSelect = document.getElementById("trade-state");
	
	typeSelect?.removeAttribute("disabled");
	stateSelect?.removeAttribute("disabled");
	
	// Show custom input if "Custom" is selected
	typeSelect?.addEventListener("change", (e) => {
		const customInput = document.getElementById("custom-trade-type");
		customInput.classList.toggle("hidden", e.target.value !== "Custom");
	});
	
	stateSelect?.addEventListener("change", (e) => {
		const customInput = document.getElementById("custom-trade-state");
		customInput.classList.toggle("hidden", e.target.value !== "Custom");
	});
}

// ✅ Enable editing ONLY for admins when the page loads
document.getElementById("update-trade-labels").addEventListener("click", () => {
	// Show the form section
	document.getElementById("trade-form-container").classList.remove("hidden");
	
	// Re-check and enable dropdowns
	enableTradeEditingForAdmins();
});


async function updateTradeLabel(tradeId, labelType) {
	const user = auth.currentUser;
	const isAdminUser = await checkIfAdmin(user);

	if (!isAdminUser) {
		alert("❌ Only admins can update trade labels!");
		return;
	}

	// ✅ Ask for password first
	const enteredPassword = prompt("Enter admin password to change trade labels:");
	if (enteredPassword !== secretKey) {
		alert("❌ Incorrect password! Changes denied.");
		return;
	}

	// ✅ Only after correct password, show label options
	const labelOptions = labelType === "tradeType"
		? ["Intraday", "Short Term", "Long Term", "Re-entry", "Swing", "Momentum", "Positional", "BEST", "STBT", "Investment", "Arbitrage", "Options & Futures", "Cash", "Algo", "Quant", "Custom"]
		: ["Waiting for entry", "Entry triggered", "Order pending", "Running", "Stop Loss hit", "Target 1 Hit", "Target 2 Hit", "Target 3 Hit", "Exited", "Booked", "Partially Filled", "Cancelled", "Break Even", "Re-entry Triggered", "Time Stop Hit", "Auto-Squared Off", "Custom"];

	let selectedLabel = prompt(`Choose ${labelType}:\n` + labelOptions.join("\n"));
	if (!selectedLabel) return;

	if (selectedLabel === "Custom") {
		selectedLabel = prompt("Enter custom label:");
		if (!selectedLabel) return;
	}

	try {
		const tradeRef = doc(db, "trades", tradeId);
		await updateDoc(tradeRef, { [labelType]: selectedLabel });

		document.getElementById(tradeId).querySelector(`.${labelType}-label`).textContent = selectedLabel;

		alert("✅ Trade label updated successfully!");
	} catch (error) {
		console.error("❌ Error updating trade label:", error);
	}
}

// Call this after creating each trade card
async function applyLabelClickListeners(tradeId) {
    const user = auth.currentUser;
    const isAdminUser = user ? await checkIfAdmin(user) : false;

    if (!isAdminUser) return; // ❌ Non-admins cannot interact with labels

    console.log(`✅ Admin detected. Labels are now clickable for Trade ID: ${tradeId}`);

    const tradeTypeLabel = document.querySelector(`#${tradeId} .trade-type-label`);
    const tradeStateLabel = document.querySelector(`#${tradeId} .trade-state-label`);

    if (tradeTypeLabel) {
        tradeTypeLabel.addEventListener("click", () => updateTradeLabel(tradeId, "tradeType"));
    }
    if (tradeStateLabel) {
        tradeStateLabel.addEventListener("click", () => updateTradeLabel(tradeId, "tradeState"));
    }
}

///////////////// Add Labels ENDS HERE //////////////////

///////////////// Add Labels ENDS HERE //////////////////

///////////////// 1️⃣ User-Side Cleanup (Fastest UI Performance)Only show the latest 10 notifications in the UI (users won’t see older ones).2️⃣ Firestore TTL (Auto-Delete Old Notifications)Firebase will automatically delete notifications older than 3 hours.3️⃣ Admin Button (Manual Cleanup Option)Admins can force-delete old notifications whenever needed.          STARTS HERE ///////////////// 

async function fetchNotifications() {
    if (!userLoginTime) return; // ✅ Only fetch if logged in

    const notificationsRef = collection(db, "notifications");
    const q = query(
        notificationsRef,
        where("timestamp", ">=", userLoginTime),
        orderBy("timestamp", "desc"),
        limit(15) // ✅ Limit to latest 15
    );

    onSnapshot(q, (snapshot) => {
        const notificationList = document.getElementById("notification-list");
        notificationList.innerHTML = ""; // ✅ Clear old notifications

        snapshot.forEach((doc) => {
            const notification = doc.data();
            displayNotification(doc.id, notification.message, notification.tradeId, notification.timestamp);
        });

        console.log(`✅ Loaded ${snapshot.size} new notifications since login.`);
    });
}

///////////////// ENDS HERE ///////////////// 

///////////////// to load only notifications after the user logged in. STARTS HERE ///////////////// 

//async function fetchNotifications() {
	//if (!userLoginTime) return; // ✅ Only fetch if logged in
	
	//const notificationsRef = collection(db, "notifications");
	//const q = query(
		//notificationsRef,
		//orderBy("timestamp", "desc"),
		//limit(10) // ✅ Only fetch latest 10
	//);
	
	//onSnapshot(q, (snapshot) => {
		//const notificationList = document.getElementById("notification-list");
		//notificationList.innerHTML = ""; // ✅ Clear old notifications
		
		//snapshot.forEach((doc) => {
			//const notification = doc.data();
			//displayNotification(doc.id, notification.message, notification.tradeId, notification.timestamp);
		//});
		
		//console.log(`✅ Loaded ${snapshot.size} latest notifications.`);
	//});
//}

function clearNotifications() {
    const notificationList = document.getElementById("notification-list");
    notificationList.innerHTML = `<p>No new notifications. 📭</p>`;
    console.log("✅ Cleared notifications after logout.");
}
///////////////// to load only notifications after the user logged in.  ENDS HERE ///////////////// 

///////////////// ✔ Fetch only the latest 20 notifications instead of everything ✔ Order them by timestamp (latest first) ✔ Reduce Firestore reads, making it more efficient STARTS HERE ///////////////// 

//import { getFirestore, collection, query, orderBy, limit, getDocs } from "firebase/firestore";

//const db = getFirestore();
//below this open if u want last 20 notifications
//async function fetchNotifications() {
    //const notificationsRef = collection(db, "notifications");
    //const q = query(notificationsRef, orderBy("timestamp", "desc"), limit(20));

    //try {
        //const querySnapshot = await getDocs(q);
        //const notifications = [];
        //querySnapshot.forEach((doc) => {
            //notifications.push({ id: doc.id, ...doc.data() });
        //});

        //renderNotifications(notifications);
    //} catch (error) {
        //console.error("Error fetching notifications:", error);
    //}
//}


///////////////// ✔ Fetch only the latest 20 notifications instead of everything ✔ Order them by timestamp (latest first) ✔ Reduce Firestore reads, making it more efficient ENDS HERE ///////////////// 

///////////////// TTS NOTIFICATION STARTS HERE ///////////////// 
function speakNotification(message) {
    if (!window.speechSynthesis) {
        console.warn("Speech synthesis is not supported in this browser.");
        return;
    }

    const utterance = new SpeechSynthesisUtterance(message);
    utterance.lang = "en-US"; // Set language
    utterance.rate = 1.0; // Adjust speed (1.0 = normal)
    utterance.volume = 1.0; // Adjust volume (0.0 to 1.0)

    speechSynthesis.speak(utterance);
}

function showNotification(message) {
    const notificationList = document.getElementById("notification-list");
    const newNotification = document.createElement("li");
    newNotification.textContent = message;
    notificationList.prepend(newNotification);

    const notificationType = localStorage.getItem("notificationType");
    console.log("Notification Type Selected:", notificationType); // Debugging log

    if (notificationType === "mp3") {
        console.log("🔊 Playing MP3 Sound");
        playNotificationSound();
    } else if (notificationType === "tts") {
        console.log("🗣️ Using Text-to-Speech");
        speakNotification(message);
    }
}

document.addEventListener("DOMContentLoaded", function () {
    const mp3Toggle = document.getElementById("mp3-toggle");
    const ttsToggle = document.getElementById("tts-toggle");

    function updateNotificationPreference(type) {
        localStorage.setItem("notificationType", type);
        if (type === "mp3") {
            ttsToggle.checked = false;
        } else if (type === "tts") {
            mp3Toggle.checked = false;
        }
    }

    // Load stored preference on page load
    const savedPreference = localStorage.getItem("notificationType");
    if (savedPreference === "mp3") {
        mp3Toggle.checked = true;
        ttsToggle.checked = false;
    } else if (savedPreference === "tts") {
        ttsToggle.checked = true;
        mp3Toggle.checked = false;
    }

    mp3Toggle.addEventListener("change", function () {
        if (this.checked) updateNotificationPreference("mp3");
    });

    ttsToggle.addEventListener("change", function () {
        if (this.checked) updateNotificationPreference("tts");
    });
});
///////////////// TTS NOTIFICATION ENDS HERE ///////////////// 

///////////////// filer trades by category and scroll to them view pager category  STARTS HERE ///////////////// 
const notificationModal = document.getElementById("notification-section");
if (notificationModal) {
    notificationModal.classList.add("notifications-active");
} else {
    console.error("Element with ID 'notification-section' not found.");
}
document.addEventListener("DOMContentLoaded", function() {
	const notificationModal = document.getElementById("notifications-modal");
	if (notificationModal) {
		notificationModal.classList.add("notifications-active");
	}
});

//function filterTradesByCategory(selectedCategory) {
	//const allTrades = document.querySelectorAll(".trade-card");
	
	//allTrades.forEach(trade => {
		//const tradeCategory = trade.getAttribute("data-category");
		//if (selectedCategory === "all" || tradeCategory === selectedCategory) {
			//trade.style.display = "block"; // ✅ Show the trade
		//} else {
			//trade.style.display = "none"; // ❌ Hide the trade
		//}
	//});
//}



// Load trades when the page is ready
window.addEventListener("DOMContentLoaded", () => {
	//below two lines changes to make date filter null instead of default todays date (there is also one more line on below document line
	//const today = new Date().toISOString().split("T")[0];
	//document.getElementById("date-filter").value = today;
	
	
	const selectedCategory = document.getElementById("category-filter").value;
	//loadTrades(selectedCategory, today); // Initial load
	loadTrades(selectedCategory, null); // Initial load
});

// Listen to dropdown changes
document.getElementById("category-filter").addEventListener("change", function() {
	const selectedCategory = this.value;
	//below line changes to make date filter null instead of default todays date
	//const selectedDate = document.getElementById("date-filter").value;
	const selectedDate = document.getElementById("date-filter").value || null;
	loadTrades(selectedCategory, selectedDate);
});

document.getElementById("date-filter").addEventListener("change", function() {
	const selectedDate = this.value;
	const selectedCategory = document.getElementById("category-filter").value;
	loadTrades(selectedCategory, selectedDate);
});

// Tab button logic (ViewPager-style buttons)
document.querySelectorAll(".tab-btn").forEach(button => {
	button.addEventListener("click", function() {
		const selectedCategory = this.dataset.category;
		const selectedDate = document.getElementById("date-filter").value;
		
		// Sync the dropdown with the clicked tab
		document.getElementById("category-filter").value = selectedCategory;
		
		// Highlight the active tab
		document.querySelectorAll(".tab-btn").forEach(btn => btn.classList.remove("active"));
		this.classList.add("active");
		
		// Load trades with updated category + date
		loadTrades(selectedCategory, selectedDate);
	});
});
//document.querySelectorAll(".tab-btn").forEach(button => {
    //button.addEventListener("click", function () {
        //const selectedCategory = this.dataset.category;
        
        // ✅ Highlight the active tab
        //document.querySelectorAll(".tab-btn").forEach(btn => btn.classList.remove("active"));
        //this.classList.add("active");

        // ✅ Filter trades dynamically
        //filterTradesByCategory(selectedCategory);
    //});
//});
///////////////// Tab Switching Logic ENDS HERE ///////////////// 

///////////////// COLOUR TOGGLE SL TARGET BOXEX STARTS HERE ///////////////// 


document.addEventListener("DOMContentLoaded", () => {
	document.querySelectorAll(".trade-box").forEach((box) => {
		box.addEventListener("click", () => {
			console.log(`✅ Click detected on ${box.classList}`);
		});
	});
});
async function updateTradeColor(tradeId, tradeClass, isActive) {
    try {
        const tradeRef = doc(db, "trades", tradeId);
        await updateDoc(tradeRef, {
            [`${tradeClass}_active`]: isActive
        });
        console.log(`✅ Color state updated for ${tradeClass} in ${tradeId}: ${isActive}`);
    } catch (error) {
        console.error("❌ Error updating Firestore:", error);
    }
}

async function toggleTradeColor(tradeId, tradeClass) {
	console.log(`🔄 Toggle request for Trade ID: ${tradeId}, Class: ${tradeClass}`);
	
	// ✅ Verify Admin
	const verified = await verifyAdmin();
	if (!verified) return;
	
	// ✅ Find the Trade Card
	const tradeCard = document.querySelector(`[id="${tradeId}"]`);
	if (!tradeCard) {
		console.error("❌ Trade card not found for ID:", tradeId);
		return;
	}
	
	// ✅ Find the Entire Box Instead of Just Button
	const targetBox = tradeCard.querySelector(`.${tradeClass}`);
	if (!targetBox) {
		console.error(`❌ No box found for class "${tradeClass}" in trade ID: ${tradeId}`);
		return;
	}
	
	// ✅ Toggle the 'active' Class (Change Full Box Background)
	targetBox.classList.toggle("active");
	
	// ✅ Save New State in Firebase
	const isActive = targetBox.classList.contains("active");
	await updateTradeColor(tradeId, tradeClass, isActive);
}

function renderTrade(tradeData) {
	const tradeContainer = document.getElementById("trade-container");
	if (!tradeContainer) {
		console.error("❌ ERROR: trade-container is missing in the DOM!");
		return;
	}
	
	const tradeCard = document.createElement("div");
	tradeCard.classList.add("trade-card");
	
	// ✅ Set attributes for filtering
	tradeCard.setAttribute("data-trade-id", tradeData.id);
	tradeCard.setAttribute("data-category", tradeData.category || "uncategorized");
	tradeCard.setAttribute("data-timestamp", tradeData.timestamp || new Date().toISOString());
	
	// Trade title
	const tradeName = document.createElement("h3");
	tradeName.textContent = tradeData.name || "Unnamed Trade";
	
	// Display timestamp (human readable)
	const timestamp = document.createElement("p");
	timestamp.classList.add("timestamp");
	timestamp.textContent = `Added on: ${tradeData.timestamp || "N/A"}`;
	
	// Targets and stop loss
	const targetsDiv = document.createElement("div");
	targetsDiv.classList.add("targets");
	
	function createToggleBox(className, text) {
		const box = document.createElement("div");
		box.classList.add("trade-box", className);
		box.setAttribute("data-trade-id", tradeData.id);
		
		box.addEventListener("click", () => {
			toggleTradeColor(tradeData.id, className);
		});
		
		box.textContent = text;
		return box;
	}
	
	// SL and Targets
	targetsDiv.appendChild(createToggleBox("stop-loss", `SL: ${tradeData.stopLoss || "N/A"}`));
	targetsDiv.appendChild(createToggleBox("target-1", `T1: ${tradeData.target1 || "N/A"}`));
	targetsDiv.appendChild(createToggleBox("target-2", `T2: ${tradeData.target2 || "N/A"}`));
	targetsDiv.appendChild(createToggleBox("target-3", `T3: ${tradeData.target3 || "N/A"}`));
	
	// Assemble trade card
	tradeCard.appendChild(tradeName);
	tradeCard.appendChild(timestamp);
	tradeCard.appendChild(targetsDiv);
	tradeContainer.appendChild(tradeCard);
}

// ✅ Save Toggle Status to Firestore (Optional)
async function saveTradeStatusToFirestore(tradeId, tradeClass, status) {
    const tradeRef = doc(db, "trades", tradeId);  
    await setDoc(tradeRef, { [tradeClass]: status }, { merge: true });
}

auth.onAuthStateChanged(async (user) => {
	if (user) {
		const isAdmin = await checkIfAdmin(user);

		if (isAdmin) {
			// add this here:
			enableTradeEditingForAdmins();
		}
	}
});

///////////////// COLOUR TOGGLE SL TARGET BOXES ENDS HERE ///////////////// 



///////////////// home button STARTS HERE ///////////////// 
// 🏠 Redirect to Home Page
//function goToHome() {
//window.location.href = "https://sites.google.com/view/dotview/home";
//}

///////////////// home button new changes in admin panel STARTS HERE ///////////////// 


// ✅ Fetch Home Button Link from Firestore
async function getHomeButtonLink() {
	try {
		const homeLinkRef = doc(db, "settings", "homeLink");
		const homeSnap = await getDoc(homeLinkRef);
		
		if (homeSnap.exists()) {
			return homeSnap.data().link;
		} else {
			return "https://sites.google.com/view/dotview/home"; // ✅ Default home link
		}
	} catch (error) {
		console.error("⚠️ Error fetching home link:", error);
		return "https://sites.google.com/view/dotview/home"; // Fallback
	}
}

// ✅ Update Home Button Link (Admin Only)
async function updateHomeButtonLink(newLink, password) {
	try {
		// ✅ Check admin password
		if (password !== secretKey) {
			alert("❌ Incorrect admin password!");
			return;
		}
		
		if (!newLink.startsWith("https://")) {
			alert("⚠️ Please enter a valid HTTPS URL.");
			return;
		}
		
		// ✅ Store the new link in Firestore
		const homeLinkRef = doc(db, "settings", "homeLink");
		await setDoc(homeLinkRef, { link: newLink });
		
		alert("✅ Home button link updated successfully!");
		
		// ✅ Update the button immediately
		document.getElementById("home-button").href = newLink;
		
		// ✅ Persist the updated link in localStorage for faster loading
		localStorage.setItem("homeLink", newLink);
	} catch (error) {
		console.error("⚠️ Error updating home button link:", error);
		alert("❌ Failed to update home button link. Please try again.");
	}
}
// ✅ Apply Home Link on Page Load
//document.addEventListener("DOMContentLoaded", async () => {
//	try {
//		const homeButton = document.getElementById("home-button");

// ✅ First, check if there's a stored link in localStorage
//		const storedLink = localStorage.getItem("homeLink");
//		if (storedLink) {
//			homeButton.href = storedLink; // ✅ Use stored link first (faster)
//		}

// ✅ Then, fetch the latest link from Firestore (ensures consistency)
//		const homeLink = await getHomeButtonLink();
//		homeButton.href = homeLink; // ✅ Set latest home link

// ✅ Save the latest fetched link in localStorage
//		localStorage.setItem("homeLink", homeLink);
//	} catch (error) {
//		console.error("⚠️ Error applying home link:", error);
//	}
//});


//this changes in dome when hardcoded link removed from home button . 🎯 How This Fix Works:✅ Before Firestore loads: Button shows 🏠 (Loading...) and is disabled (not clickable).✅ After Firestore loads: Button gets the correct link and becomes clickable.✅ If Firestore fails: Button shows 🏠 (Error) so users know something went wrong.Now, users will never go to an old link just because Firestore was slow! 🚀


document.addEventListener("DOMContentLoaded", async () => {
	const homeButton = document.getElementById("home-button");
	
	// Temporarily disable the button
	homeButton.style.pointerEvents = "none";
	homeButton.textContent = "🏠 (Loading...)";
	
	try {
		// Check localStorage first for faster access
		const storedLink = localStorage.getItem("homeLink");
		if (storedLink) {
			homeButton.href = storedLink;
			homeButton.textContent = "🏠";
			homeButton.style.pointerEvents = "auto"; // Re-enable button
		}
		
		// Fetch latest link from Firestore
		const homeLink = await getHomeButtonLink();
		homeButton.href = homeLink;
		homeButton.textContent = "🏠";
		homeButton.style.pointerEvents = "auto"; // Ensure it's clickable
		
		// Save latest link in localStorage
		localStorage.setItem("homeLink", homeLink);
	} catch (error) {
		console.error("⚠️ Error applying home link:", error);
		homeButton.textContent = "🏠 (Error)";
	}
});



// ✅ Handle Admin Update Button Click (Globally Available)
window.updateHomeLinkFromAdmin = async function() {
	try {
		const newLink = document.getElementById("homeLinkInput").value.trim();
		const enteredPassword = document.getElementById("adminPasswordInput").value;
		
		if (!newLink || !enteredPassword) {
			alert("⚠️ Please enter both the new link and admin password.");
			return;
		}
		
		await updateHomeButtonLink(newLink, enteredPassword);
	} catch (error) {
		console.error("⚠️ Error in updateHomeLinkFromAdmin:", error);
	}
};

// Toggle Home Button Link Update Section
document.getElementById("toggle-home-link").addEventListener("click", function() {
	const homeLinkContainer = document.getElementById("home-link-container");
	homeLinkContainer.style.display = homeLinkContainer.style.display === "none" || homeLinkContainer.style.display === "" ? "block" : "none";
});
///////////////// home button new changes in admin panel STARTS HERE ///////////////// 
///////////////// home button ENDS HERE ///////////////// 

///////////////// dark mode toggle in settings STARTS HERE ///////////////// 
// ✅ Dark Mode Toggle
document.getElementById("dark-mode-toggle").addEventListener("change", (event) => {
    if (event.target.checked) {
        document.body.classList.add("dark-mode");
        localStorage.setItem("darkMode", "enabled");
    } else {
        document.body.classList.remove("dark-mode");
        localStorage.setItem("darkMode", "disabled");
    }
});

// ✅ Restore Dark Mode Preference on Page Load
document.addEventListener("DOMContentLoaded", () => {
    if (localStorage.getItem("darkMode") === "enabled") {
        document.body.classList.add("dark-mode");
        document.getElementById("dark-mode-toggle").checked = true;
    }
});
///////////////// dark mode toggle in settings ENDS HERE ///////////////// 




///////////////// Implement JavaScript to Store Feedback STARTS HERE ///////////////// 

// ✅ Function to Submit Feedback
document.getElementById("submit-feedback").addEventListener("click", async () => {
	const user = auth.currentUser;
	const feedbackText = document.getElementById("feedback-input").value.trim();
	
	if (!user) {
		alert("You must be logged in to submit feedback.");
		return;
	}
	
	if (!feedbackText) {
		alert("Please enter your feedback before submitting.");
		return;
	}
	
	try {
		// ✅ Store feedback in Firestore
		await addDoc(collection(db, "feedback"), {
			userId: user.uid,
			email: user.email,
			feedback: feedbackText,
			timestamp: serverTimestamp()
		});
		
		alert("Thank you for your feedback!");
		document.getElementById("feedback-input").value = ""; // Clear input field
		loadUserFeedback(); // Refresh feedback list after submitting
	} catch (error) {
		console.error("Error submitting feedback:", error);
		alert("Error: Unable to submit feedback.");
	}
});

// ✅ Load only the last 10 feedback entries
async function loadUserFeedback() {
	const user = auth.currentUser;
	if (!user) return;
	
	try {
		const feedbackList = document.getElementById("feedback-list");
		feedbackList.innerHTML = "<p>Loading feedback...</p>";
		
		// Reference to Firestore collection
		const feedbackRef = collection(db, "feedback");
		
		// ✅ Ensure Firestore has the required index: (userId Ascending, timestamp Descending)
		const q = query(
			feedbackRef,
			where("userId", "==", user.uid),
			orderBy("timestamp", "desc"), // Ensure 'timestamp' exists in Firestore
			limit(10)
		);
		
		const querySnapshot = await getDocs(q);
		feedbackList.innerHTML = ""; // Clear previous entries
		
		if (querySnapshot.empty) {
			feedbackList.innerHTML = "<p>No feedback submitted yet.</p>";
		} else {
			querySnapshot.forEach((doc) => {
				const feedbackData = doc.data();
				
				// ✅ Handle missing or incorrectly formatted timestamp
				let feedbackDate = "Unknown Date";
				if (feedbackData.timestamp && feedbackData.timestamp.toDate) {
					feedbackDate = new Date(feedbackData.timestamp.toDate()).toLocaleString();
				}
				
				// Create and append list item
				const feedbackItem = document.createElement("li");
				feedbackItem.textContent = `${feedbackDate}: ${feedbackData.feedback}`;
				feedbackList.appendChild(feedbackItem);
			});
		}
	} catch (error) {
		console.error("❌ Error loading feedback:", error);
		
		// Display error in UI
		const feedbackList = document.getElementById("feedback-list");
		feedbackList.innerHTML = `<p style="color: red;">Error loading feedback. Please try again later.</p>`;
	}
}

// ✅ Load user profile & feedback when settings panel opens
document.getElementById("settings-button").addEventListener("click", () => {
	loadUserProfile();
	loadUserFeedback();
});
///////////////// Implement JavaScript to Store Feedback ENDS HERE ///////////////// 





///////////////// admin side share app STARTS HERE ///////////////// 
// ✅ Firestore References
const settingsRef = doc(db, "settings", "shareSettings");
const versionsRef = collection(db, "appVersions");

// ✅ Fetch Share Settings
async function fetchShareSettings() {
	try {
		const settingsSnap = await getDoc(settingsRef);
		return settingsSnap.exists() ? settingsSnap.data() : { url: "", message: "" };
	} catch (error) {
		console.error("❌ Error fetching share settings:", error);
		return { url: "", message: "" };
	}
}


// 🔹 Enable share + copy functionality
document.addEventListener("DOMContentLoaded", async () => {
	const shareBtn = document.getElementById("share-app");
	const copyBtn = document.getElementById("copy-link");
	
	const { url, message } = await fetchShareSettings();
	
	if (shareBtn) {
		shareBtn.addEventListener("click", () => {
			const fullText = `${message} \n\n ${url}`;
			if (navigator.share) {
				navigator.share({ title: "Dot View", text: message, url })
					.catch((err) => {
						console.warn("Share failed, falling back to copy:", err);
						navigator.clipboard.writeText(fullText);
						alert("Link copied to clipboard. Share not supported on this device.");
					});
			} else {
				navigator.clipboard.writeText(fullText);
				alert("✅ Copied full share message to clipboard! Just paste it anywhere to share. -— (your device doesn’t support direct sharing.)");
			}
		});
	}
	
	if (copyBtn) {
		copyBtn.addEventListener("click", () => {
			navigator.clipboard.writeText(url);
			alert("✅ Link copied to clipboard!");
		});
	}
});


// ✅ Fetch & Display Previous Versions
async function loadVersionHistory() {
	const versionHistoryDiv = document.getElementById("version-history");
	versionHistoryDiv.innerHTML = `<p>Loading versions... 🔄</p>`;
	
	try {
		const versionsSnap = await getDocs(query(versionsRef, orderBy("timestamp", "desc")));
		if (versionsSnap.empty) {
			versionHistoryDiv.innerHTML = `<p>No previous versions available.</p>`;
			return;
		}
		
		let historyHTML = "";
		versionsSnap.forEach((docSnap) => {
			const version = docSnap.data();
			historyHTML += `
                <div class="version-item">
                    <p><strong>Version:</strong> ${version.version}</p>
                    <p><strong>Changelog:</strong> ${version.changelog || "No details provided"}</p>
                    <!--<p><a href="${version.url}" target="_blank">📥 Download</a></p>-->
                    <p>
                      <a href="${version.url}" target="_blank">📥 Download</a>
                      <button onclick="deleteVersionById('${docSnap.id}')">🗑️ Delete</button>
                    </p>
                    <hr>
                </div>
            `;
		});
		
		versionHistoryDiv.innerHTML = historyHTML;
	} catch (error) {
		console.error("❌ Error loading version history:", error);
		versionHistoryDiv.innerHTML = `<p>Failed to load versions.</p>`;
	}
}

async function deleteVersionById(docId) {
  const password = prompt("Enter Admin Password to delete version:");
  if (password !== secretKey) {
    alert("❌ Incorrect password!");
    return;
  }
  
  if (!confirm("Are you sure you want to delete this version?")) return;
  
  try {
    await deleteDoc(doc(versionsRef, docId));
    alert("✅ Version deleted!");
    loadVersionHistory(); // refresh list
  } catch (err) {
    console.error("❌ Error deleting version:", err);
    alert("❌ Failed to delete version.");
  }
}

window.deleteVersionById = deleteVersionById; // Make accessible to HTML

// ✅ Update Share Settings (Admin Only)
async function updateShareSettings() {
	const linkInput = document.getElementById("share-link-input");
	const messageInput = document.getElementById("share-message-input");
	const passwordInput = document.getElementById("admin-password");
	
	if (!linkInput || !messageInput || !passwordInput) {
		console.error("❌ One or more required input fields are missing!");
		return;
	}
	
	const newLink = linkInput.value.trim();
	const newMessage = messageInput.value.trim();
	const enteredPassword = passwordInput.value.trim();
	
	if (!newLink || !newMessage) {
		alert("⚠️ Please enter both link and message!");
		return;
	}
	
	if (enteredPassword !== secretKey) {
		alert("❌ Incorrect Admin Password!");
		return;
	}
	
	try {
		await setDoc(settingsRef, { url: newLink, message: newMessage }, { merge: true });
		alert("✅ Share settings updated successfully!");
	} catch (error) {
		console.error("❌ Error updating share settings:", error);
	}
}

async function uploadNewVersion() {
    const versionInput = document.getElementById("app-version");
    const downloadURLInput = document.getElementById("download-url");
    const changelogInput = document.getElementById("changelog");
    const forceUpdateCheckbox = document.getElementById("force-update-version");
    const passwordInput = document.getElementById("admin-password");

    if (!versionInput || !downloadURLInput || !changelogInput || !forceUpdateCheckbox || !passwordInput) {
        console.error("❌ One or more required input fields are missing!");
        return;
    }

    const version = versionInput.value.trim();
    const downloadURL = downloadURLInput.value.trim();
    const changelog = changelogInput.value.trim();
    const forceUpdate = forceUpdateCheckbox.checked;
    const enteredPassword = passwordInput.value.trim();

    if (!version || !downloadURL) {
        alert("⚠️ Version and download link are required!");
        return;
    }

    if (enteredPassword !== secretKey) {
        alert("❌ Incorrect Admin Password!");
        return;
    }

    try {
        await addDoc(versionsRef, {
            version,
            url: downloadURL,
            changelog,
            forceUpdate,
            timestamp: serverTimestamp()
        });
        alert("✅ New version uploaded successfully!");
        loadVersionHistory(); // Refresh versions list
    } catch (error) {
        console.error("❌ Error uploading new version:", error);
    }
}

// ✅ Check for Latest Version (Forcing Users to Update if Needed)
async function checkForUpdate() {
	try {
		const versionsSnap = await getDocs(query(versionsRef, orderBy("timestamp", "desc"), limit(1)));
		if (!versionsSnap.empty) {
			const latestVersion = versionsSnap.docs[0].data();
			const storedVersion = localStorage.getItem("userVersion") || "0.0";
			
			console.log("Latest Version:", latestVersion.version);
			console.log("Stored Version:", storedVersion);
			
			if (latestVersion.forceUpdate && storedVersion !== latestVersion.version) {
				alert(`⚠️ A new mandatory update (${latestVersion.version}) is available!`);
				window.location.href = latestVersion.url;
			}
		}
	} catch (error) {
		console.error("❌ Error checking for updates:", error);
	}
}

// Automatically update localStorage with latest version after successful load
async function syncUserVersion() {
	const snap = await getDocs(query(versionsRef, orderBy("timestamp", "desc"), limit(1)));
	if (!snap.empty) {
		const latest = snap.docs[0].data();
		localStorage.setItem("userVersion", latest.version);
	}
}

document.addEventListener("DOMContentLoaded", async () => {
	//await checkForUpdate(); // check if forced update is needed
	//await syncUserVersion(); // save the version if user has latest
	await checkForUpdate(); 
});

// ✅ Attach Event Listeners
document.getElementById("update-share-settings").addEventListener("click", updateShareSettings);
document.getElementById("upload-version").addEventListener("click", uploadNewVersion);

// ✅ Load Previous Versions on Page Load
document.addEventListener("DOMContentLoaded", loadVersionHistory);
//document.addEventListener("DOMContentLoaded", checkForUpdate);


// Toggle Manage App Share & Updates Section
document.getElementById("toggle-share-updates").addEventListener("click", function() {
	const shareUpdatesContainer = document.getElementById("share-updates-container");
	shareUpdatesContainer.style.display = shareUpdatesContainer.style.display === "none" || shareUpdatesContainer.style.display === "" ? "block" : "none";
});

// Toggle App Version Control Section
document.getElementById("toggle-app-version-control").addEventListener("click", function() {
	const versionControlContainer = document.getElementById("app-version-control-container");
	versionControlContainer.style.display = versionControlContainer.style.display === "none" || versionControlContainer.style.display === "" ? "block" : "none";
});

// Toggle Previous Versions Section
document.getElementById("toggle-version-history").addEventListener("click", function() {
	const versionHistoryContainer = document.getElementById("version-history-container");
	versionHistoryContainer.style.display = versionHistoryContainer.style.display === "none" || versionHistoryContainer.style.display === "" ? "block" : "none";
});
///////////////// Admin side share app ENDS HERE ///////////////// 



////////////////User side share app starts here //////////////



////////////////User side share app ends here ///////////////





///////////////// Enable/Disable Animations STARTS HERE /////////////////
// ✅ Toggle Animations
document.getElementById("animation-toggle").addEventListener("change", (event) => {
    if (event.target.checked) {
        document.body.classList.remove("no-animation");
        localStorage.setItem("animationsEnabled", "true");
    } else {
        document.body.classList.add("no-animation");
        localStorage.setItem("animationsEnabled", "false");
    }
});

// ✅ Restore Animation Preference on Page Load
document.addEventListener("DOMContentLoaded", () => {
    if (localStorage.getItem("animationsEnabled") === "false") {
        document.body.classList.add("no-animation");
        document.getElementById("animation-toggle").checked = false;
    }
});

///////////////// Enable/Disable Animations  HERE ///////////////// 

///////////////// Apply Font Size Dynamically STARTS HERE ///////////////// 
// ✅ Apply Font Size
function applyFontSize(size) {
    document.body.style.fontSize = size === "small" ? "14px" : size === "large" ? "18px" : "16px";
    localStorage.setItem("fontSize", size); // Save preference
}

// ✅ Load Saved Font Size
document.getElementById("font-size").addEventListener("change", (event) => {
    applyFontSize(event.target.value);
});

// ✅ Restore Font Size on Page Load
document.addEventListener("DOMContentLoaded", () => {
    const savedFontSize = localStorage.getItem("fontSize") || "medium";
    document.getElementById("font-size").value = savedFontSize;
    applyFontSize(savedFontSize);
});
///////////////// Apply Font Size Dynamically ENDS HERE ///////////////// 


///////////////// Implement Delete Account Functionality STARTS HERE ///////////////// 

// ✅ Function to Delete Account
document.getElementById("delete-account").addEventListener("click", async () => {
    const user = auth.currentUser;

    if (!user) {
        alert("You must be logged in to delete your account.");
        return;
    }

    // Confirm with the user before deletion
    const confirmDelete = confirm("⚠️ Are you sure you want to delete your account? This action cannot be undone.");
    if (!confirmDelete) return;

    try {
        // ✅ Ask for password to confirm deletion
        const password = prompt("Enter your password to confirm deletion:");
        if (!password) return;

        const credential = EmailAuthProvider.credential(user.email, password);
        await reauthenticateWithCredential(user, credential);

        // ✅ Delete user data from Firestore
        const userRef = doc(db, "users", user.uid);
        await deleteDoc(userRef);

        // ✅ Delete user from Firebase Authentication
        await deleteUser(user);

        alert("Your account has been deleted.");
        window.location.href = "login.html"; // Redirect to login page
    } catch (error) {
        console.error("Error deleting account:", error);
        alert("Error: " + error.message);
    }
});
///////////////// Implement Delete Account Functionality ENDS HERE ///////////////// 


///////////////// Implement Edit & Save Profile Functionality STARTS HERE ///////////////// 

// ✅ Function to Load User Profile Data (Declared ONLY ONCE)
async function loadUserProfile() {
    const user = auth.currentUser;

    if (!user) {
        console.warn("User not logged in.");
        return;
    }

    try {
        const userRef = doc(db, "users", user.uid);
        const docSnap = await getDoc(userRef);
        let data = docSnap.exists() ? docSnap.data() : {};

        // ✅ Populate fields with user data
        document.getElementById("edit-name").value = data.name || "";
        document.getElementById("edit-phone").value = data.phone || "";
        document.getElementById("edit-gender").value = data.gender || "";
        document.getElementById("edit-birthdate").value = data.birthdate || "";
        document.getElementById("edit-address").value = data.address || "";

        // ✅ Auto-fill user email from Firebase Auth (Not Editable)
        document.getElementById("edit-email").value = user.email;  
    } catch (error) {
        console.error("Error loading user profile:", error);
    }
}

// ✅ Function to Save Updated Profile Data
async function saveUserProfile() {
    const user = auth.currentUser;

    if (!user) {
        alert("You must be logged in to update your profile.");
        return;
    }

    const updatedData = {
        email: user.email, // ✅ Save the email automatically
        name: document.getElementById("edit-name").value.trim(),
        phone: document.getElementById("edit-phone").value.trim(),
        gender: document.getElementById("edit-gender").value.trim(),
        birthdate: document.getElementById("edit-birthdate").value.trim(),
        address: document.getElementById("edit-address").value.trim()
    };

    try {
        // ✅ Save profile to `users`
        const userRef = doc(db, "users", user.uid);
        await setDoc(userRef, updatedData, { merge: true });

        // ✅ Save profile to `users1` (copy)
        const userRef1 = doc(db, "users1", user.uid);
        await setDoc(userRef1, updatedData, { merge: true });

        alert("Profile updated successfully!");
        loadUserProfile(); // ✅ Reload profile after update
    } catch (error) {
        console.error("Error saving profile:", error);
    }
}

// ✅ Attach Event Listeners (Declared Only Once)
document.getElementById("settings-button").addEventListener("click", loadUserProfile);
document.getElementById("save-profile").addEventListener("click", saveUserProfile);
///////////////// Implement Edit & Save Profile Functionality ENDS HERE ///////////////// 


/////////////////change password  STARTS HERE ///////////////// 
// ✅ Change Password Function
document.getElementById("change-password").addEventListener("click", async () => {
    const user = auth.currentUser;

    if (!user) {
        alert("You must be logged in to change your password.");
        return;
    }

    // Ask for old password to reauthenticate the user
    const oldPassword = prompt("Enter your current password:");
    if (!oldPassword) return;

    const credential = EmailAuthProvider.credential(user.email, oldPassword);

    try {
        // ✅ Reauthenticate the user
        await reauthenticateWithCredential(user, credential);

        // Ask for new password
        const newPassword = prompt("Enter your new password (min 6 characters):");
        if (!newPassword || newPassword.length < 6) {
            alert("Password must be at least 6 characters long.");
            return;
        }

        // ✅ Update password in Firebase Authentication
        await updatePassword(user, newPassword);
        alert("Password changed successfully!");
    } catch (error) {
        console.error("Error changing password:", error);
        alert("Error: " + error.message);
    }
});


/////////////////change password ENDS HERE ///////////////// 



/////////////////settings button STARTS HERE /////////////////
const settingsButton = document.getElementById("settings-button");
const settingsPanel = document.getElementById("settings-panel");
const closeSettingsButton = document.getElementById("close-settings");
const hideSettingsButton = document.getElementById("hide-settings");

// ✅ Open & Close Settings Panel
settingsButton.addEventListener("click", () => {
    if (settingsPanel.classList.contains("hidden")) {
        settingsPanel.classList.remove("hidden");
        settingsPanel.style.display = "block"; // ✅ Ensure it's visible
        settingsPanel.style.animation = "slideIn 0.3s ease-in-out";
    } else {
        settingsPanel.style.animation = "fadeOut 0.3s ease-in-out";
        setTimeout(() => {
            settingsPanel.classList.add("hidden");
            settingsPanel.style.display = "none"; // ✅ Hide properly
        }, 250);
    }
});

// ✅ Close Settings Panel (Using Close Button)
closeSettingsButton.addEventListener("click", () => {
    settingsPanel.style.animation = "fadeOut 0.3s ease-in-out";
    setTimeout(() => {
        settingsPanel.classList.add("hidden");
        settingsPanel.style.display = "none";
    }, 250);
});

// ✅ Hide Settings Panel (Using Hide Button)
hideSettingsButton.addEventListener("click", () => {
    settingsPanel.style.animation = "fadeOut 0.3s ease-in-out";
    setTimeout(() => {
        settingsPanel.classList.add("hidden");
        settingsPanel.style.display = "none";
    }, 250);
});

// ✅ Close Panel When Clicking Outside
document.addEventListener("click", (event) => {
    if (
        !settingsPanel.contains(event.target) &&
        event.target !== settingsButton &&
        !settingsPanel.classList.contains("hidden")
    ) {
        settingsPanel.style.animation = "fadeOut 0.3s ease-in-out";
        setTimeout(() => {
            settingsPanel.classList.add("hidden");
            settingsPanel.style.display = "none";
        }, 250);
    }
});

/////////////////settings button ends HERE /////////////////

/////////////////TOGGLE THEME STARTS HERE /////////////////
const themeToggleButton = document.getElementById("theme-toggle");
const body = document.body;

// Check Local Storage for Theme Preference
if (localStorage.getItem("theme") === "dark") {
	body.classList.add("dark-theme");
	//themeToggleButton.textContent = "☀️ Light Mode";
	//themeToggleButton.innerHTML = '<span style="font-size: 24px;">☀️</span> Light Mode';
	themeToggleButton.innerHTML = '<span style="font-size: 24px;">☀️</span>';
}

// Toggle Theme on Button Click
themeToggleButton.addEventListener("click", () => {
	body.classList.toggle("dark-theme");
	
	// Save to Local Storage
	if (body.classList.contains("dark-theme")) {
		localStorage.setItem("theme", "dark");
		//themeToggleButton.textContent = "☀️ Light Mode";
		//themeToggleButton.innerHTML = '<span style="font-size: 24px;">☀️</span> Light Mode';
		themeToggleButton.innerHTML = '<span style="font-size: 24px;">☀️</span>';
	} else {
		localStorage.setItem("theme", "light");
		//themeToggleButton.textContent = "🌙 Dark Mode";
		//themeToggleButton.innerHTML = '<span style="font-size: 24px;">🌙 ️</span> Light Mode';
		themeToggleButton.innerHTML = '<span style="font-size: 24px;">🌙 ️</span>';
	}
});
/////////////////////TOGGLE THEME ENDED HERE ///////////////////



// ✅ Function to save notification in Firestore
// ✅ Function to save notification in Firestore
async function saveNotification(message, tradeId) {
	await addDoc(collection(db, "notifications"), {
		message: message,
		tradeId: tradeId,
		timestamp: new Date() 
	});
}

// ✅ Function to display notifications in the UI (Newest First)
function displayNotification(notificationId, message, tradeId, timestamp) {
	const notificationList = document.getElementById("notification-list");
	
	const li = document.createElement("li");
	const timeString = new Date(timestamp.toDate()).toLocaleString();
	
	li.innerHTML = `
        <span class="notification-message">${message}</span>
        <span class="notification-time">${timeString}</span>
        <button class="close-btn" data-id="${notificationId}">❌</button>
    `;
	
	li.classList.add("notification-item");
	li.addEventListener("click", () => {
		if (tradeId) {
			scrollToTrade(tradeId);
		}
	});
	
	// Close button to remove notification
	li.querySelector(".close-btn").addEventListener("click", async (event) => {
		event.stopPropagation(); // Prevent click from opening the trade
		await deleteDoc(doc(db, "notifications", notificationId));
	});
	
	// Add to top (newest first)
	notificationList.prepend(li);
}

// ✅ Function to scroll to a specific trade when a notification is clicked
function scrollToTrade(tradeId) {
    let attempts = 0;

    const highlightTrade = (tradeElement) => {
        tradeElement.scrollIntoView({ behavior: "smooth", block: "center" });
        tradeElement.classList.add("highlight");
        setTimeout(() => {
            tradeElement.classList.remove("highlight");
        }, 3000); // Remove highlight after 3 seconds
    };

    const interval = setInterval(() => {
        const tradeElement = document.getElementById(tradeId);

        if (tradeElement || attempts > 10) { // Try for 1 second max
            clearInterval(interval);

            if (tradeElement) {
                // 🔹 Step 1: Find the trade's category
                const tradeCategory = tradeElement.getAttribute("data-category");

                if (tradeCategory) {
                    // 🔹 Step 2: Switch to the correct tab
                    const categoryButton = document.querySelector(`.tab-btn[data-category="${tradeCategory}"]`);
                    
                    if (categoryButton) {
                        categoryButton.click(); // Simulate clicking the tab
                        console.log("✅ Tab switched to:", tradeCategory);

                        // 🔹 Step 3: Wait for tab switch to complete before scrolling
                        setTimeout(() => {
                            highlightTrade(tradeElement);
                        }, 500); // 500ms delay for smooth transition
                    } else {
                        console.warn("⚠️ No tab button found for category:", tradeCategory);
                    }
                } else {
                    console.warn("⚠️ No category found for trade:", tradeId);
                }
            }
        }

        attempts++;
    }, 100); // Check every 100ms
}


// ✅ Listen for new trades and save notifications in Firestore (No Likes/Dislikes)
onSnapshot(collection(db, "trades"), (snapshot) => {
	snapshot.docChanges().forEach((change) => {
		if (change.type === "added") {
			saveNotification(`📢 New Trade Added: ${change.doc.data().name}`, change.doc.id).then(() => {
				playNotificationSound(); // 🔊 Play sound
				showNotificationPanel(); // ✅ Open notification section
			});
		} else if (change.type === "modified" && !("likes" in change.doc.data()) && !("dislikes" in change.doc.data())) {
			saveNotification(`✏️ Trade Updated: ${change.doc.data().name}`, change.doc.id).then(() => {
				playNotificationSound(); // 🔊 Ensure sound plays for updates
				showNotificationPanel(); // ✅ Ensure panel opens
			});
		} else if (change.type === "removed") {
			saveNotification(`🗑 Trade Deleted: ${change.doc.data().name}`, change.doc.id);
			playNotificationSound();
		}
	});
});

// ✅ Load latest 15 notifications + listen for new ones
onSnapshot(
	query(collection(db, "notifications"), orderBy("timestamp", "desc"), limit(15)),
	(snapshot) => {
		const notificationList = document.getElementById("notification-list");
		notificationList.innerHTML = ""; // Clear old notifications
		
		snapshot.forEach((doc) => {
			const notification = doc.data();
			displayNotification(doc.id, notification.message, notification.tradeId, notification.timestamp);
		});
		
		console.log(`✅ Loaded latest ${snapshot.size} notifications.`);
		
		// Show notification panel if there are notifications
		if (!snapshot.empty) {
			document.getElementById("notification-section").style.display = "block";
		}
	}
);

function showNotificationPanel() {
	const notificationSection = document.getElementById("notification-section");
	if (notificationSection && notificationSection.style.display !== "block") {
		notificationSection.style.display = "block";
		console.log("✅ Notification panel opened automatically");
	}
}


// ✅ Function to delete all notifications
clearAllBtn.addEventListener("click", () => {
	deleteNotificationsInBatches(500); // ✅ Call optimized batch delete function
});

async function deleteNotificationsInBatches(batchSize = 500) {
	try {
		const notificationsRef = collection(db, "notifications");
		
		let totalDeleted = 0;
		let hasMore = true;
		
		while (hasMore) {
			// ✅ Fetch limited notifications (reduces reads)
			const querySnapshot = await getDocs(query(notificationsRef, limit(batchSize)));
			
			if (querySnapshot.empty) {
				hasMore = false;
				break;
			}
			
			const batch = writeBatch(db);
			querySnapshot.docs.forEach((docSnap) => {
				batch.delete(doc(db, "notifications", docSnap.id));
			});
			
			await batch.commit(); // ✅ Process batch asynchronously
			totalDeleted += querySnapshot.size;
			console.log(`✅ Deleted ${totalDeleted} notifications so far...`);
			
			// ✅ Let the UI update & prevent freezing
			await new Promise((resolve) => setTimeout(resolve, 100));
		}
		
		console.log("✅ All notifications deleted successfully.");
		
		// ✅ Clear UI smoothly
		document.getElementById("notification-list").innerHTML = "";
		document.getElementById("notification-section").style.display = "none";
		
	} catch (error) {
		console.error("❌ Error deleting notifications:", error);
	}
}

// ✅ Hide notification panel without clearing notifications
hideNotificationBtn.addEventListener("click", () => {
	const notificationSection = document.getElementById("notification-section");
	if (notificationSection) {
		notificationSection.style.display = "none";
	}
});

// ✅ Toggle notification section visibility when bell icon is clicked
document.getElementById("notification-bell").addEventListener("click", () => {
	const notificationSection = document.getElementById("notification-section");
	if (notificationSection) {
		notificationSection.style.display =
			notificationSection.style.display === "block" ? "none" : "block";
	}
});

// Toggle Notification Panel Section inside admin panel.because admin clear all takes page handout
document.getElementById("toggle-notification-panel").addEventListener("click", function () {
    const notificationPanel = document.getElementById("notification-panel-container");
    notificationPanel.style.display = notificationPanel.style.display === "none" || notificationPanel.style.display === "" ? "block" : "none";
});






let isAdmin = false; 


async function verifyAdmin() {
	try {
		// Wait if secretKey is not yet loaded
		if (!secretKey) {
			await fetchSecretKey(); // Wait until secretKey is available
		}
		
		const user = auth.currentUser;
		if (!user) {
			alert("❌ You must be logged in.");
			return false;
		}
		
		const isAdminUser = await checkIfAdmin(user);
		if (!isAdminUser) {
			alert("❌ Not Authorized.");
			return false;
		}
		
		// ✅ Always ask for password
		const password = prompt("🔑 Enter Admin Password:");
		if (password !== secretKey) {
			alert("❌ Incorrect Password!");
			return false;
		}
		
		console.log("✅ Admin authenticated! Showing admin buttons...");
		
		// ✅ Show all admin buttons after successful authentication
		document.getElementById("admin-controls").classList.remove("hidden");
		document.getElementById("remove-all-trades").classList.remove("hidden");
		document.getElementById("add-trade").classList.remove("hidden");
		document.getElementById("trade-form-container").classList.remove("hidden");
		document.querySelectorAll(".delete-trade-btn").forEach(btn => btn.classList.remove("hidden"));
		document.querySelectorAll(".update-btn").forEach(btn => btn.classList.remove("hidden"));
		document.querySelectorAll(".delete-update-btn").forEach(btn => btn.classList.remove("hidden"));
		
		return true;
	} catch (error) {
		console.error("❌ Error in verifyAdmin:", error);
		alert("⚠️ Unexpected error verifying admin.");
		return false;
	}
}

async function checkIfAdmin(user) {
	if (!user) return false;
	console.log("Checking admin role for:", user.email);
	
	// Wait for adminEmail to be available
	if (!ADMIN_EMAIL) {
		await fetchAdminEmail();
	}
	
	if (user.email === ADMIN_EMAIL) {
		console.log("✅ User is Firestore-configured admin.");
		return true;
	}
	
	try {
		const token = await user.getIdTokenResult();
		console.log("Admin Claims from Firebase:", token.claims);
		
		return token.claims?.admin || false;
	} catch (error) {
		console.error("❌ Error checking admin status:", error);
		return false;
	}
}

adminBtn.addEventListener("click", async () => {
    const verified = await verifyAdmin();
    if (!verified) return;

    document.getElementById("trade-form-container").classList.remove("hidden");
    document.getElementById("add-trade").classList.remove("hidden");
    document.getElementById("remove-all-trades").classList.remove("hidden");

    isAdmin = true;
    tradeFormContainer.classList.remove("hidden");
    removeAllTradesBtn.classList.remove("hidden");
    document.querySelectorAll(".delete-trade-btn, .update-btn").forEach(btn => btn.classList.remove("hidden"));
});


async function addTrade() {
	const verified = await verifyAdmin();
	if (!verified) return;
	
	const addTradeBtn = document.getElementById("add-trade");
	addTradeBtn.disabled = true;
	
	const tradeAction = document.getElementById("trade-action")?.value.trim() || "";
	const tradeAsset = document.getElementById("trade-asset")?.value.trim() || "";
	const tradeEntry = document.getElementById("trade-entry-price")?.value.trim() || "";
	
	if (!tradeAction || !tradeAsset || !tradeEntry) {
		alert("❌ Please fill out all required fields: Action, Asset, and Entry Price.");
		addTradeBtn.disabled = false;
		return;
	}
	
	// ✅ Get dropdown or custom values
	let tradeType = document.getElementById("trade-type")?.value;
	if (tradeType === "Custom") {
		tradeType = document.getElementById("custom-trade-type")?.value.trim();
		if (!tradeType) {
			alert("❌ Please enter a custom Trade Type.");
			addTradeBtn.disabled = false;
			return;
		}
	}
	
	let tradeState = document.getElementById("trade-state")?.value;
	if (tradeState === "Custom") {
		tradeState = document.getElementById("custom-trade-state")?.value.trim();
		if (!tradeState) {
			alert("❌ Please enter a custom Trade State.");
			addTradeBtn.disabled = false;
			return;
		}
	}
	
	// ✅ Ask for password again before saving labels
	const labelPassword = prompt("Enter admin password to confirm labels:");
	if (labelPassword !== secretKey) {
		alert("❌ Incorrect password! Trade not added.");
		addTradeBtn.disabled = false;
		return;
	}
	
	// ✅ Add to Firestore
	const categoryElement = document.getElementById("category-filter");
	const categoryValue = categoryElement ? categoryElement.value : "Uncategorized";
	
	const tradeData = {
		action: tradeAction,
		asset: tradeAsset,
		entryPrice: tradeEntry,
		name: `${tradeAction} ${tradeAsset} @ ${tradeEntry}`,
		sl: document.getElementById("trade-sl")?.value.trim() || "",
		t1: document.getElementById("trade-t1")?.value.trim() || "",
		t2: document.getElementById("trade-t2")?.value.trim() || "",
		t3: document.getElementById("trade-t3")?.value.trim() || "",
		chartLink: document.getElementById("tradeChartLinkInput")?.value.trim() || "", // <-- NEW
		tradeType: tradeType,
		tradeState: tradeState,
		category: categoryValue,
		timestamp: new Date(),
		updates: [],
		likes: 0,
		dislikes: 0
	};
	
	console.log("✅ Adding trade with data:", tradeData);
	
	try {
		await addDoc(collection(db, "trades"), tradeData);
		console.log("✔️ Trade successfully added!");
		clearTradeForm();
	} catch (error) {
		console.error("❌ Error adding trade:", error);
	}
	
	addTradeBtn.disabled = false;
	
}

// Clears form fields after adding a trade
function clearTradeForm() {
	["trade-action", "trade-asset", "trade-entry-price", "trade-sl", "trade-t1", "trade-t2", "trade-t3", " tradeChartLinkInput"].forEach(id => {
		const element = document.getElementById(id);
		if (element) element.value = "";
	});
}

// Attach only ONE event listener
document.getElementById("add-trade").addEventListener("click", addTrade);


function attachEventListeners() {
    document.querySelectorAll(".history-btn").forEach(button => {
        button.addEventListener("click", async (e) => {
            const tradeId = e.target.dataset.id;
            let historyDiv = document.getElementById(`history-${tradeId}`);

            if (!historyDiv) {
                console.error(`No history div found for trade ID: ${tradeId}`);
                return;
            }

            // Toggle visibility
            if (historyDiv.style.display === "none" || historyDiv.style.display === "") {
                historyDiv.style.display = "block";
                await loadTradeHistory(tradeId, historyDiv);
            } else {
                historyDiv.style.display = "none";
            }
        });
    });
    
    document.querySelectorAll(".update-btn").forEach(button => {
        button.addEventListener("click", async (e) => {
            const verified = await verifyAdmin();
            if (!verified) return;

            const tradeId = e.target.dataset.id;
            const newUpdate = prompt("Enter update:");
            if (newUpdate) {
                await addTradeUpdate(tradeId, newUpdate);
                await loadTradeHistory(tradeId, document.getElementById(`history-${tradeId}`));
            }
        });
    });
    document.querySelectorAll(".like-btn").forEach(button => {
        button.addEventListener("click", async (e) => {
            const tradeId = e.target.dataset.id;
            const tradeRef = doc(db, "trades", tradeId);
            const tradeSnap = await getDoc(tradeRef);
            if (tradeSnap.exists()) {
                const tradeData = tradeSnap.data();
                await updateDoc(tradeRef, { likes: tradeData.likes + 1 });
            }
        });
    });

    document.querySelectorAll(".dislike-btn").forEach(button => {
        button.addEventListener("click", async (e) => {
            const tradeId = e.target.dataset.id;
            const tradeRef = doc(db, "trades", tradeId);
            const tradeSnap = await getDoc(tradeRef);
            if (tradeSnap.exists()) {
                const tradeData = tradeSnap.data();
                await updateDoc(tradeRef, { dislikes: tradeData.dislikes + 1 });
            }
        });
    });
    document.addEventListener("DOMContentLoaded", function() {
    console.log("DOM fully loaded.");

    const adminControls = document.getElementById("admin-controls");
    const tradeForm = document.getElementById("trade-form-container");
    const addTradeBtn = document.getElementById("add-trade");
    const removeAllTradesBtn = document.getElementById("remove-all-trades");

    if (!adminControls || !tradeForm || !addTradeBtn || !removeAllTradesBtn) {
        console.error("❌ One or more admin elements are missing!");
    } else {
        console.log("✅ All admin elements are present.");
    }
});

    document.querySelectorAll(".delete-trade-btn").forEach(button => {
        button.addEventListener("click", async (e) => {
            const verified = await verifyAdmin();
            if (!verified) return;

            const tradeId = e.target.dataset.id;
            await deleteDoc(doc(db, "trades", tradeId));
        });
    });
}
async function deleteTradeUpdate(tradeId, updateIndex) {
    const tradeRef = doc(db, "trades", tradeId);
    const tradeSnap = await getDoc(tradeRef);

    if (tradeSnap.exists()) {
        let tradeData = tradeSnap.data();
        tradeData.updates.splice(updateIndex, 1); // Remove the update at the given index

        await updateDoc(tradeRef, { updates: tradeData.updates });
    }
}

async function addTradeUpdate(tradeId, updateText) {
	const tradeRef = doc(db, "trades", tradeId);
	const tradeSnap = await getDoc(tradeRef);
	
	if (tradeSnap.exists()) {
		const tradeData = tradeSnap.data();
		const updatedHistory = [
			{ text: updateText, timestamp: new Date() },
			...tradeData.updates // Ensure newest updates appear first
		];
		
		await updateDoc(tradeRef, { updates: updatedHistory });
		
		// ✅ Save Notification in Firestore & play sound
		await addDoc(collection(db, "notifications"), {
			message: `✏️ Trade Updated: ${tradeData.name}`,
			tradeId: tradeId,
			timestamp: new Date()
		}).then(() => {
			console.log("🔊 Playing sound for trade update");
			playNotificationSound(); // 🔊 Ensure sound plays
			showNotificationPanel(); // ✅ Open notification panel
		}).catch(error => console.error("❌ Error saving trade update notification:", error));
	}
}




async function loadTrades(selectedCategory = "all", selectedDate = null) {
	const tradeContainer = document.querySelector(".trade-container");
	
	// 🚨 Check if user is logged in BEFORE loading trades
	const user = auth.currentUser;
	if (!user) {
		console.warn("❌ User not logged in. Trades will not load.");
		tradeContainer.innerHTML = `<p style="color: red;">You must be logged in to see trades. ❌</p>`;
		return;
	}
	
	tradeContainer.innerHTML = `<p>Loading trades... 🔄</p>`;
	
	try {
		// ✅ Check if the user is Admin
		const isAdmin = await checkIfAdmin(user);
		console.log(`🔍 Admin Check → ${isAdmin ? "✅ Yes (Full Access)" : "❌ No"}`);
		
		// ✅ Fetch user premium access from Firestore by email
		const userEmail = user.email.toLowerCase();
		const userQuery = query(collection(db, "users1"), where("email", "==", userEmail));
		const userSnap = await getDocs(userQuery);
		
		if (userSnap.empty) {
			console.error("❌ User document not found in users1!");
			return;
		}
		
		// ✅ Get the first matching document
		const userData = userSnap.docs[0].data();
		const userPremiumAccess = userData?.premiumAccess || {};
		
		// ✅ Fetch trade locks from Firestore
		const lockRef = doc(db, "tradeSettings", "visibility");
		const lockSnap = await getDoc(lockRef);
		const tradeLocks = lockSnap.exists() ? lockSnap.data() : {};
		
		// ✅ Build query with category and date filters
		const constraints = [];
		
		if (selectedCategory !== "all") {
			constraints.push(where("category", "==", selectedCategory));
		}
		
		if (selectedDate) {
			const start = new Date(selectedDate);
			start.setHours(0, 0, 0, 0);
			const end = new Date(start);
			end.setDate(end.getDate() + 1);
			
			constraints.push(where("timestamp", ">=", start));
			constraints.push(where("timestamp", "<", end));
		}
		
		constraints.push(orderBy("timestamp", "desc"));
		
		const q = query(collection(db, "trades"), ...constraints);
		
		// ✅ Listen for real-time updates
		onSnapshot(q, (snapshot) => {
			tradeContainer.innerHTML = ""; // Clear previous trades
			
			if (snapshot.empty) {
				console.warn(`⚠️ No trades found for filters.`);
				tradeContainer.innerHTML = `<p>No trades found for selected filters. 📭</p>`;
				return;
			}
			
			// ✅ Render trade cards with proper permissions
			snapshot.forEach((doc) => {
				const trade = doc.data();
				const tradeId = doc.id;
				
				// ✅ Handle missing category
				trade.category = trade.category || "Uncategorized";
				
				console.log(`✅ Loaded trade: ${trade.name}, Category: ${trade.category}`);
				
				// ✅ Ensure Admin Always Has Full Access
				const tradeCard = createTradeCard(trade, tradeId, isAdmin ? {} : userPremiumAccess, tradeLocks);
				if (tradeCard) tradeContainer.appendChild(tradeCard);
			});
			
			// ✅ Ensure events are attached after loading trades
			attachEventListeners();
			attachToggleListeners();
		});
	} catch (error) {
		console.error("❌ Error loading trades:", error);
		tradeContainer.innerHTML = `<p style="color: red;">Failed to load trades. 🚨</p>`;
	}
}


// ✅ Listen for changes in Global Locks (tradeSettings/visibility)
let tradeLockData = {}; // Store trade lock state globally

function listenForTradeLockChanges() {
	const tradeLockRef = doc(db, "tradeSettings", "visibility");
	
	onSnapshot(tradeLockRef, (docSnap) => {
		if (docSnap.exists()) {
			tradeLockData = docSnap.data();
		} else {
			tradeLockData = {}; // Reset if no data found
		}
		console.log("🔄 Trade lock data updated:", tradeLockData);
		checkTradeLocking(); // Re-check access when lock changes
	}, (error) => {
		console.error("❌ Error listening for trade lock updates:", error);
	});
}

// ✅ Start listening when the page loads
document.addEventListener("DOMContentLoaded", listenForTradeLockChanges);

// 🔹 Ensure trade lock data is fetched on page load
// 🔹 Fetch trade lock settings on page load
async function fetchInitialTradeLockData() {
	const tradeLockRef = doc(db, "tradeSettings", "visibility");
	
	try {
		const tradeLockSnap = await getDoc(tradeLockRef);
		if (tradeLockSnap.exists()) {
			tradeLockData = tradeLockSnap.data();
			console.log("✅ Trade lock data loaded on page refresh:", tradeLockData);
		} else {
			tradeLockData = {}; // Reset if no data found
			console.warn("⚠️ No trade lock data found, setting default locks.");
		}
		
		checkTradeLocking(); // ✅ Apply the lock settings after loading
		
	} catch (error) {
		console.error("❌ Error fetching trade lock data on refresh:", error);
	}
}

// ✅ Ensure trade lock data is fetched & updates in real-time
document.addEventListener("DOMContentLoaded", async () => {
	await fetchInitialTradeLockData(); // 🔹 Load trade locks on refresh
	listenForTradeLockChanges(); // 🔹 Keep real-time updates active
});

// ✅ Check if a trade category is locked (Real-time check)
function checkIfTradeLocked(category) {
	return tradeLockData[category] || false; // Returns true if locked, false otherwise
}

// ✅ Start listening for trade lock updates when page loads
document.addEventListener("DOMContentLoaded", listenForTradeLockChanges);

function getPercentageDisplay(entryPrice, targetPrice, action) {
	if (!entryPrice || !targetPrice || isNaN(entryPrice) || isNaN(targetPrice)) return "";
	
	const percent = action === 'SELL' ?
		((entryPrice - targetPrice) / entryPrice) * 100 :
		((targetPrice - entryPrice) / entryPrice) * 100;
	
	const rounded = percent.toFixed(1);
	const sign = percent > 0 ? "+" : "";
	
	return `<span class="percent">(${sign}${rounded}%)</span>`;
}

// 🆕 Function to create a trade card
function createTradeCard(trade, tradeId, userPremiumAccess, tradeLocks) {
	const user = auth.currentUser;
	if (!user) {
		console.warn("User is logged out. Not displaying trades.");
		return null;
	}
	
	console.log("Creating trade card for ID:", tradeId, "Trade Data:", trade);
	
	const tradeCard = document.createElement("div");
	tradeCard.classList.add("trade-card");
	tradeCard.id = tradeId;
	
	// ✅ Ensure trade category is set properly
	const tradeCategory = trade.category || "others";
	tradeCard.setAttribute("data-category", tradeCategory);
	
	// ✅ Check if the trade should be unlocked
	const isAdmin = user.email === ADMIN_EMAIL; // Admin sees everything
	const hasCategoryAccess = userPremiumAccess[tradeCategory]?.status === true; // Premium access granted?
	const isCategoryUnlocked = tradeLocks[tradeCategory] === false; // If admin unlocked category
	const isTradeUnlocked = trade["stop-lossToggled"] || trade["target-1Toggled"] || trade["target-2Toggled"] || trade["target-3Toggled"];
	
	// ✅ New Logic: If any SL/T1/T2/T3 is toggled, unlock Action & Entry Price for ALL USERS
	const canSeeActionAndEntry = isAdmin || hasCategoryAccess || isCategoryUnlocked || isTradeUnlocked;
	const canSeeFullTrade = canSeeActionAndEntry || isTradeUnlocked;
	
	tradeCard.innerHTML = `
        <div class="trade-labels">
            <span class="trade-type-label" data-trade-id="${tradeId}">${trade.tradeType || "Intraday"}</span>
            
				    <!--<span class="trade-button-wrapper">
				        <button class="trade-chart-link-btn" data-link="${trade.chartLink || ''}" style="${trade.chartLink ? '' : 'display:none'}">
				            Trade Chart Link
				        </button>
				    </span>--><!--this button converted to span because of alignment match issue.-->
						
						<span class="trade-chart-link-btn" data-link="${trade.chartLink || ''}" style="${trade.chartLink ? '' : 'display:none'}">
						    Trade Chart Link
						</span>
            
            <span class="trade-state-label" data-trade-id="${tradeId}">${trade.tradeState || "Waiting for Entry"}</span>
        </div>

        <div class="trade-name">
            <h3>
                <!-- 🚀 Show Trade Action & Entry Price Only If User Has Access -->
                ${canSeeActionAndEntry ? `
                    <button class="trade-action trade-btn ${trade.action === 'BUY' ? 'buy' : 'sell'}" style="font-size: 20px;">
                        ${trade.action || "Action"}
                    </button>
                ` : ""}

                <!-- ✅ Asset Name (Always Visible) -->
                <button class="trade-asset trade-btn" style="background: none; color: var(--text-color); font-size: 20px; text-align: left; width: auto; white-space: nowrap;">
                    ${trade.asset || "Asset"}
                </button>

                ${canSeeActionAndEntry ? `
                    <button class="trade-entry-price trade-btn" style="background: none; color: var(--text-color); font-size: 20px; text-align: left; width: auto; white-space: nowrap;">
                        @ ${trade.entryPrice || "Entry"}
                    </button>
                ` : ""}
            </h3>
        </div>

        <!-- ✅ Timestamp -->
        <p class="timestamp">⏱️ Added on: ${trade.timestamp ? new Date(trade.timestamp.toDate()).toLocaleString() : "N/A"}</p>

        <!-- 📌 Category Display -->
        <p class="category-">
            📌 <b>Category:</b> <span>${trade.category || "Uncategorized"}</span>
        </p>

        <!-- 🔒 Locked Message (Only Show If Trade is Locked) -->
        ${!canSeeActionAndEntry ? `<p class="locked-message">🔒 There will be a delay in trade details because of restricted access.</p>` : ""}

        <!-- 🚀 Show SL/T1/T2/T3 Only If Trade is Fully Unlocked -->
        <!--<div class="trade-details ${canSeeFullTrade ? "" : "hidden"}">
            <div class="targets">
                <div class="trade-box stop-loss toggle-box ${trade['stop-lossToggled'] ? 'toggled' : ''}" 
                    data-trade-id="${tradeId}" data-target="stop-loss">
                    SL: ${trade.sl || "---"}
                </div>
                <div class="trade-box target toggle-box ${trade['target-1Toggled'] ? 'toggled' : ''}" 
                    data-trade-id="${tradeId}" data-target="target-1">
                    T1: ${trade.t1 || "---"}
                </div>
                <div class="trade-box target toggle-box ${trade['target-2Toggled'] ? 'toggled' : ''}" 
                    data-trade-id="${tradeId}" data-target="target-2">
                    T2: ${trade.t2 || "---"}
                </div>
                <div class="trade-box target toggle-box ${trade['target-3Toggled'] ? 'toggled' : ''}" 
                    data-trade-id="${tradeId}" data-target="target-3">
                    T3: ${trade.t3 || "---"}
                </div>
            </div>
        </div>-->
        
				<!-- 🚀 Show SL/T1/T2/T3 Only If Trade is Fully Unlocked -->
				<div class="trade-details ${canSeeFullTrade ? "" : "hidden"}">
				  <div class="targets">
				    <div class="trade-box stop-loss toggle-box ${trade['stop-lossToggled'] ? 'toggled' : ''}" 
				        data-trade-id="${tradeId}" data-target="stop-loss">
				      SL: ${trade.sl || "---"}<br>
				      ${getPercentageDisplay(trade.entryPrice, trade.sl, trade.action)}
				    </div>
				
				    <div class="trade-box target toggle-box ${trade['target-1Toggled'] ? 'toggled' : ''}" 
				        data-trade-id="${tradeId}" data-target="target-1">
				      T1: ${trade.t1 || "---"}<br>
				      ${getPercentageDisplay(trade.entryPrice, trade.t1, trade.action)}
				    </div>
				
				    <div class="trade-box target toggle-box ${trade['target-2Toggled'] ? 'toggled' : ''}" 
				        data-trade-id="${tradeId}" data-target="target-2">
				      T2: ${trade.t2 || "---"}<br>
				      ${getPercentageDisplay(trade.entryPrice, trade.t2, trade.action)}
				    </div>
				
				    <div class="trade-box target toggle-box ${trade['target-3Toggled'] ? 'toggled' : ''}" 
				        data-trade-id="${tradeId}" data-target="target-3">
				      T3: ${trade.t3 || "---"}<br>
				      ${getPercentageDisplay(trade.entryPrice, trade.t3, trade.action)}
				    </div>
				  </div> 
				  </div>

        <div class="trade-actions">
            <!--<button class="history-btn" data-id="${tradeId}">📜 View History 🧐</button>-->
						<!--<button class="history-btn" data-id="${tradeId}" 
						    style="border: 2px solid gray; background: none; color: var(--text-color); font-size: 16px; padding: 5px 10px; white-space: nowrap;">
						    📜 View History 🧐
						</button>-->

						<!--<button
						  class="history-btn"
						  data-id="${tradeId}"
						  style="
						    border: 2px solid gray;
						    background: none;
						    color: var(--text-color);
						    font-size: 16px;
						    padding: 5px 10px;
						    white-space: nowrap;
						    cursor:pointer;
						  "
						>
						  <span class="scroll">📜</span>
						  View History 🧐
						</button>-->
						
						<button
						  class="history-btn"
						  data-id="${tradeId}"
						  style="
						    border: 2px solid gray;
						    background: none;
						    color: var(--text-color);
						    font-size: 16px;
						    padding: 5px 10px;
						    white-space: nowrap;
						    cursor: pointer;
						  "
						>
						  <span class="scroll">📜</span>
						  View History
						  <span class="bounce">🧐</span>
						</button>

            <!-- 🚀 Admin Controls -->
            ${isAdmin ? `
                <button class="update-btn" data-id="${tradeId}"style="border: 2px solid gray; background: none; color: var(--text-color); font-size: 16px; padding: 5px 10px; white-space: nowrap;">✏️ Add Update</button>
                
                <button class="delete-trade-btn" data-id="${tradeId}"style="border: 2px solid gray; background: none; color: var(--text-color); font-size: 16px; padding: 5px 10px; white-space: nowrap;">🗑 Delete</button>
            ` : ""}

            <button class="like-btn" data-id="${tradeId}"> 👍 ${trade.likes || 0} </button>
            <button class="dislike-btn" data-id="${tradeId}"> 👎 ${trade.dislikes || 0} </button>
        </div>
        <div>
            <!--<b><br><span style="font-size:16px; color:#909090;">Trade Generated By </span>
            <span style="font-size:18px; color:red;">DotX View Algo Bot</span></b>-->
						<!--<b><br><span style="font-size:16px; color:#909090;">Trade Generated By </span>  
						<span style="font-size:18px; color:#D32F2F; font-weight:bold;">⚡ DotX View Algo Bot</span></b>-->
												
						<b>
						  <br>

						  <span class="tooltip-trigger" data-tooltip-id="tradecard">ℹ️</span>
						  <span style="font-size:16px; color:#909090;">Trade Generated By </span>  
						  <span style="font-size:18px; color:#D32F2F; font-weight:bold;">
						    <span class="lightning">⚡</span> Dot View Algo Bot
						  </span>

						</b>
            
        </div> 
        <div>
            <div class="trade-history hidden" id="history-${tradeId}"></div>
        </div>
    `;
	const chartLinkBtn = tradeCard.querySelector(".trade-chart-link-btn");
	if (chartLinkBtn && chartLinkBtn.dataset.link) {
		chartLinkBtn.addEventListener("click", () => {
			window.open(chartLinkBtn.dataset.link, "_blank");
		});
	}
	
	// ✅ Attach event listeners safely
	setTimeout(() => {
		if (isAdmin) {
			applyLabelClickListeners(tradeId);
			applyTradeButtonListeners(tradeId);
			
		}
	}, 100); // ⏳ Delay ensures elements exist before attaching listeners
	
	return tradeCard;
}


/////////////////////// event listener to open settings panel when user click on message above trade card.
document.addEventListener("click", function (event) {
    if (event.target.classList.contains("upgrade-access-btn")) {
        openSettingsPanel(); // Function to open settings
    }
});

function openSettingsPanel() {
    document.getElementById("settings-panel").classList.remove("hidden");
}
/////////////////////// Detect Category Selection and Load Trades Start
document.getElementById("category-filter").addEventListener("change", function() {
	const selectedCategory = this.value;
	loadTrades(selectedCategory);
});

/////////////////////// Detect Category Selection and Load Trades End


//this is to solve issue of tradecard tooltip////
async function loadTradeHistory(tradeId, historyDiv) {
    const tradeRef = doc(db, "trades", tradeId);
    const tradeSnap = await getDoc(tradeRef);

    if (tradeSnap.exists()) {
        const tradeData = tradeSnap.data();
        historyDiv.innerHTML = tradeData.updates.map((update, index) => `
            </br><div class="update-entry">
                <!--<ul>(May be sometimes there will be delay to update trade activities because of server issues. Kindly watch your trades actively.)</ul>-->
                <!--<p>${new Date(update.timestamp.toDate()).toLocaleString()}: ${update.text}</p>-->
                <!--<p>${new Date(update.timestamp.toDate()).toLocaleString()}: <b>${update.text}</b></p>-->
                <p><span style="font-size:12px;">${new Date(update.timestamp.toDate()).toLocaleString()}:</span> <b style="font-size:16px;">${update.text}</b></p>
                <button class="delete-update-btn hidden" data-trade-id="${tradeId}" data-index="${index}">🗑 Delete</button>
            </div>
        `).join("");
    }
    attachDeleteUpdateListeners();
} 

function attachDeleteUpdateListeners() {
  document.querySelectorAll(".delete-update-btn").forEach(button => {
    button.addEventListener("click", async (e) => {
      const verified = await verifyAdmin();
      if (!verified) return;
      
      const tradeId = e.target.dataset.tradeId;
      const updateIndex = parseInt(e.target.dataset.index);
      await deleteTradeUpdate(tradeId, updateIndex);
    });
  });
}

// Load stored toggle states on page refresh
function attachToggleListeners() {
	document.querySelectorAll(".toggle-box").forEach((box) => {
		box.addEventListener("click", async function() {
			const user = auth.currentUser;
			if (!user) return;
			
			const isAdminUser = await checkIfAdmin(user);
			if (!isAdminUser) return; // ❌ Non-admins cannot toggle
			
			// ✅ Admin Password Confirmation
			const password = prompt("Enter admin password to confirm:");
			if (password !== secretKey) {
				alert("❌ Incorrect password! Toggling denied.");
				return;
			}
			
			// ✅ Password correct → Toggle SL/Target
			const tradeId = this.getAttribute("data-trade-id");
			const target = this.getAttribute("data-target");
			toggleTradeStatus(tradeId, target);
		});
	});
}

async function toggleTradeStatus(tradeId, target) {
    const tradeRef = doc(db, "trades", tradeId);
    const tradeDoc = await getDoc(tradeRef);

    if (!tradeDoc.exists()) return;

    const tradeData = tradeDoc.data();
    const toggleKey = `${target}Toggled`;
    const newState = !tradeData[toggleKey];

    await updateDoc(tradeRef, { [toggleKey]: newState });

    console.log(`✅ ${target} toggled for Trade ID: ${tradeId}`);
}

async function updateLikeDislike(tradeId, type) {
    const tradeRef = doc(db, "trades", tradeId);
    const tradeSnap = await getDoc(tradeRef);

    if (tradeSnap.exists()) {
        const tradeData = tradeSnap.data();
        const updatedValue = (tradeData[type] || 0) + 1; // Increment like/dislike count
        await updateDoc(tradeRef, { [type]: updatedValue });

        // Update UI immediately
        document.querySelector(`[data-id="${tradeId}"].${type === "likes" ? "like-btn" : "dislike-btn"}`).innerText = 
            `${type === "likes" ? "👍" : "👎"} ${updatedValue}`;
    }
}
// ✅ sign up with  Send verification email
//import { getAuth, createUserWithEmailAndPassword, sendEmailVerification, signInWithEmailAndPassword, signOut } from "firebase/auth";

//const auth = getAuth();

// Signup with Email Verification
signupBtn.addEventListener("click", async () => {
	const email = prompt("Enter Email:");
	const password = prompt("Enter Password:");
	try {
		const userCredential = await createUserWithEmailAndPassword(auth, email, password);
		const user = userCredential.user;
		
		// ✅ Send verification email
		await sendEmailVerification(user);
		alert("✅ Account created! A verification email has been sent. Please verify before logging in.");
		
		// ✅ Logout user immediately after signup to prevent login before verification
		await signOut(auth);
		alert("You have been logged out. Please verify your email before logging in.");
	} catch (error) {
		alert("❌ Signup failed: " + error.message);
	}
});



// ✅ Signup normal
//signupBtn.addEventListener("click", async () => {
    //const email = prompt("Enter Email:");
    //const password = prompt("Enter Password:");
    //try {
        //await createUserWithEmailAndPassword(auth, email, password);
        //alert("✅ Account created successfully!");
    //} catch (error) {
        //alert("❌ Signup failed: " + error.message);
    //}
//});



//import { getFirestore, doc, setDoc, getDoc } from "firebase/firestore"; import { auth } from "./firebaseConfig.js";

//const db = getFirestore(); 
loginBtn.addEventListener("click", async () => {
	const email = prompt("Enter Email:");
	const password = prompt("Enter Password:");
	
	try {
		const userCredential = await signInWithEmailAndPassword(auth, email, password);
		const user = userCredential.user;
		
		if (!user.emailVerified) {
			alert("❌ Please verify your email before logging in.");
			await signOut(auth);
			return;
		}
		
		alert("✅ Login successful!");
		
		// Check agreement status in Firestore
		const agreementDoc = await getDoc(doc(db, "user_agreements", user.uid));
		
		if (!agreementDoc.exists()) {
			// No agreement found in Firestore, show disclaimer
			showDisclaimerPopup(user.uid);
		} else {
			// Agreement exists, proceed normally
			proceedToDashboard();
		}
		
	} catch (error) {
		alert("❌ Login failed: " + error.message);
	}
});

// Function to show the disclaimer popup
function showDisclaimerPopup(userId) {
	document.getElementById("disclaimer-popup").style.display = "flex";
	
	document.getElementById("agree-btn").addEventListener("click", async () => {
		try {
			// Save agreement to Firestore
			await setDoc(doc(db, "user_agreements", userId), { agreedAt: new Date() });
			
			// Hide disclaimer and proceed
			document.getElementById("disclaimer-popup").style.display = "none";
			proceedToDashboard();
		} catch (error) {
			console.error("❌ Error saving agreement:", error);
			alert("⚠️ Unable to save agreement to Firestore. Please try again.");
		}
	});
}

// Function to proceed after agreement
function proceedToDashboard() {
	document.getElementById("trade-section").classList.remove("hidden");
	document.getElementById("login-notice").classList.add("hidden");
}




//✅ Updated Signup Code (With Email Check at Login)
//loginBtn.addEventListener("click", async () => {
	//const email = prompt("Enter Email:");
	//const password = prompt("Enter Password:");
	//try {
		//const userCredential = await signInWithEmailAndPassword(auth, email, password);
		//const user = userCredential.user;
		
		//if (!user.emailVerified) {
			//alert("❌ Please verify your email before logging in.");
			//await signOut(auth); // ✅ Force logout if unverified
			//return;
		//}
		
		//alert("✅ Login successful!");
	//} catch (error) {
		//alert("❌ Login failed: " + error.message);
	//}
//});



// ✅ Logout
logoutBtn.addEventListener("click", async () => {
    try {
        await signOut(auth);
        alert("✅ Logged out successfully!");
    } catch (error) {
        alert("❌ Logout failed: " + error.message);
    }
});

// ✅ Automatically update UI based on login state

let userLoginTime = null; // Store login timestamp in memory

onAuthStateChanged(auth, async (user) => {
    if (user) {
        console.log("✅ User logged in:", user.email);

        loginBtn.style.display = "none";
        signupBtn.style.display = "none";
        logoutBtn.style.display = "block";

        // ✅ Store login timestamp for notification filtering
        userLoginTime = new Date(); 
        
        // ✅ Show trades, hide login notice
        document.getElementById("trade-section").classList.remove("hidden");
        document.getElementById("login-notice").classList.add("hidden");

        const isAdminUser = await checkIfAdmin(user);
        if (isAdminUser) {
            console.log("✅ Admin detected. Showing admin controls...");
            document.getElementById("admin-btn").classList.remove("hidden");
            document.getElementById("remove-all-trades").classList.remove("hidden");
            document.getElementById("trade-form-container").classList.remove("hidden");
            document.getElementById("add-trade").classList.remove("hidden");
            document.querySelectorAll(".delete-trade-btn, .update-btn, .delete-update-btn")
                .forEach(btn => btn.classList.remove("hidden"));
        }

        // ✅ Load trades & notifications AFTER login
        loadTrades();
        fetchNotifications(); // ✅ Only fetch notifications after login

    } else {
        console.log("❌ User is logged out.");
        loginBtn.style.display = "block";
        signupBtn.style.display = "block";
        logoutBtn.style.display = "none";

        // ❌ Hide trades, show login notice
        document.getElementById("trade-section").classList.add("hidden");
        document.getElementById("login-notice").classList.remove("hidden");

        // ✅ Clear trade list on logout
        const tradeContainer = document.getElementById("trade-container");
        if (tradeContainer) {
            tradeContainer.innerHTML = "";
        } else {
            console.error("❌ ERROR: trade-container not found in the DOM!");
        }

        // ✅ Hide admin buttons
        document.getElementById("admin-btn").classList.add("hidden");
        document.getElementById("remove-all-trades").classList.add("hidden");
        document.getElementById("trade-form-container").classList.add("hidden");
        document.getElementById("add-trade").classList.add("hidden");
        document.querySelectorAll(".delete-trade-btn, .update-btn, .delete-update-btn")
            .forEach(btn => btn.classList.add("hidden"));

        // ✅ Reset login time & clear notifications
        userLoginTime = null;
        clearNotifications();
        
    }
});


function updateDateButton() {
    const dateBtn = document.getElementById("date-btn");
    const today = new Date().toLocaleDateString("en-US", {
        weekday: "long",  // Example: Monday
        year: "numeric",
        month: "long",   // Example: March
        day: "numeric"   // Example: 9
    });

    dateBtn.textContent = `📅 ${today}`; 
}

// Run the function when the page loads
updateDateButton();

// ✅ Remove all trades
removeAllTradesBtn.addEventListener("click", async () => {
    const verified = await verifyAdmin();
    if (!verified) return;

    const querySnapshot = await getDocs(collection(db, "trades"));
    querySnapshot.forEach(async (docSnap) => {
        await deleteDoc(doc(db, "trades", docSnap.id));
    });

    alert("✅ All trades removed!");
});

loadTrades(); 





window.sendMessageReply = sendMessageReply;
//upgrade access buttons open settings panel
document.addEventListener("DOMContentLoaded", function() {
	document.querySelectorAll(".upgrade-access-btn").forEach(button => {
		button.addEventListener("click", function() {
			document.getElementById("settings-panel").classList.remove("hidden");
		});
	});
});


/////////////Support Section starts here //////////////

document.addEventListener("DOMContentLoaded", () => {
	const supportDocRef = doc(db, "settings", "support_section");

	/**************** USER SIDE ****************/
	async function loadSupportSection() {
		const supportSection = document.getElementById("support-section");
		if (!supportSection) return;

		try {
			const docSnap = await getDoc(supportDocRef);
			if (!docSnap.exists()) return (supportSection.style.display = "none");

			const data = docSnap.data();
			supportSection.style.display = data.enabled ? "block" : "none";

			const contactList = document.getElementById("user-contact-list");
			const linkList = document.getElementById("user-link-list");

			if (contactList && linkList) {
				contactList.innerHTML = "";
				linkList.innerHTML = "";

				(data.contacts || []).forEach(contact => {
					const li = document.createElement("li");
					li.innerHTML = `</br><strong>${contact.type}:</strong> <a href="${getContactLink(contact.type, contact.value)}" target="_blank">${contact.value}</a></br>`;
					contactList.appendChild(li);
				});

				(data.links || []).forEach(link => {
					const li = document.createElement("li");
					li.innerHTML = `</br><strong>${link.type}:</strong> <a href="${link.value}" target="_blank">${link.value}</a></br>`;
					linkList.appendChild(li);
				});
			}
		} catch (error) {
			console.error("❌ Error loading support section:", error);
		}
	}

	document.getElementById("toggle-support-details")?.addEventListener("click", function () {
		const details = document.getElementById("support-extra");
		if (!details) return;
		details.style.display = details.style.display === "none" ? "block" : "none";
		this.textContent = details.style.display === "none" ? "More Details" : "Hide Details";
	});

	loadSupportSection();

	/**************** ADMIN SIDE ****************/
	let contacts = [];
	let links = [];

	const contactListAdmin = document.getElementById("contact-list");
	const linkListAdmin = document.getElementById("link-list");

	async function loadSupportSettings() {
		const docSnap = await getDoc(supportDocRef);
		if (!docSnap.exists()) return;

		const data = docSnap.data();
		document.getElementById("toggle-support")?.setAttribute("checked", data.enabled);

		contacts = data.contacts || [];
		links = data.links || [];
		updateAdminUI();
	}

	function updateAdminUI() {
		if (contactListAdmin) {
			contactListAdmin.innerHTML = "";
			contacts.forEach((contact, index) => {
				const li = document.createElement("li");
				li.innerHTML = `
					<span>${contact.type}: ${contact.value}</span>
					<button onclick="editContact(${index})">Edit</button>
					<button onclick="deleteContact(${index})">Delete</button>
				`;
				contactListAdmin.appendChild(li);
			});
		}

		if (linkListAdmin) {
			linkListAdmin.innerHTML = "";
			links.forEach((link, index) => {
				const li = document.createElement("li");
				li.innerHTML = `
					<span>${link.type}: ${link.value}</span>
					<button onclick="editLink(${index})">Edit</button>
					<button onclick="deleteLink(${index})">Delete</button>
				`;
				linkListAdmin.appendChild(li);
			});
		}
	}

	window.editContact = (i) => {
		const newVal = prompt("Edit contact:", contacts[i].value);
		if (newVal) {
			contacts[i].value = newVal;
			saveSupportSettings();
		}
	};

	window.deleteContact = (i) => {
		if (confirm("Delete contact?")) {
			contacts.splice(i, 1);
			saveSupportSettings();
		}
	};

	window.editLink = (i) => {
		const newVal = prompt("Edit link:", links[i].value);
		if (newVal) {
			links[i].value = newVal;
			saveSupportSettings();
		}
	};

	window.deleteLink = (i) => {
		if (confirm("Delete link?")) {
			links.splice(i, 1);
			saveSupportSettings();
		}
	};

	async function saveSupportSettings() {
		await setDoc(supportDocRef, {
			enabled: document.getElementById("toggle-support")?.checked || false,
			contacts,
			links
		}, { merge: true });
		updateAdminUI();
		loadSupportSection();
		alert("✅ Support section updated!");
	}

	// Admin buttons
	document.getElementById("add-contact-btn")?.addEventListener("click", () => {
		const type = prompt("Type (e.g., Email, Phone)");
		const value = prompt("Value");
		if (type && value) {
			contacts.push({ type, value });
			updateAdminUI();
		}
	});

	document.getElementById("add-link-btn")?.addEventListener("click", () => {
		const type = prompt("Link Type (e.g., Telegram)");
		const value = prompt("URL");
		if (type && value) {
			links.push({ type, value });
			updateAdminUI();
		}
	});

	document.getElementById("save-support-settings")?.addEventListener("click", saveSupportSettings);

	document.getElementById("toggle-support")?.addEventListener("change", saveSupportSettings);

	loadSupportSettings();
});

// Helper to build contact links
function getContactLink(type, value) {
	switch (type.toLowerCase()) {
		case "email": return `mailto:${value}`;
		case "phone": return `tel:${value}`;
		case "whatsapp": return `https://wa.me/${value.replace(/\D/g, "")}`;
		case "telegram": return `https://t.me/${value}`;
		default: return value;
	}
}



//toggle for admin support settings inside admin panel

document.getElementById("toggle-admin-support-settings").addEventListener("click", function () {
    const adminSupportSettingsContainer = document.getElementById("admin-support-settings-container");
    if (adminSupportSettingsContainer.style.display === "none" || adminSupportSettingsContainer.style.display === "") {
        adminSupportSettingsContainer.style.display = "block"; // Expand
    } else {
        adminSupportSettingsContainer.style.display = "none"; // Collapse
    }
});


/////////////Support Section ends here //////////////



////////////Refresh Button Starts Here//////////

document.getElementById("refresh-btn").addEventListener("click", () => {
  location.reload();
});

////////////Refresh Button Ends Here//////////